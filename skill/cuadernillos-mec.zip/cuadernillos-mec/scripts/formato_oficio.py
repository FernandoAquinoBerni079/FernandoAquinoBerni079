# -*- coding: utf-8 -*-
"""formato_oficio.py — pasa un tomo existente al formato estándar (Fer, 02-oct-2026):
oficio 21,59 × 33,02 cm · márgenes estrechos 1,27 cm · tablas ajustadas a la ventana.

    python3 formato_oficio.py TOMO_A4.docx TOMO_OFICIO.docx

- Todas las secciones pasan a oficio con márgenes de 1,27 cm (encabezado y pie a 1,25 cm).
- Tablas: helpers.tablas_a_ventana() (100 % del ancho, columnas reescaladas).
- Imágenes ancladas a página completa (portada y contraportada compuestas): en oficio la
  proporción es 0,654 y no 0,707 como en A4. NO se estiran, porque se deformarían, ni se
  recortan, porque perderían texto: se agregan filas en las franjas lisas (filas de
  desvío bajo en la horizontal) repartidas en cuatro zonas, hasta llegar a la proporción de
  oficio. Validado en la portada y la contraportada de Software 1.er Curso, sin costuras
  visibles. Las fotos de Gemini que van dentro de esas composiciones no se tocan.
- Las imágenes en línea conservan su tamaño (el ancho útil crece de 16,6 a 19,05 cm).
Después: helpers.saltos_robustos, paginacion.corregir_paginas e indice_pdf.
"""
import io, sys
import numpy as np
from PIL import Image
import docx
from docx.oxml.ns import qn
from helpers import tablas_a_ventana, saltos_robustos, subtitulos_keep_next

W_TW, H_TW, M_TW = 12240, 18720, 720
A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
PROP = 33.02 / 21.59

def extender_vertical(blob, zonas=4, umbral_std=6):
    im = Image.open(io.BytesIO(blob)).convert('RGB'); a = np.asarray(im)
    h_obj = round(a.shape[1] * PROP); falta = h_obj - a.shape[0]
    if falta <= 0:
        return blob
    std = a.std(axis=1).mean(axis=1); corridas = []; ini = None
    for y in range(a.shape[0]):
        if std[y] < umbral_std:
            ini = y if ini is None else ini
        else:
            if ini is not None and y - ini > 20:
                corridas.append((ini, y))
            ini = None
    corridas = sorted(corridas, key=lambda r: r[1] - r[0], reverse=True)[:zonas]
    if not corridas:
        raise ValueError('sin franjas lisas: rehacer la composición en proporción oficio')
    tot = sum(b - a_ for a_, b in corridas)
    adds = [round(falta * (b - a_) / tot) for a_, b in corridas]; adds[0] += falta - sum(adds)
    partes = []; prev = 0
    for (a_, b), k in sorted(zip(corridas, adds)):
        y = (a_ + b) // 2
        partes += [a[prev:y], np.repeat(a[y:y + 1], k, axis=0)]; prev = y
    partes.append(a[prev:])
    out = io.BytesIO(); Image.fromarray(np.concatenate(partes)).save(out, 'JPEG', quality=95)
    return out.getvalue()

def convertir(src, dst):
    d = docx.Document(src); b = d.element.body
    for s in b.iter(qn('w:sectPr')):
        pg = s.find(qn('w:pgSz')); pg.set(qn('w:w'), str(W_TW)); pg.set(qn('w:h'), str(H_TW))
        m = s.find(qn('w:pgMar'))
        for k in ('top', 'bottom', 'left', 'right'):
            m.set(qn('w:' + k), str(M_TW))
        m.set(qn('w:header'), '708'); m.set(qn('w:footer'), '708')
    cx, cy = str(round(21.59 / 2.54 * 914400)), str(round(33.02 / 2.54 * 914400))
    for dr in b.iter(qn('w:drawing')):
        anc = dr.find(qn('wp:anchor'))
        if anc is None:
            continue
        ext = anc.find(qn('wp:extent'))
        if int(ext.get('cx')) < 0.9 * 7560000:       # no es de página completa
            continue
        blip = dr.find('.//' + A + 'blip'); part = d.part.related_parts[blip.get(qn('r:embed'))]
        part._blob = extender_vertical(part.blob)
        for e in [ext] + list(dr.iter(A + 'ext')):
            e.set('cx', cx); e.set('cy', cy)
    n = tablas_a_ventana(d); saltos_robustos(d); subtitulos_keep_next(d)
    d.save(dst)
    print('oficio OK · tablas ajustadas:', n)

if __name__ == '__main__':
    convertir(sys.argv[1], sys.argv[2])
