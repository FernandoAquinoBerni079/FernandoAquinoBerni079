# -*- coding: utf-8 -*-
"""plan_anual.py — Plan Anual canónico del MEC (Paraguay).

    build_plan_anual(plan_data, ruta)

A4 horizontal · tabla continua de 7 columnas · ANCHOS = 26,6 cm (ancho útil real
del A4 apaisado con márgenes de 1,5 cm: NO reescribirlos a mano) · layout fijo con
tblGrid · encabezado repetible · cantSplit 100 % · bandas de etapa azules · filas de
unidad en el color de la materia · fila propia (N.º = «—») para las evaluaciones de
etapa · cierre con criterios, inclusión y firmas · footer con campos reales.

plan_data = {
  'materia': 'Lengua y Literatura Castellana',
  'curso': '8.º grado',
  'subtitulo': 'Educación Escolar Básica · Tercer Ciclo · Plan Común',
  'horas': '4 horas semanales',
  'identidad': {'DARK': '6A3E46', 'MED': '925663', 'LIGHT': 'F7EEF0'},
  'etapas': [
     {'banda': 'PRIMERA ETAPA — cierre en junio',
      'unidades': [
         {'nombre': 'UNIDAD 1 — …',
          'clases': [
             {'n': 1, 'tema': '…', 'indicadores': ['…', '…'], 'tiempo': '4 h',
              'procedimiento': '…', 'instrumento': '…', 'observacion': '…',
              'capacidades': ['Texto OFICIAL de la capacidad, sin reformular.']},
          ]},
      ],
      'evaluacion': 'Evaluación de la Primera Etapa (Unidades 1 a 4)'},
  ],
  'criterios': 'texto…', 'inclusion': 'texto…',
}

Trazabilidad (auditoría ChatGPT, oct-2026): cada secuencia lleva `capacidades`, una lista
con la(s) capacidad(es) del programa MEC transcriptas TEXTUALMENTE, una por ítem y nunca
fusionadas. Van dentro de la celda TEMAS, debajo del tema, con el rótulo «Capacidad MEC:».
Si hay capacidades, el encabezado pasa a «TEMAS Y CAPACIDAD MEC». No se agrega una octava
columna: los ANCHOS suman el ancho útil del A4 apaisado. Las secuencias de profundización y
las evaluaciones de unidad repiten la capacidad que consolidan. En las integradoras de
etapa se puede poner una remisión («Todas las capacidades de la Unidad 1, transcriptas en
las secuencias 1 a 15»), para que la fila no supere una hoja.
`assert` de cobertura: la unión de todas las `capacidades` = todas las capacidades del
programa (en Software 1.º faltaba una: «Reconoce la importancia de la capacidad de
abstracción…»).

Los temas y los indicadores se LEEN de las fichas del tomo (`extraer_fichas()` de
helpers, o importando los módulos de contenido). Nunca se escriben a mano acá.
"""
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ANCHOS = [1.0, 5.0, 6.8, 1.5, 5.3, 4.2, 2.8]        # = 26,6 cm
COLS = ['N.º', 'TEMAS', 'INDICADORES DE LOGRO', 'TIEMPO', 'PROCEDIMIENTOS',
        'INSTRUMENTOS DE EVALUACIÓN', 'OBSERVACIÓN']
AZUL = '1B4F72'
AZUL_CLARO = 'EAF0F6'
CABECERA = '5D4037'


def _shd(cell, fill):
    s = OxmlElement('w:shd'); s.set(qn('w:val'), 'clear')
    s.set(qn('w:color'), 'auto'); s.set(qn('w:fill'), fill)
    cell._tc.get_or_add_tcPr().append(s)


def _celda(cell, texto, bold=False, blanco=False, size=8.5):
    par = cell.paragraphs[0]
    for i, linea in enumerate(texto if isinstance(texto, list) else [texto]):
        if i:
            par = cell.add_paragraph(); par.paragraph_format.space_after = Pt(2)
        r = par.add_run(linea); r.bold = bold; r.font.size = Pt(size)
        if blanco:
            r.font.color.rgb = RGBColor.from_string('FFFFFF')


def _celda_tema(cell, lineas, size=8.5):
    """[tema, 'Capacidad MEC:', '«cap 1»', …]: rótulo en negrita, capacidades en cursiva."""
    par = cell.paragraphs[0]
    for i, linea in enumerate(lineas):
        if i:
            par = cell.add_paragraph(); par.paragraph_format.space_after = Pt(1)
        r = par.add_run(linea); r.font.size = Pt(size)
        r.bold = (linea == 'Capacidad MEC:'); r.italic = linea.startswith('«')


def verificar_capacidades(plan_data, capacidades_programa):
    """Cobertura textual: toda capacidad oficial aparece en al menos una secuencia y no hay
    capacidades que no sean del programa (fusiones, recortes, paráfrasis)."""
    usadas = {x for e in plan_data['etapas'] for u in e['unidades'] for c in u['clases']
              for x in c.get('capacidades', [])}
    faltan = [x for x in capacidades_programa if x not in usadas]
    ajenas = [x for x in usadas if x not in capacidades_programa]
    assert not faltan and not ajenas, ('faltan', faltan, 'no oficiales', ajenas)
    return len(usadas)


def build_plan_anual(plan_data, ruta):
    ident = plan_data['identidad']
    DARK, MED, LIGHT = ident['DARK'], ident['MED'], ident.get('LIGHT', 'F5F5F5')

    doc = Document()
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = Cm(29.7), Cm(21.0)
    sec.top_margin = sec.bottom_margin = Cm(1.2)
    sec.left_margin = sec.right_margin = Cm(1.5)
    st = doc.styles['Normal']; st.font.name = 'Calibri'; st.font.size = Pt(8.5)

    def p(t, bold=False, size=10, color=None, center=False):
        par = doc.add_paragraph()
        r = par.add_run(t); r.bold = bold; r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
        if center:
            par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        return par

    p('PLAN ANUAL — %s · %s' % (plan_data['materia'].upper(), plan_data['curso'].upper()),
      bold=True, size=14, color=DARK, center=True)
    p('%s · %s · República del Paraguay · %s' % (plan_data['subtitulo'], plan_data['horas'],
                                                 plan_data.get('anio', '2026')),
      size=9.5, center=True)
    p('Institución educativa: ______________________________  '
      'Docente: ______________________________', size=9)

    t = doc.add_table(rows=1, cols=7)
    t.autofit = False
    tblPr = t._tbl.tblPr
    lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
    tw = OxmlElement('w:tblW'); tw.set(qn('w:w'), str(int(sum(ANCHOS) * 567)))
    tw.set(qn('w:type'), 'dxa'); tblPr.append(tw)
    b = OxmlElement('w:tblBorders')
    for e in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement('w:' + e); el.set(qn('w:val'), 'single'); el.set(qn('w:sz'), '4')
        el.set(qn('w:space'), '0'); el.set(qn('w:color'), '808080'); b.append(el)
    tblPr.append(b)
    # tblGrid: sin esto Word ignora los anchos de columna
    g = t._tbl.find(qn('w:tblGrid'))
    if g is not None:
        t._tbl.remove(g)
    g = OxmlElement('w:tblGrid')
    for a in ANCHOS:
        gc = OxmlElement('w:gridCol'); gc.set(qn('w:w'), str(int(a * 567))); g.append(gc)
    tblPr.addnext(g)

    def _anchos(row):
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for j, c in enumerate(row.cells):
            c.width = Cm(ANCHOS[j])

    hdr = t.rows[0]; _anchos(hdr)
    hdr._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    con_cap = any(c.get('capacidades') for e in plan_data['etapas'] for u in e['unidades']
                  for c in u['clases'])
    for j, h in enumerate(COLS):
        if j == 1 and con_cap:
            h = 'TEMAS Y CAPACIDAD MEC'
        _shd(hdr.cells[j], CABECERA); _celda(hdr.cells[j], h, bold=True, blanco=True)

    def fila():
        r = t.add_row(); _anchos(r); return r

    def banda(texto, fill=AZUL, size=9.5):
        r = fila(); m = r.cells[0].merge(r.cells[6])
        _shd(m, fill); _celda(m, texto, bold=True, blanco=True, size=size)

    for etapa in plan_data['etapas']:
        banda(etapa['banda'])
        for u in etapa['unidades']:
            r = fila(); m = r.cells[0].merge(r.cells[6])
            _shd(m, MED); _celda(m, u['nombre'], bold=True, blanco=True, size=9)
            for c in u['clases']:
                r = fila()
                tema = c['tema']
                if c.get('capacidades'):
                    tema = [c['tema'], 'Capacidad MEC:'] + ['«%s»' % x for x in c['capacidades']]
                datos = [str(c['n']), tema,
                         '\n'.join('• ' + i for i in c['indicadores']),
                         c.get('tiempo', ''), c['procedimiento'], c['instrumento'],
                         c.get('observacion', '')]
                for j, v in enumerate(datos):
                    if j == 1 and isinstance(v, list):
                        _celda_tema(r.cells[j], v)
                    else:
                        _celda(r.cells[j], v)
                _shd(r.cells[0], LIGHT)
        if etapa.get('evaluacion'):
            r = fila()
            vals = ['—', etapa['evaluacion'],
                    'Integra los indicadores de las unidades de la etapa',
                    plan_data.get('tiempo_etapa', ''),
                    'Aplicación de la evaluación escrita de etapa',
                    'Prueba escrita de etapa con clave y criterios',
                    'Página propia en el tomo; banda azul']
            for j, v in enumerate(vals):
                _celda(r.cells[j], v, bold=(j <= 1))
                _shd(r.cells[j], AZUL_CLARO)

    doc.add_paragraph()
    p('Criterios generales de evaluación: ' + plan_data['criterios'], size=9)
    p('Estrategias de inclusión: ' + plan_data['inclusion'], size=9)
    doc.add_paragraph()
    p('Firma del docente: ______________________          '
      'Firma de la dirección: ______________________', size=9.5)

    # footer con campos reales
    pf = sec.footer.paragraphs[0]
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = pf.add_run('Página '); r.font.size = Pt(9)
    _fld(pf, ' PAGE ')
    r2 = pf.add_run(' de '); r2.font.size = Pt(9)
    _fld(pf, ' NUMPAGES ')

    settings = doc.settings.element
    if settings.find(qn('w:updateFields')) is None:
        el = OxmlElement('w:updateFields'); el.set(qn('w:val'), 'true')
        compat = settings.find(qn('w:compat'))
        (compat.addprevious(el) if compat is not None else settings.append(el))

    doc.save(ruta)
    return ruta


def _fld(par, instr):
    for el, attrs in (('w:fldChar', {'w:fldCharType': 'begin'}), ('w:instrText', None),
                      ('w:fldChar', {'w:fldCharType': 'end'})):
        r = OxmlElement('w:r'); e = OxmlElement(el)
        if el == 'w:instrText':
            e.set(qn('xml:space'), 'preserve'); e.text = instr
        else:
            for k, v in attrs.items():
                e.set(qn(k), v)
        r.append(e); par._p.append(r)


def verificar_unicidad(plan_data):
    """Procedimientos e instrumentos ÚNICOS entre sí: control programático, no a ojo."""
    procs, insts = [], []
    for etapa in plan_data['etapas']:
        for u in etapa['unidades']:
            for c in u['clases']:
                procs.append(c['procedimiento']); insts.append(c['instrumento'])
    assert len(set(procs)) == len(procs), 'procedimientos repetidos en el Plan Anual'
    assert len(set(insts)) == len(insts), 'instrumentos repetidos en el Plan Anual'
    return len(procs)


def sin_codigos_internos(plan_data, patrones=(r'\b\d-\d\d\b', r'IMG_\d+', r'TXT_\w+')):
    """Ningún campo visible puede llevar códigos del pipeline: el Plan Anual lo lee
    un docente y lo firma una dirección."""
    import re
    hallazgos = []
    for etapa in plan_data['etapas']:
        for u in etapa['unidades']:
            for c in u['clases']:
                for campo in ('tema', 'procedimiento', 'instrumento', 'observacion'):
                    v = c.get(campo, '')
                    for pat in patrones:
                        if re.search(pat, v):
                            hallazgos.append('clase %s · %s' % (c['n'], campo))
    assert not hallazgos, 'códigos internos visibles: %s' % hallazgos
    return True
