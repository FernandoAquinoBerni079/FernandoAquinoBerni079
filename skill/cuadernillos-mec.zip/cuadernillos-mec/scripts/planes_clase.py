# -*- coding: utf-8 -*-
"""planes_clase.py — generador de PLANES DE CLASE (formato canónico V3).

Este archivo es el GENERADOR DE REFERENCIA, tomado de la serie de 26 planes de
Castellano 8.º que validó el estándar (100/100, 0 críticos). Para otra materia se
copia a /home/claude/<materia>/ y se reemplazan `momentos.py` (contenido propio de
cada sesión: inicio/desarrollo/cierre, recursos y criterios) y `fuente_planes.json`
(campos heredados, extraídos del Plan Anual y de las fichas del tomo — NUNCA
transcritos a mano). Los parámetros del encargo se fijan arriba.

Norma completa: references/plan-de-clase.md.
Original de la serie de referencia:
Estándar V2 + tres correcciones (V3):
  §1.8bis  citas del material conservan su registro original (voseo del tomo)
  §1.5bis  unicidad con piso verificable por máquina
  prueba de escala: 26 secciones, encabezado de continuación STYLEREF, pie en todas
"""
import json
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import momentos

DARK, MED, LIGHT, GRIS = '6A3E46', '925663', 'F7EEF0', 'BFBFBF'
W = 17.0
MINUTOS_HORA_CATEDRA = 40           # §1.6: parámetro, no supuesto
HORAS_CATEDRA = 4
TOTAL_MIN = HORAS_CATEDRA * MINUTOS_HORA_CATEDRA
REPARTO = (40, 90, 30)
assert sum(REPARTO) == TOTAL_MIN

FUENTE = json.load(open('fuente_planes.json'))

# --- orden de los 26 planes ---
ORDEN = [str(n) for n in range(1, 16)] + ['E1'] + [str(n) for n in range(16, 25)] + ['E2']
assert len(ORDEN) == 26

doc = Document()

# ---------- estilos ----------
st = doc.styles['Normal']
st.font.name = 'Calibri'; st.font.size = Pt(9.5)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
st.element.rPr.rFonts.set(qn('w:cs'), 'Calibri')
st.paragraph_format.space_after = Pt(3)

from docx.enum.style import WD_STYLE_TYPE
try:
    plan_style = doc.styles['Plan de Clase']
except KeyError:
    plan_style = doc.styles.add_style('Plan de Clase', WD_STYLE_TYPE.PARAGRAPH)
plan_style.base_style = doc.styles['Normal']
plan_style.font.name = 'Calibri'; plan_style.font.size = Pt(14); plan_style.font.bold = True
plan_style.font.color.rgb = RGBColor.from_string(DARK)
pf = plan_style.paragraph_format
pf.space_before = Pt(0); pf.space_after = Pt(6); pf.keep_with_next = True
ppr = plan_style.element.get_or_add_pPr()
ol = OxmlElement('w:outlineLvl'); ol.set(qn('w:val'), '0'); ppr.append(ol)


def _sec_setup(sec):
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin = Cm(1.6); sec.bottom_margin = Cm(1.6)
    sec.left_margin = sec.right_margin = Cm(2.0)
    sec.different_first_page_header_footer = True


def _fld(par, instr, size=8.5, italic=False, color=None):
    for el, attrs in (('w:fldChar', {'w:fldCharType': 'begin'}), ('w:instrText', None),
                      ('w:fldChar', {'w:fldCharType': 'end'})):
        r = OxmlElement('w:r')
        rPr = OxmlElement('w:rPr')
        s = OxmlElement('w:sz'); s.set(qn('w:val'), str(int(size * 2))); rPr.append(s)
        if italic:
            rPr.append(OxmlElement('w:i'))
        if color:
            c = OxmlElement('w:color'); c.set(qn('w:val'), color); rPr.append(c)
        r.append(rPr)
        e = OxmlElement(el)
        if el == 'w:instrText':
            e.set(qn('xml:space'), 'preserve'); e.text = instr
        else:
            for k, v in attrs.items():
                e.set(qn(k), v)
        r.append(e); par._p.append(r)


def _pie(sec):
    """Pie con campos reales en primera página y en las siguientes."""
    for foot in (sec.first_page_footer, sec.footer):
        foot.is_linked_to_previous = False
        par = foot.paragraphs[0]
        par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in list(par.runs):
            r._element.getparent().remove(r._element)
        r = par.add_run('Página '); r.font.size = Pt(8.5)
        _fld(par, ' PAGE ')
        r2 = par.add_run(' de '); r2.font.size = Pt(8.5)
        _fld(par, ' NUMPAGES ')


def _encabezado_continuacion(sec):
    """Primera página sin encabezado; las siguientes, STYLEREF al título del plan."""
    sec.first_page_header.is_linked_to_previous = False
    for p in sec.first_page_header.paragraphs:
        for r in list(p.runs):
            r._element.getparent().remove(r._element)
    hdr = sec.header
    hdr.is_linked_to_previous = False
    par = hdr.paragraphs[0]
    par.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for r in list(par.runs):
        r._element.getparent().remove(r._element)
    _fld(par, ' STYLEREF "Plan de Clase" \\* MERGEFORMAT ', size=8.5, italic=True, color='6A3E46')
    r = par.add_run(' · continuación')
    r.font.size = Pt(8.5); r.italic = True
    r.font.color.rgb = RGBColor.from_string(DARK)


# ---------- helpers de tabla ----------
def shd(cell, fill):
    s = OxmlElement('w:shd'); s.set(qn('w:val'), 'clear')
    s.set(qn('w:color'), 'auto'); s.set(qn('w:fill'), fill)
    cell._tc.get_or_add_tcPr().append(s)


def tabla(filas, cols, anchos, proteger=True):
    t = doc.add_table(rows=filas, cols=cols)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr
    lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
    tw = OxmlElement('w:tblW'); tw.set(qn('w:w'), str(int(sum(anchos) * 567)))
    tw.set(qn('w:type'), 'dxa'); tblPr.append(tw)
    b = OxmlElement('w:tblBorders')
    for e in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement('w:' + e); el.set(qn('w:val'), 'single'); el.set(qn('w:sz'), '4')
        el.set(qn('w:space'), '0'); el.set(qn('w:color'), GRIS); b.append(el)
    tblPr.append(b)
    g = t._tbl.find(qn('w:tblGrid'))
    if g is not None:
        t._tbl.remove(g)
    g = OxmlElement('w:tblGrid')
    for a in anchos:
        gc = OxmlElement('w:gridCol'); gc.set(qn('w:w'), str(int(a * 567))); g.append(gc)
    tblPr.addnext(g)
    for row in t.rows:
        if proteger:
            row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for j, c in enumerate(row.cells):
            c.width = Cm(anchos[j])
    return t


def celda(cell, val, bold=False, blanco=False, size=9.5, center=False, vinetas=False):
    par = cell.paragraphs[0]
    if center:
        par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    items = val if isinstance(val, list) else [val]
    for i, linea in enumerate(items):
        if i:
            par = cell.add_paragraph()
            par.paragraph_format.space_after = Pt(2)
        r = par.add_run(('• ' if vinetas else '') + linea)
        r.bold = bold; r.font.size = Pt(size)
        if blanco:
            r.font.color.rgb = RGBColor.from_string('FFFFFF')


def desproteger(row):
    trPr = row._tr.get_or_add_trPr()
    cs = trPr.find(qn('w:cantSplit'))
    if cs is not None:
        trPr.remove(cs)


# ---------- construcción de un plan ----------
def plan(idx, key, total):
    d = momentos.M[int(key)] if key.isdigit() else momentos.M[key]
    if key.isdigit():
        f = FUENTE[key]
        titulo = f['titulo']; tema = f['tema']; cap = f['capacidad']
        inds = f['indicadores']; proc = f['proc']; inst = f['inst']; unidad = f['unidad']
        if f['ultima']:
            inst = inst + ' Evaluación de la Unidad %d.' % f['unidad_n']
    else:
        titulo = d['titulo']; tema = d['tema']; cap = d['capacidad']
        inds = d['indicadores']; proc = d['proc']; inst = d['inst']; unidad = d['unidad']

    # 1 · título con estilo propio (salto de página al inicio de cada sección)
    p = doc.add_paragraph(style='Plan de Clase')
    p.add_run('Plan de Clase N.º %d — %s' % (idx, titulo))

    # 2 · banda
    t = tabla(1, 1, [W])
    shd(t.rows[0].cells[0], DARK)
    celda(t.rows[0].cells[0],
          'Institución: ______________________________     ·     Plan de Clase N.º %d de %d · 2026' % (idx, total),
          bold=True, blanco=True, size=9.5, center=True)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # 3 · datos
    datos = [('Docente', '______________________________', 'Disciplina', 'Lengua y Literatura Castellana'),
             ('Curso', '8.º grado — EEB, Tercer Ciclo', 'Tiempo', '%d horas cátedra (%d min)' % (HORAS_CATEDRA, TOTAL_MIN)),
             ('Unidad', unidad, 'Sección', '____________'),
             ('Material', ('Tomo del estudiante · Clase %s' % key) if key.isdigit()
              else 'Tomo del estudiante · textos de la etapa, habilitados para consulta',
              'Fecha', '____ / ____ / 2026')]
    t = tabla(len(datos) + 1, 4, [2.4, 6.4, 2.1, 6.1])
    for i, (l1, v1, l2, v2) in enumerate(datos):
        c = t.rows[i].cells
        shd(c[0], MED); celda(c[0], l1, bold=True, blanco=True)
        celda(c[1], v1)
        shd(c[2], MED); celda(c[2], l2, bold=True, blanco=True)
        celda(c[3], v2)
    fr = t.rows[len(datos)]
    shd(fr.cells[0], MED); celda(fr.cells[0], 'Tema', bold=True, blanco=True)
    celda(fr.cells[1].merge(fr.cells[3]), tema)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # 4 · capacidad e indicadores
    t = tabla(2, 2, [3.4, 13.6])
    shd(t.rows[0].cells[0], MED); celda(t.rows[0].cells[0], 'Capacidad', bold=True, blanco=True)
    celda(t.rows[0].cells[1], cap)
    shd(t.rows[1].cells[0], MED); celda(t.rows[1].cells[0], ['Indicadores', 'de logro'], bold=True, blanco=True)
    celda(t.rows[1].cells[1], inds, vinetas=True)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # 5 · momentos (encabezado con tblHeader + keepNext; Desarrollo divisible)
    t = tabla(4, 3, [2.2, 12.7, 2.1])
    for j, hh in enumerate(('MOMENTO', 'ACTIVIDADES', 'TIEMPO')):
        shd(t.rows[0].cells[j], DARK)
        celda(t.rows[0].cells[j], hh, bold=True, blanco=True, center=(j != 1))
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    for c in t.rows[0].cells:
        for par in c.paragraphs:
            par.paragraph_format.keep_with_next = True
    for i, (nombre, bloques, mins) in enumerate(
            (('Inicio', d['inicio'], REPARTO[0]),
             ('Desarrollo', d['desarrollo'], REPARTO[1]),
             ('Cierre', d['cierre'], REPARTO[2])), 1):
        c = t.rows[i].cells
        shd(c[0], LIGHT); celda(c[0], nombre, bold=True)
        celda(c[1], bloques, vinetas=True)
        celda(c[2], '%d min' % mins, center=True)
    desproteger(t.rows[2])          # §1.13: cantSplit selectivo
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # 6 · recursos
    t = tabla(1, 2, [3.4, 13.6])
    shd(t.rows[0].cells[0], MED)
    celda(t.rows[0].cells[0], ['Recursos y medios', 'auxiliares'], bold=True, blanco=True)
    celda(t.rows[0].cells[1], d['recursos'])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # 7 · evaluación
    t = tabla(4, 2, [3.4, 13.6])
    fb = t.rows[0].cells[0].merge(t.rows[0].cells[1])
    shd(fb, DARK); celda(fb, 'EVALUACIÓN', bold=True, blanco=True, center=True, size=10)
    for i, (l, v, vin) in enumerate((('Procedimientos', proc, False),
                                     ('Instrumentos', inst, False),
                                     ('Criterios', d['criterios'], True)), 1):
        shd(t.rows[i].cells[0], MED)
        celda(t.rows[i].cells[0], l, bold=True, blanco=True)
        celda(t.rows[i].cells[1], v, vinetas=vin)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # 8 · observaciones
    po = doc.add_paragraph()
    r = po.add_run('Observaciones: '); r.bold = True; r.font.size = Pt(9.5)
    r2 = po.add_run('_' * 74); r2.font.size = Pt(9.5)

    # 9 · firmas
    t = tabla(1, 2, [8.5, 8.5])
    celda(t.rows[0].cells[0], ['____________________________', 'Docente'], center=True)
    celda(t.rows[0].cells[1], ['____________________________', 'Dirección — Visto bueno'], center=True)


# ---------- portada ----------
_sec_setup(doc.sections[0])
t = tabla(1, 1, [W])
shd(t.rows[0].cells[0], DARK)
celda(t.rows[0].cells[0], ['', 'PLANES DE CLASE', 'Lengua y Literatura Castellana · 8.º grado', ''],
      bold=True, blanco=True, size=18, center=True)
doc.add_paragraph()
for txt, sz, bold in (('Educación Escolar Básica · Tercer Ciclo', 11.5, True),
                      ('Programa de Estudio del Ministerio de Educación y Ciencias', 10, False),
                      ('Carga horaria: 4 horas cátedra semanales', 10, False),
                      ('26 planes de clase · 7 unidades · 24 clases y 2 evaluaciones de etapa', 10, False),
                      ('Institución: ______________________________', 10, False),
                      ('Docente: ______________________________', 10, False),
                      ('', 10, False),
                      ('República del Paraguay · 2026', 11, True)):
    par = doc.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = par.add_run(txt); r.font.size = Pt(sz); r.bold = bold

# índice
par = doc.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = par.add_run('Índice'); r.bold = True; r.font.size = Pt(14)
r.font.color.rgb = RGBColor.from_string(DARK)
# Sin leyenda «Ctrl+E / F9» (protocolo 2026 §4.3): después de generar, el índice se puebla
# con scripts/indice_pdf.py (construir() + actualizar() sobre el PDF).
p = doc.add_paragraph()
fld = OxmlElement('w:fldSimple')
fld.set(qn('w:instr'), 'TOC \\o "1-1" \\h \\z \\u')
run = OxmlElement('w:r'); tx = OxmlElement('w:t')
tx.text = 'ÍNDICE PENDIENTE: correr scripts/indice_pdf.py'
run.append(tx); fld.append(run)
p._p.append(fld)
_pie(doc.sections[0])
doc.sections[0].first_page_header.is_linked_to_previous = False
doc.sections[0].header.is_linked_to_previous = False

# ---------- 26 secciones, una por plan ----------
for i, key in enumerate(ORDEN, 1):
    sec = doc.add_section(WD_SECTION.NEW_PAGE)
    _sec_setup(sec)
    _pie(sec)
    _encabezado_continuacion(sec)
    plan(i, key, len(ORDEN))

# ---------- settings ----------
settings = doc.settings.element
if settings.find(qn('w:updateFields')) is None:
    el = OxmlElement('w:updateFields'); el.set(qn('w:val'), 'true')
    compat = settings.find(qn('w:compat'))
    (compat.addprevious(el) if compat is not None else settings.append(el))

doc.save('Lengua_y_Literatura_Castellana_8vo_Grado_PLANES_DE_CLASE.docx')
print('PLANES OK · %d planes · %d secciones' % (len(ORDEN), len(doc.sections)))
