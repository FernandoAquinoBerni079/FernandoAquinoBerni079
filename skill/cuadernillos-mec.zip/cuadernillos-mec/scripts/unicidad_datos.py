# -*- coding: utf-8 -*-
"""unicidad_datos.py — control de datos repetidos (protocolo 2026 §3quater: «todo dato
repetido es un fallo de auditoría»).

Hay dos controles complementarios:

1. operaciones_repetidas(texto): extrae las operaciones binarias o decimales
   «a ⊕ b» (+ − × ÷) de una unidad entera (explicación, ejemplos, actividades, prácticas,
   evaluaciones) y señala los pares que COMPARTEN 2 O MÁS de sus tres números
   {a, b, resultado}. Detecta:
   - operandos reutilizados (1011 + 110 en el ejemplo y 1011 − 110 en una actividad);
   - operaciones inversas (101 × 11 = 1111 en el ejemplo y 1111 ÷ 101 en una actividad);
   - el mismo par de operandos con otra operación.
   Excepción legítima: los productos parciales de un mismo ejemplo resuelto
   (101 × 11 = 101 + 1010). Se pasan en `mismo_ejemplo` después de mirar el texto.
   Antes de escribir una operación nueva, se valida el candidato contra TODAS las de la
   unidad con `choca(candidato, existentes)`.

2. firmas_repetidas(bloques): firma numérica (multiconjunto de cifras con unidad: «480 GB»,
   «₲ 280.000», «1 TB») de cada ejemplo, actividad, práctica, ficha y evaluación. Dos
   bloques que comparten dos o más datos con unidad son sospechosos. Así se encontró el
   SSD 480 GB / HDD 1 TB repetido entre el ejemplo de la Clase 7, la Actividad 11 y la
   Integradora. Ojo: un dato que el auditor proponga como reemplazo también se valida, porque
   puede chocar con otro bloque (por ejemplo, «2 TB» ya estaba en la Ficha A).

Validado en Software 1.er Curso, Unidad 3 (oct-2026): encontró los 3 casos del auditor y 4
más que nadie había visto.
"""
import itertools, re

OPS = {'+': lambda a, b: a + b, '−': lambda a, b: a - b, '-': lambda a, b: a - b,
       '×': lambda a, b: a * b, '÷': lambda a, b: a // b}

def numeros(op):
    a, o, b = op
    return {a, b, OPS[o](a, b)}

def operaciones(texto, base=2):
    pat = r'\b([01]{2,})\s*([+−×÷])\s*([01]{2,})\b' if base == 2 else \
          r'\b(\d+)\s*([+−×÷])\s*(\d+)\b'
    vistos = []
    for a, o, b in re.findall(pat, texto):
        t = (int(a, base), o, int(b, base))
        if t not in vistos:
            vistos.append(t)
    return vistos

def choca(cand, existentes, minimo=2):
    return [e for e in existentes if e != cand and len(numeros(cand) & numeros(e)) >= minimo]

def operaciones_repetidas(texto, base=2, mismo_ejemplo=()):
    ops = operaciones(texto, base); exc = {frozenset(x) for x in mismo_ejemplo}; out = []
    for x, y in itertools.combinations(ops, 2):
        comp = numeros(x) & numeros(y)
        if len(comp) >= 2 and frozenset({x, y}) not in exc:
            out.append((x, y, sorted(comp)))
    return out

DATO = r'(?:₲\s?[\d.]+|\d+(?:[.,]\d+)?\s?(?:GB|GiB|TB|TiB|MB|MiB|KiB|kB|ms|%))'

def firmas_repetidas(bloques, minimo=2):
    """bloques = {'Clase 7 · ejemplo': texto, 'Clase 7 · act 11': texto, …}"""
    f = {k: set(re.sub(r'\s', '', m) for m in re.findall(DATO, v)) for k, v in bloques.items()}
    return [(a, b, sorted(f[a] & f[b])) for a, b in itertools.combinations(f, 2)
            if len(f[a] & f[b]) >= minimo]
