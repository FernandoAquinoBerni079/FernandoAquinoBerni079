# -*- coding: utf-8 -*-
"""paginacion.py — render, medición de ocupación y ajuste de páginas casi vacías.

    from paginacion import render, ocupacion, corregir_paginas
    pdf = render('TOMO.docx')                       # LibreOffice headless → PDF
    occ = ocupacion(pdf)                            # [(fracción_ocupada, primera_línea), …]
    final = corregir_paginas('TOMO.docx', 'TOMO_pag')   # ciclo hasta 0 páginas < 25 %

Validado en Software 1.er Curso (oct-2026): 137 → 107 páginas en oficio, 0 casi vacías.

Requisitos del contenedor: libreoffice-writer + fonts-crosextra-carlito +
fonts-crosextra-caladea (métricas de Calibri y Cambria). Sin el Writer, soffice responde
«source file could not be loaded»; sin las fuentes, la paginación no se parece a la de Word.

Criterio: una página interior es «casi vacía» si su último renglón de texto (sin contar el
pie «Página X de Y») queda por encima del 25 % del alto. La portada y la contraportada
(imagen sin texto) se excluyen.

Corrección, en este orden (lo que ya hace helpers.finalizar() para los tomos nuevos):
1. saltos_robustos() — saltos en párrafos vacíos → «salto de página antes».
2. subtitulos_keep_next() — subtítulos de actividades pegados a su primer ítem.
3. Ajuste por BLOQUE (de un título «Clase N —»/«Práctica N —»/«Ficha X —» hasta el salto
   siguiente): se baja el espacio entre párrafos sólo en ese bloque, en tres niveles.
   Nunca se toca la tipografía.
4. Si con el nivel máximo no alcanza: se achica UNA figura del bloque (sólo su tamaño en la
   página; la imagen no se recomprime ni se recorta, protocolo 2026 §3ter). Es manual.
"""
import os, re, shutil, subprocess, sys
import docx
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

LO_HOME = '/tmp/lo'
NIVELES = [(60, 60), (30, 40), (0, 20)]          # (after, before máx) en twips
CABEZAS = r'^((Clase|Práctica|Ficha) [0-9A-Z]+ —|EVALUACI[ÓO]N[^\n]*|UNIDAD \d+ —)'

def render(ruta_docx, outdir=None):
    os.makedirs(LO_HOME, exist_ok=True)
    outdir = outdir or os.path.dirname(os.path.abspath(ruta_docx))
    subprocess.run(['soffice', '--headless', '--norestore', '--convert-to', 'pdf',
                    '--outdir', outdir, ruta_docx], env=dict(os.environ, HOME=LO_HOME),
                   capture_output=True, timeout=900)
    pdf = os.path.join(outdir, os.path.basename(ruta_docx).rsplit('.', 1)[0] + '.pdf')
    if not os.path.exists(pdf):
        raise RuntimeError('LibreOffice no generó el PDF: ¿falta libreoffice-writer?')
    return pdf

def ocupacion(pdf):
    out = subprocess.run(['pdftotext', '-bbox-layout', pdf, '-'], capture_output=True,
                         text=True).stdout
    res = []
    for pg in re.split(r'<page ', out)[1:]:
        H = float(re.search(r'height="([\d.]+)"', pg).group(1)); ys = []; prim = ''
        for m in re.finditer(r'<line xMin="[\d.]+" yMin="[\d.]+" xMax="[\d.]+" '
                             r'yMax="([\d.]+)">(.*?)</line>', pg, re.S):
            t = ' '.join(re.findall(r'>([^<]*)</word>', m.group(2)))
            if re.match(r'Página \d+ de \d+', t):
                continue
            ys.append(float(m.group(1))); prim = prim or t
        res.append((max(ys) / H if ys else 0.0, prim))
    return res

def casi_vacias(pdf, umbral=0.25, inicio=r'^UNIDAD 1\b'):
    """Desde la primera página de la Unidad 1: la presentación y el índice pueden ser
    cortos por naturaleza y se revisan a ojo."""
    r = ocupacion(pdf); desde = 1
    for k in range(len(r)):
        t = subprocess.run(['pdftotext', '-f', str(k + 1), '-l', str(k + 1), pdf, '-'],
                           capture_output=True, text=True).stdout
        if re.search(inicio, t, re.M) and 'Índice' not in t:
            desde = k; break
    return [(i + 1, round(f, 2)) for i, (f, _) in enumerate(r)
            if desde <= i < len(r) - 1 and i > 0 and 0 < f < umbral]

def _texto(el):
    return ''.join(t.text or '' for t in el.iter(qn('w:t')))

def _es_salto(el):
    x = el.xml if el.tag == qn('w:p') else ''
    return 'w:type="page"' in x or 'pageBreakBefore' in x

def _apretar(p, after, before):
    pr = p.find(qn('w:pPr'))
    if pr is None:
        pr = OxmlElement('w:pPr'); p.insert(0, pr)
    sp = pr.find(qn('w:spacing'))
    if sp is None:
        sp = OxmlElement('w:spacing'); ancla = None
        for tag in ('w:ind', 'w:contextualSpacing', 'w:jc', 'w:outlineLvl', 'w:rPr', 'w:sectPr'):
            ancla = pr.find(qn(tag))
            if ancla is not None:
                break
        (ancla.addprevious(sp) if ancla is not None else pr.append(sp))
    a, b = sp.get(qn('w:after')), sp.get(qn('w:before'))
    if a is None or int(a) > after:
        sp.set(qn('w:after'), str(after))
    if b is not None and int(b) > before:
        sp.set(qn('w:before'), str(before))

def apretar_bloques(src, dst, plan, saltar_primeros=60):
    """plan = {'Práctica 4 —': nivel, …}. Ajusta sólo el bloque de cada título."""
    d = docx.Document(src); ch = list(d.element.body.iterchildren())
    for cabeza, nivel in plan.items():
        idx = [i for i, el in enumerate(ch) if i > saltar_primeros and
               _texto(el).strip().startswith(cabeza)]
        if not idx:
            raise ValueError('no encuentro el bloque ' + cabeza)
        i = idx[0]; j = i + 1
        while j < len(ch) and not _es_salto(ch[j]):
            j += 1
        after, before = NIVELES[nivel]
        for el in ch[i:j]:
            for p in ([el] if el.tag == qn('w:p') else list(el.iter(qn('w:p')))):
                _apretar(p, after, before)
    d.save(dst)

def _bloque_de(pdf, pagina):
    for j in range(pagina, max(0, pagina - 8), -1):
        t = subprocess.run(['pdftotext', '-f', str(j), '-l', str(j), pdf, '-'],
                           capture_output=True, text=True).stdout
        m = re.search(CABEZAS, t, re.M)
        if m:
            return m.group(1)

def corregir_paginas(src, base, max_iter=5, umbral=0.25):
    plan = {}; cur = src
    for it in range(max_iter):
        pdf = render(cur); malas = casi_vacias(pdf, umbral)
        print('iteración', it, 'páginas', len(ocupacion(pdf)), 'casi vacías', malas)
        if not malas:
            return cur, pdf, plan
        for pag, _ in malas:
            cab = _bloque_de(pdf, pag)
            if not cab:
                continue
            k = cab.split(' —')[0] + ' —' if '—' in cab else cab
            if plan.get(k, -1) + 1 < len(NIVELES):
                plan[k] = plan.get(k, -1) + 1
            else:
                print('  sin margen de espaciado en', k, '→ achicar una figura del bloque')
        cur = '%s_%d.docx' % (base, it)
        apretar_bloques(src, cur, plan)
    return cur, render(cur), plan

if __name__ == '__main__':
    print(corregir_paginas(sys.argv[1], sys.argv[2]))
