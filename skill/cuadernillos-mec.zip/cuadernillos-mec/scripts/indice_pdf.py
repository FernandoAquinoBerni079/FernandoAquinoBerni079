# -*- coding: utf-8 -*-
"""indice_pdf.py — índice POBLADO con la página real del PDF (protocolo 2026 §4.3).

    python3 indice_pdf.py TOMO.docx TOMO.pdf TOMO_con_indice.docx

Si el .docx ya trae entradas de índice (estilos TDC1/TDC2 o toc 1/toc 2, como queda después
de un F9 en Word), reescribe sólo el número de página de cada entrada. El número sale de la
primera página, posterior al índice, donde aparece el título.

Si el .docx viene del pipeline (helpers.indice_toc(): campo TOC sin entradas), primero
`construir()` arma las entradas a partir de los títulos de nivel 1 y 2, con estilos TDC1 y
TDC2, tabulación derecha con puntos y número provisorio «0». Después se renderiza y se
corre `actualizar()`:

    construir('TOMO.docx', 'TOMO_i.docx'); pdf = paginacion.render('TOMO_i.docx')
    actualizar('TOMO_i.docx', pdf, 'TOMO_final.docx')   # y de nuevo, hasta «cambiadas 0»

Las evaluaciones tienen un título distinto en el cuerpo («EVALUACIÓN DE LA UNIDAD 3»,
«EVALUACIÓN INTEGRADORA · 2.ª ETAPA») y por eso se buscan con alias.

Después: volver a renderizar y correr de nuevo el script. Tiene que informar
«cambiadas 0»; si no, la paginación cambió con los números nuevos y se repite.
"""
import re, subprocess, sys
import docx
from docx.oxml.ns import qn

norm = lambda s: re.sub(r'\s+', ' ', s).strip().casefold()

def paginas(pdf):
    n = int(re.search(r'Pages:\s+(\d+)', subprocess.run(['pdfinfo', pdf], capture_output=True,
                                                         text=True).stdout).group(1))
    return [subprocess.run(['pdftotext', '-f', str(i), '-l', str(i), pdf, '-'],
                           capture_output=True, text=True).stdout for i in range(1, n + 1)]

def _alias(key):
    c = [key]
    m = re.match(r'evaluación de la unidad (\d+)', key)
    if m: c.append('evaluación de la unidad %s' % m.group(1))
    m = re.match(r'evaluación integradora de la (\S+) etapa', key)
    if m: c.append('evaluación integradora · %s etapa' % m.group(1))
    if key.startswith('prueba diagnóstica'): c.append('prueba diagnóstica')
    return c

def construir(docx_in, docx_out, ancho_util_cm=19.05):
    from docx.enum.style import WD_STYLE_TYPE
    from docx.enum.text import WD_TAB_ALIGNMENT, WD_TAB_LEADER
    from docx.shared import Cm, Pt
    d = docx.Document(docx_in)
    campo = next((p for p in d.paragraphs if p._p.find(qn('w:fldSimple')) is not None and
                  'TOC' in p._p.find(qn('w:fldSimple')).get(qn('w:instr'), '')), None)
    if campo is None:
        raise SystemExit('No hay campo TOC para reemplazar.')
    for nivel in (1, 2):
        nombre = 'TDC%d' % nivel
        if nombre not in [s.name for s in d.styles]:
            st = d.styles.add_style(nombre, WD_STYLE_TYPE.PARAGRAPH)
            st.font.size = Pt(10.5 if nivel == 1 else 10); st.font.bold = (nivel == 1)
            st.paragraph_format.left_indent = Cm(0 if nivel == 1 else 0.6)
            st.paragraph_format.space_after = Pt(2)
            st.paragraph_format.tab_stops.add_tab_stop(Cm(ancho_util_cm), WD_TAB_ALIGNMENT.RIGHT,
                                                       WD_TAB_LEADER.DOTS)
    def nivel(p):
        if p.style.name in ('Heading 1', 'Heading 2'):
            return int(p.style.name[-1])
        for pr in (p._p.pPr, p.style.element.pPr if p.style is not None else None):
            ol = pr.find(qn('w:outlineLvl')) if pr is not None else None
            if ol is not None and ol.get(qn('w:val')) in ('0', '1'):
                return int(ol.get(qn('w:val'))) + 1        # p. ej. estilo «Plan de Clase»
        return None
    heads = [(nivel(p), p.text.strip()) for p in d.paragraphs
             if nivel(p) and p.text.strip() and p.text.strip() not in ('Índice', 'Presentación')]
    ancla = campo
    for nivel, texto in heads:
        q = d.add_paragraph(style='TDC%d' % nivel)
        q.add_run(texto); q.add_run('\t'); q.add_run('0')
        ancla._p.addnext(q._p); ancla = q
    campo._p.getparent().remove(campo._p)
    d.save(docx_out)
    return len(heads)

def actualizar(docx_in, pdf, docx_out):
    P = paginas(pdf); d = docx.Document(docx_in)
    toc = [p for p in d.element.body.iter(qn('w:p'))
           if p.find(qn('w:pPr') + '/' + qn('w:pStyle')) is not None and
           p.find(qn('w:pPr') + '/' + qn('w:pStyle')).get(qn('w:val')).lower().startswith(('tdc', 'toc'))]
    if not toc:
        raise SystemExit('El .docx no tiene entradas de índice: corré antes construir().')
    ini = max(i for i, t in enumerate(P[:8]) if 'Índice' in t) + 1
    desde = ini; filas = []; cambios = 0
    for p in toc:
        ts = list(p.iter(qn('w:t'))); titulo = ''.join(t.text for t in ts[:-1]).strip()
        num = ts[-1]; cands = _alias(norm(titulo)); hallada = None
        for i in range(desde, len(P)):
            lineas = [norm(l) for l in P[i].splitlines() if l.strip()]
            if any(l.startswith(c) for c in cands for l in lineas):
                hallada = i + 1; break
        if hallada is None:
            raise SystemExit('No encuentro en el PDF: ' + titulo)
        cambios += num.text.strip() != str(hallada)
        num.text = str(hallada); filas.append((hallada, titulo))
        if not norm(titulo).startswith('unidad'):
            desde = hallada - 1
    d.save(docx_out)
    return filas, cambios

if __name__ == '__main__':
    f, c = actualizar(*sys.argv[1:4])
    print('entradas', len(f), '· cambiadas', c)
