# -*- coding: utf-8 -*-
"""deconflicto_color.py — distancia CIEDE2000 de una identidad nueva contra TODO el
catálogo del inventario maestro. Correr SIEMPRE antes de la portada de una materia nueva."""
import json, math, re

def hex2lab(h):
    r,g,b = (int(h[i:i+2],16)/255 for i in (0,2,4))
    def f(c): return ((c+0.055)/1.055)**2.4 if c>0.04045 else c/12.92
    r,g,b = f(r),f(g),f(b)
    X = r*0.4124+g*0.3576+b*0.1805; Y = r*0.2126+g*0.7152+b*0.0722; Z = r*0.0193+g*0.1192+b*0.9505
    Xn,Yn,Zn = 0.95047,1.0,1.08883
    def g2(t): return t**(1/3) if t>0.008856 else 7.787*t+16/116
    fx,fy,fz = g2(X/Xn),g2(Y/Yn),g2(Z/Zn)
    return (116*fy-16, 500*(fx-fy), 200*(fy-fz))

def ciede2000(l1,l2):
    L1,a1,b1 = l1; L2,a2,b2 = l2
    C1 = math.hypot(a1,b1); C2 = math.hypot(a2,b2); Cb = (C1+C2)/2
    G = 0.5*(1-math.sqrt(Cb**7/(Cb**7+25**7)))
    a1p, a2p = (1+G)*a1, (1+G)*a2
    C1p, C2p = math.hypot(a1p,b1), math.hypot(a2p,b2)
    h1p = math.degrees(math.atan2(b1,a1p))%360 if (a1p or b1) else 0
    h2p = math.degrees(math.atan2(b2,a2p))%360 if (a2p or b2) else 0
    dL = L2-L1; dC = C2p-C1p
    if C1p*C2p==0: dh=0
    elif abs(h2p-h1p)<=180: dh=h2p-h1p
    elif h2p-h1p>180: dh=h2p-h1p-360
    else: dh=h2p-h1p+360
    dH = 2*math.sqrt(C1p*C2p)*math.sin(math.radians(dh/2))
    Lb=(L1+L2)/2; Cbp=(C1p+C2p)/2
    if C1p*C2p==0: hbp=h1p+h2p
    elif abs(h1p-h2p)<=180: hbp=(h1p+h2p)/2
    elif h1p+h2p<360: hbp=(h1p+h2p+360)/2
    else: hbp=(h1p+h2p-360)/2
    T = 1-0.17*math.cos(math.radians(hbp-30))+0.24*math.cos(math.radians(2*hbp))+0.32*math.cos(math.radians(3*hbp+6))-0.20*math.cos(math.radians(4*hbp-63))
    Sl = 1+0.015*(Lb-50)**2/math.sqrt(20+(Lb-50)**2)
    Sc = 1+0.045*Cbp; Sh = 1+0.015*Cbp*T
    dTh = 30*math.exp(-((hbp-275)/25)**2)
    Rc = 2*math.sqrt(Cbp**7/(Cbp**7+25**7)); Rt = -Rc*math.sin(math.radians(2*dTh))
    return math.sqrt((dL/Sl)**2+(dC/Sc)**2+(dH/Sh)**2+Rt*(dC/Sc)*(dH/Sh))

def contraste_blanco(h):
    def lin(c): c=c/255; return ((c+0.055)/1.055)**2.4 if c>0.04045 else c/12.92
    r,g,b = int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
    L = 0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b)
    return (1.05)/(L+0.05)


# ---------------- API de la skill ----------------

def catalogo(inventario, hoja='Inventario', col_identidad=4, col_obs=10,
             col_materia=1, col_curso=2):
    """Extrae {hex: 'Materia Curso'} de TODOS los tonos del inventario maestro,
    más las bandas fijas de evaluación."""
    import openpyxl
    wb = openpyxl.load_workbook(inventario, data_only=True)
    ws = wb[hoja]
    cat = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        ident = '%s %s' % (row[col_identidad] or '', row[col_obs] or '')
        nombre = ('%s %s' % (str(row[col_materia] or '')[:22],
                             str(row[col_curso] or '')[:6])).strip()
        for h in re.findall(r'#([0-9A-Fa-f]{6})', ident):
            cat.setdefault(h.upper(), nombre)
    cat['B8860B'] = 'BANDA ámbar (evaluación de unidad)'
    cat['1B4F72'] = 'BANDA azul (evaluación de etapa)'
    return cat


def verificar(cat, tonos, mochila=(), n=5):
    """Para cada tono: ΔE CIEDE2000 contra todo el catálogo, contra la mochila del
    curso (los tonos que conviven en la misma cartuchera del estudiante) y
    contraste con blanco. Devuelve un informe para mostrarle a Fer."""
    labs = {h: hex2lab(h) for h in cat}
    ml = [hex2lab(m.lstrip('#').upper()) for m in mochila]
    salida = []
    for t in tonos:
        h = t.lstrip('#').upper()
        lab = hex2lab(h)
        vecinos = sorted((ciede2000(lab, labs[k]), k, cat[k]) for k in cat)[:n]
        d_mochila = min((ciede2000(lab, m) for m in ml), default=None)
        salida.append(dict(tono='#' + h, contraste_blanco=contraste_blanco(h),
                           delta_min=vecinos[0][0], vecinos=vecinos,
                           delta_mochila=d_mochila))
    return salida


def buscar(cat, hue_min, hue_max, L_min=20, L_max=45, C_min=15,
           contraste_min=7.0, delta_min=8.0, paso=4, top=15):
    """Propone tonos DARK de una familia de matiz (hue Lab en grados) que estén a
    ΔE >= delta_min de TODO el catálogo y con contraste suficiente con blanco."""
    labs = {h: hex2lab(h) for h in cat}
    out = []
    for r in range(0, 256, paso):
        for g in range(0, 256, paso):
            for b in range(0, 256, paso):
                h = '%02X%02X%02X' % (r, g, b)
                if contraste_blanco(h) < contraste_min:
                    continue
                L, a, bb = hex2lab(h)
                C = math.hypot(a, bb)
                hue = math.degrees(math.atan2(bb, a)) % 360
                if not (L_min <= L <= L_max and C >= C_min):
                    continue
                dentro = (hue_min <= hue <= hue_max) if hue_min <= hue_max else (hue >= hue_min or hue <= hue_max)
                if not dentro:
                    continue
                d = min(ciede2000((L, a, bb), labs[k]) for k in cat)
                if d >= delta_min:
                    out.append(dict(tono='#' + h, delta_min=d, L=L, C=C, hue=hue,
                                    contraste=contraste_blanco(h)))
    out.sort(key=lambda x: -x['delta_min'])
    return out[:top]


def serie(cat, hue_min, hue_max, franjas, delta_mutuo=5.5, **kw):
    """Serie de tonos graduados (p. ej. 7.º / 8.º / 9.º de una misma familia):
    franjas = [(L_min, L_max), ...] de claro a oscuro."""
    import itertools
    cands = [buscar(cat, hue_min, hue_max, L_min=a, L_max=b, top=10, **kw) for a, b in franjas]
    mejor = None
    for combo in itertools.product(*cands):
        labs = [hex2lab(c['tono'].lstrip('#')) for c in combo]
        mutuos = [ciede2000(labs[i], labs[i + 1]) for i in range(len(labs) - 1)]
        if min(mutuos) < delta_mutuo:
            continue
        score = min(c['delta_min'] for c in combo) + 0.2 * min(mutuos)
        if mejor is None or score > mejor[0]:
            mejor = (score, combo, mutuos)
    return None if mejor is None else dict(serie=mejor[1], delta_mutuos=mejor[2])


def paleta(dark, med=None, soft=None, light=None):
    """Devuelve la paleta de 4 tonos lista para set_identidad()."""
    return dict(DARK=dark.lstrip('#').upper(),
                MED=(med or '').lstrip('#').upper() or None,
                SOFT=(soft or '').lstrip('#').upper() or None,
                LIGHT=(light or '').lstrip('#').upper() or None)
