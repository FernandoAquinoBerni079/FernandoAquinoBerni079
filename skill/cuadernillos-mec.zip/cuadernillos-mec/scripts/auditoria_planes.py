# -*- coding: utf-8 -*-
"""auditoria_planes.py — auditoría de liberación sobre los 26 planes.
Áreas A(20) B(30) C(30) D(20). Un fallo crítico invalida la entrega."""
import json, re, subprocess, sys, zipfile
from docx import Document
from docx.oxml.ns import qn
import momentos

F = 'Lengua_y_Literatura_Castellana_8vo_Grado_PLANES_DE_CLASE.docx'
PDF = F.replace('.docx', '.pdf')
FUENTE = json.load(open('fuente_planes.json'))
ORDEN = [str(n) for n in range(1, 16)] + ['E1'] + [str(n) for n in range(16, 25)] + ['E2']

R = []
def chk(area, nombre, cond, critico=False, detalle=''):
    R.append((area, nombre, bool(cond), critico, detalle))

d = Document(F); z = zipfile.ZipFile(F)
x = z.read('word/document.xml').decode()
texto = re.sub(r'<[^>]+>', '', re.sub('</w:p>', '\n', x))
lineas = [l.strip() for l in texto.split('\n')]

# ================= A · INTEGRIDAD DOCUMENTAL (20) =================
titulos = re.findall(r'Plan de Clase N\.º (\d+) — ', texto)
nums = [int(n) for n in titulos]
propios = sorted(set(n for n in nums))
chk('A', '26 planes con título propio', propios == list(range(1, 27)), True, str(len(propios)))
chk('A', 'numeración correlativa sin saltos', nums[:26] == list(range(1, 27)) or propios == list(range(1, 27)), True)
chk('A', 'banda «de 26» en los 26 planes', texto.count('de 26 · 2026') == 26, True, str(texto.count('de 26 · 2026')))
for b in ('Capacidad', 'Indicadores', 'MOMENTO', 'ACTIVIDADES', 'TIEMPO', 'Recursos y medios',
          'EVALUACIÓN', 'Procedimientos', 'Instrumentos', 'Criterios', 'Observaciones:', 'Visto bueno'):
    chk('A', 'bloque presente 26 veces: ' + b,
        (texto.count(b) >= 26 if b != 'Observaciones:' else texto.count(b) == 26), True,
        str(texto.count(b)))
chk('A', 'versión comercial: institución/docente/fecha/sección en blanco',
    texto.count('Institución: ______') == 27 and texto.count('____ / ____ / 2026') == 26, False)
chk('A', 'perfil EEB coherente en los 26', texto.count('8.º grado — EEB, Tercer Ciclo') == 26, False)
chk('A', '2 planes propios de evaluación de etapa',
    texto.count('Evaluación de la Primera Etapa') >= 1 and texto.count('Evaluación de la Segunda Etapa') >= 1, True)

# ================= B · COHERENCIA CURRICULAR Y TRAZABILIDAD (30) =================
# derivación verbatim contra Plan Anual y tomo
def txt_de(f):
    xx = zipfile.ZipFile(f).read('word/document.xml').decode()
    return re.sub(r'<[^>]+>', '', re.sub('</w:p>', '\n', xx))
PA = txt_de('Lengua_y_Literatura_Castellana_8vo_Grado_PLAN_ANUAL.docx')
TO = txt_de('Lengua_y_Literatura_Castellana_8vo_Grado_TOMO_COMPLETO.docx')
fallos_der = []
for k in [str(n) for n in range(1, 25)]:
    f = FUENTE[k]
    for nom, val, src in (('tema', f['tema'], PA), ('proc', f['proc'], PA),
                          ('inst', f['inst'], PA), ('cap', f['capacidad'], TO)):
        if val not in texto or val not in src:
            fallos_der.append('C%s/%s' % (k, nom))
    for ind in f['indicadores']:
        if ind not in texto or ind not in PA:
            fallos_der.append('C%s/ind' % k)
chk('B', 'derivación verbatim de las 24 clases (tema, indicadores, proc, inst, capacidad)',
    not fallos_der, True, ', '.join(fallos_der[:5]))
# trazabilidad: cada plan tiene ≥2 indicadores y ≥2 criterios
sin_traza = []
for k in ORDEN:
    d_ = momentos.M[int(k)] if k.isdigit() else momentos.M[k]
    inds = FUENTE[k]['indicadores'] if k.isdigit() else d_['indicadores']
    if len(inds) < 2 or len(d_['criterios']) < 2:
        sin_traza.append(k)
chk('B', 'cadena indicador→criterio: ≥2 indicadores y ≥2 criterios por plan', not sin_traza, True, str(sin_traza))
# instrumento de evaluación de unidad en las 7 clases de cierre
cierres = [n for n, f in FUENTE.items() if f['ultima']]
falt = [n for n in cierres if ('Evaluación de la Unidad %d.' % FUENTE[n]['unidad_n']) not in texto]
chk('B', 'evaluación de unidad como instrumento en las 7 clases de cierre', not falt, True, str(falt))
# sin residuos de otras materias/cursos
residuos = ['Matemática', 'Química', 'Antropología', 'Yegros', 'Dibujo Técnico', '7.º grado', '9.º grado', 'Karumbé']
hall = [r for r in residuos if r in texto]
chk('B', 'sin residuos de otro curso o materia', not hall, True, str(hall))
# recursos referidos existen: toda figura citada existe en el tomo
figs = set(re.findall(r'figura (\d\.\d+)', texto))
inexistentes = [f for f in figs if ('Figura %s —' % f) not in TO]
chk('B', 'las figuras citadas existen en el tomo', not inexistentes, True, str(inexistentes))
chk('B', 'sin códigos internos visibles', not re.findall(r'\b8-\d\d\b', texto), True)

# ================= C · CALIDAD PEDAGÓGICA (30) =================
# tiempos: suma y viabilidad
chk('C', 'suma de tiempos = tiempo declarado en los 26 planes',
    texto.count('4 horas cátedra (160 min)') == 26 and texto.count('40 min') == 26
    and texto.count('90 min') == 26 and texto.count('30 min') == 26, True)
# viabilidad: nº de actividades por momento dentro de rango
sobrecargados = []
for k in ORDEN:
    d_ = momentos.M[int(k)] if k.isdigit() else momentos.M[k]
    if not (1 <= len(d_['inicio']) <= 3 and 3 <= len(d_['desarrollo']) <= 5 and 2 <= len(d_['cierre']) <= 3):
        sobrecargados.append(k)
chk('C', 'viabilidad temporal: densidad de actividades por momento', not sobrecargados, False, str(sobrecargados))
# actividades específicas: sin fórmulas de relleno
genericas = ['Explicación del tema', 'ejercicios varios', 'trabajo en grupo', 'repaso general', 'lectura del tema']
hallg = [g for g in genericas if g.lower() in texto.lower()]
chk('C', 'sin actividades genéricas de relleno', not hallg, True, str(hallg))
# UNICIDAD con piso verificable (corrección propia §1.5bis)
ternas = {}
for k in ORDEN:
    d_ = momentos.M[int(k)] if k.isdigit() else momentos.M[k]
    proc = FUENTE[k]['proc'] if k.isdigit() else d_['proc']
    inst = FUENTE[k]['inst'] if k.isdigit() else d_['inst']
    ternas.setdefault((d_['inicio'][0], proc, inst), []).append(k)
dup = {t: v for t, v in ternas.items() if len(v) > 1}
chk('C', 'unicidad: ninguna terna (inicio + procedimiento + instrumento) repetida', not dup, True,
    str(list(dup.values())[:3]))
# instrumento repetido en más de 3 planes consecutivos
insts = [(FUENTE[k]['inst'] if k.isdigit() else momentos.M[k]['inst']) for k in ORDEN]
racha, peor, prev = 1, 1, None
for i in insts:
    racha = racha + 1 if i == prev else 1
    peor = max(peor, racha); prev = i
chk('C', 'ningún instrumento repetido en más de 3 planes seguidos', peor <= 3, False, 'racha máx %d' % peor)
# control bidireccional ACTIVIDADES ↔ RECURSOS
malos_rec = []
for k in ORDEN:
    d_ = momentos.M[int(k)] if k.isdigit() else momentos.M[k]
    act = ' '.join(d_['inicio'] + d_['desarrollo'] + d_['cierre']).lower()
    rec = d_['recursos'].lower()
    # toda figura listada en recursos debe aparecer en actividades
    for fg in re.findall(r'figuras? ([\d\., y]+)', rec):
        for num in re.findall(r'\d\.\d+', fg):
            if num not in act:
                malos_rec.append('%s: figura %s en recursos sin uso' % (k, num))
    # toda figura usada en actividades debe estar en recursos
    for num in set(re.findall(r'figura (\d\.\d+)', act)):
        if num not in rec:
            malos_rec.append('%s: figura %s usada sin listar' % (k, num))
    # grabadora
    if 'grabaci' in act or 'graba' in act:
        if 'grabadora' not in rec and 'grabador' not in rec:
            malos_rec.append('%s: se graba sin equipo listado' % k)
chk('C', 'correspondencia bidireccional actividades ↔ recursos', not malos_rec, True, ' | '.join(malos_rec[:4]))
# alternativa de bajo costo cuando el recurso puede faltar
sin_alt = []
for k in ORDEN:
    d_ = momentos.M[int(k)] if k.isdigit() else momentos.M[k]
    rec = d_['recursos']
    if ('celular' in rec or 'equipo de audio' in rec) and ('si no' not in rec and 'si el' not in rec):
        sin_alt.append(k)
chk('C', 'alternativa prevista donde el recurso puede faltar', not sin_alt, False, str(sin_alt))
# diagnóstico y evaluaciones no automáticos
planes_con_diag = [k for k in ORDEN
                   if 'diagnóstica' in ' '.join((momentos.M[int(k)] if k.isdigit() else momentos.M[k])['inicio'])]
chk('C', 'diagnóstica presente solo en el plan 1', planes_con_diag == ['1'], False, str(planes_con_diag))

# ================= D · CALIDAD TÉCNICA Y EDITORIAL (20) =================
filas = x.count('<w:tr ') + x.count('<w:tr>')
grid = sum(1 for t in d.tables if t._tbl.find(qn('w:tblGrid')) is not None
           and len(t._tbl.find(qn('w:tblGrid'))) == len(t.columns))
lay = sum(1 for t in d.tables if t._tbl.tblPr is not None and t._tbl.tblPr.find(qn('w:tblLayout')) is not None)
chk('D', 'tblLayout fixed + tblGrid en todas las tablas', grid == len(d.tables) == lay, True,
    '%d/%d grid, %d layout' % (grid, len(d.tables), lay))
chk('D', 'tblHeader en las 26 tablas de momentos', x.count('tblHeader') == 26, True, str(x.count('tblHeader')))
prot = x.count('<w:cantSplit')
chk('D', 'cantSplit selectivo: exactamente 26 filas Desarrollo sin proteger',
    filas - prot == 26, True, '%d filas, %d protegidas' % (filas, prot))
s = z.read('word/settings.xml').decode()
chk('D', 'updateFields antes de w:compat', s.find('updateFields') < s.find('w:compat'), True)
chk('D', 'estilo «Plan de Clase» con nivel de esquema 1',
    'Plan de Clase' in [st.name for st in d.styles] and b'outlineLvl' in z.read('word/styles.xml'), True)
chk('D', 'TOC dinámico', 'TOC \\o' in x, True)
heads = [n for n in z.namelist() if 'header' in n]
foots = [n for n in z.namelist() if 'footer' in n]
con_styleref = sum(1 for n in heads if b'STYLEREF' in z.read(n))
con_page = sum(1 for n in foots if b' PAGE ' in z.read(n) and b' NUMPAGES ' in z.read(n))
chk('D', 'STYLEREF en los encabezados de continuación (26)', con_styleref == 26, True, str(con_styleref))
chk('D', 'pie con PAGE/NUMPAGES en todas las partes de pie', con_page == len(foots) and len(foots) >= 27, True,
    '%d/%d' % (con_page, len(foots)))
chk('D', '27 secciones (portada + 26 planes)', len(d.sections) == 27, True, str(len(d.sections)))
sizes = sorted(set(int(v) / 2 for v in re.findall(r'<w:sz w:val="(\d+)"/>', x)))
chk('D', 'ninguna tipografía por debajo de 9,5 pt', min(sizes) >= 9.5, True, str(sizes))
chk('D', 'fuente explícita, no heredada del tema', d.styles['Normal'].font.name == 'Calibri', False)

# ================= CORRECCIÓN §1.8bis · registro =================
voseo_citado = ['Observá en el texto']
otras_voseantes = re.findall(r'\b(\w+á)\b(?=[\s,.])', texto)
neutro_ok = not re.search(r'\b(tú|tienes|puedes|debes|hazlo)\b', texto, re.I)
chk('B', '§1.8bis: cita del tomo conserva su voseo original', all(v in texto for v in voseo_citado), True)
chk('B', '§1.8bis: cita NO neutralizada («Observa en el texto»)', '«Observa en el texto' not in texto, True)
chk('B', 'registro institucional neutro fuera de las citas', neutro_ok, True)

# ================= RENDER =================
subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', F], capture_output=True)
out = subprocess.run(['pdftotext', '-layout', PDF, '-'], capture_output=True, text=True).stdout
pags = out.split('\f')
chk('D', 'PDF generado', len(pags) > 26, True, '%d páginas' % len(pags))
# cada plan empieza en página nueva y al tope
tops = []
for p_ in pags:
    ls = [l for l in p_.split('\n') if l.strip()]
    if ls:
        tops.append(ls[0].strip())
inicios = sum(1 for t_ in tops if re.match(r'Plan de Clase N\.º \d+ — ', t_) and 'continuación' not in t_)
conti  = sum(1 for t_ in tops if 'continuación' in t_)
chk('D', 'los 26 planes empiezan al tope de una página', inicios == 26, True, str(inicios))
chk('D', 'páginas de continuación rotuladas por STYLEREF', conti >= 1, False, '%d páginas de continuación' % conti)
# ningún bloque perdido: los 9 bloques presentes 26 veces en el RENDER
for b in ('EVALUACIÓN', 'Recursos y medios', 'Visto bueno', 'Observaciones:', 'Criterios'):
    chk('D', 'render sin pérdida de bloque: ' + b, out.count(b) >= 26, True, str(out.count(b)))
# encabezado de continuación operativo
chk('D', 'encabezado de continuación visible en el render', out.count('· continuación') >= 1, False,
    str(out.count('· continuación')))
# pie en todas las páginas
pies = len(re.findall(r'Página \d+ de \d+', out))
chk('D', 'pie presente en todas las páginas del render', pies == len(pags) - 1, True,
    '%d pies / %d páginas' % (pies, len(pags) - 1))

# ================= RESULTADO =================
PESOS = {'A': 20, 'B': 30, 'C': 30, 'D': 20}
res = {}
for a in PESOS:
    items = [r for r in R if r[0] == a]
    ok = sum(1 for r in items if r[2])
    res[a] = (ok, len(items), PESOS[a] * ok / len(items))
criticos = [(r[1], r[4]) for r in R if not r[2] and r[3]]
mayores = [(r[1], r[4]) for r in R if not r[2] and not r[3]]
total = sum(v[2] for v in res.values())
print('=' * 74)
for a in 'ABCD':
    print('  %s: %d/%d controles · %.1f/%d puntos' % (a, res[a][0], res[a][1], res[a][2], PESOS[a]))
print('  TOTAL: %.1f/100 · fallos críticos: %d · fallos menores: %d' % (total, len(criticos), len(mayores)))
print('  ESTADO:', 'APROBADO' if (round(total) == 100 and not criticos) else 'NO APROBADO')
print('=' * 74)
for r in R:
    if not r[2]:
        print(('** CRÍTICO ' if r[3] else '** menor   ') + r[1] + ((' [' + r[4] + ']') if r[4] else ''))
print('controles ejecutados:', len(R))
sys.exit(1 if criticos else 0)
