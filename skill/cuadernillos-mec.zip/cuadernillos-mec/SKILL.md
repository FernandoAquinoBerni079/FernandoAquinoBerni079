---
name: cuadernillos-mec
description: Pipeline completo para producir cuadernillos pedagógicos (tomos) y Planes Anuales de asignaturas del MEC de Paraguay, alineados a los programas oficiales de tercer ciclo y nivel medio (plan común y planes específicos BTC/BTAN/BTM/BT Informática y demás énfasis). Usar SIEMPRE que Fer pida crear, continuar, corregir o auditar un tomo, cuadernillo, Plan Anual, unidad, clase, evaluación o guía didáctica; también cuando diga "Seguimos", "Avanza", "dale" o nombre una materia/curso (Informática BTC, FEC, Contabilidad, etc.), aunque no mencione la palabra "cuadernillo". Incluye helpers python-docx canónicos, formato canónico del Plan Anual, doctrina legal paraguaya verificada, identidades visuales, formato canónico del Plan de Clase y protocolo de auditoría.
---

# Cuadernillos pedagógicos MEC (Paraguay)

Producción comercial de cuadernillos de trabajo ("tomos") para Fer, docente paraguaya.
Autoridad pedagógica delegada por completo: no re-preguntar decisiones ya tomadas.
Español con voseo, **oficio 21,6 × 33 cm** (ver § Formato de la colección), enfoque
«Aprender Haciendo», venta nacional.

## Formato de la colección (regla vigente desde oct-2026)

Por decisión de Fer, para bajar el costo de impresión de docentes y estudiantes, **todas las
piezas van en oficio y ninguna en A4**:

| Pieza | Hoja | Márgenes | Ancho útil |
|---|---|---|---|
| Tomo / libro del estudiante | Oficio vertical 21,6 × 33 cm | Estrechos: 1,27 cm por lado | 19,06 cm |
| Solucionario docente | Oficio vertical | 1,27 cm | 19,06 cm |
| Planes de Clase | Oficio vertical | 1,27 cm | 19,06 cm |
| Plan Anual | Oficio horizontal 33 × 21,6 cm | 1,27 cm | 30,46 cm |
| Portadas, contraportada y muestra | Proporción oficio (216 × 330 mm) | — | — |

- **Tablas, cajas, fichas, bandas de evaluación y renglones ajustados a la ventana**: ancho
  100 % (`w:tblW` tipo `pct`, valor 5000) y columnas escaladas en proporción al ancho útil,
  con `tblGrid` reescrito. Nunca anchos fijos en cm que dejen la tabla más angosta que la
  página. Funciones: `helpers.formato_oficio(sec, horizontal=False)` y
  `helpers.ancho_ventana(tabla, anchos_cm)`.
- Distancia de encabezado y pie: 0,6 cm. Las figuras pueden usar hasta el ancho útil
  menos 1,5 cm.
- La auditoría verifica en **todas las secciones** de cada pieza el tamaño de hoja y los
  márgenes, que toda tabla tenga ancho 100 % y que el PDF salga en oficio.
- Al rearmar en oficio, los índices cambian de página: se regeneran y se verifican contra
  el PDF. Si la auditoría ubica páginas «a partir de la 5.ª», cambiar ese criterio: en oficio
  el índice es más corto.
- Piezas ya entregadas en A4 se convierten conservando la versión anterior (sufijo de
  versión nuevo, p. ej. `_v2_2`); el contenido no se toca en esa pasada.

## Flujo de trabajo por tomo

1. **Verificar antes de construir.** Revisar `/mnt/user-data/outputs/`, los archivos del
   proyecto y la planilla `Inventario_Maestro_Cuadernillos.xlsx`: NUNCA reconstruir un
   tomo ya entregado. Un chat por tomo pesado (ver `references/estandares-editoriales.md`
   § Gestión de chats).
2. **Leer el programa oficial del MEC** (PDF en el proyecto) y la carga horaria.
   Segmentar: unidades → clases (numeración continua) → calendario paraguayo
   (Etapa 1 cierra en junio, Etapa 2 en noviembre).
3. **Verificar el marco legal con búsqueda web** para todo contenido tributario,
   societario, laboral o financiero. Partir de `references/doctrina-legal.md` (corte
   jul-2026) y re-verificar lo que pueda haber cambiado. NUNCA confiar en las citas
   legales del programa MEC.
4. **Diseñar el caso integrador** (empresa paraguaya propia de la materia) y TODOS sus
   números de atrás hacia adelante antes de escribir. Definir identidad visual
   (`references/identidades.md`) — materia nueva ⇒ color nuevo, deconflictado con
   `scripts/deconflicto_color.py` y propuesto a Fer con sus cifras de ΔE y contraste.
5. **Construir con el pipeline** `scripts/helpers.py` (copiarlo a `/home/claude/<materia>/`
   junto con módulos `unidadN_content.py`, `evaluaciones_content.py`,
   `build_tomo_completo.py`). Estructura de cada clase, registro de profundidad
   INTERMEDIO, fichas, cajas y ejercicios: `references/estandares-editoriales.md`.
6. **Generar el Plan Anual** con `scripts/plan_anual.py` en archivo aparte, con los temas
   e indicadores LEÍDOS de las fichas del tomo (nunca escritos a mano). Formato y
   verificaciones: `references/plan-anual.md`.
7. **Generar los Planes de Clase** solo cuando Fer los pida: no van por defecto con el
   tomo. Un solo .docx con todos los planes, derivados del Plan Anual (Modo A) o
   directamente del programa oficial si el encargo no tiene Plan Anual (Modo B, caso
   Educación Física y Matemática Yegros). Formato, parámetros, perfiles por nivel y
   auditoría de 100 puntos: `references/plan-de-clase.md`. NUNCA suponer que la hora
   cátedra dura 40 minutos.
8. **Auditar hasta 0 fallos** con `references/auditoria.md`, en un script `auditoria.py`
   que cuente los controles (cantSplit, páginas propias, render PDF, fichas y bandas sin
   partir, tablas sin filas perdidas, coherencia aritmética transversal, coherencia
   tomo↔solucionario en las opciones múltiples, terminología legal, voseo, residuos).
9. **Entregar** los TRES .docx (tomo, Plan Anual y Solucionario Docente) — CUATRO con
   laboratorio (+ Cuaderno de Laboratorio) o con planes de clase (+ Planes de Clase) — a
   `/mnt/user-data/outputs/` + planilla de inventario
   actualizada, y avisar si el próximo tomo va en este chat o en uno nuevo.

## Defectos recurrentes del pipeline (ya corregidos en `scripts/`)

Estos cuatro se detectaron una y otra vez al copiar los scripts a cada tomo. Ya están
arreglados acá: **si reaparecen, es porque se copió una versión vieja**.

| Defecto | Síntoma | Estado |
|---|---|---|
| `ANCHOS` del Plan Anual sumaban 28,2 cm | La tabla se desborda de la hoja horizontal | Ahora se derivan de proporciones y suman exactamente el ancho útil del oficio horizontal (30,46 cm) |
| `helpers.ficha()` sin `keepNext` | La ficha de la clase se parte entre páginas | Corregido |
| `helpers.caja()` sin tipo neutro | Sale «Concepto clave — » delante de textos que no lo son | Tipos `neutra` y `taller` |
| Salto de página DESPUÉS del rótulo de una tabla larga | El rótulo queda huérfano al pie | `add_table_md(rotulo=...)` |
| `w:tblLayout=fixed` sin `w:tblGrid` | Word y LibreOffice ignoran los anchos: la columna de actividades queda estrangulada | `tblGrid` reescrito columna por columna |
| `cantSplit` universal en Planes de Clase | Huecos blancos al pie cuando una fila larga no entra | Selectivo: filas cortas protegidas, Desarrollo divisible |
| Códigos internos (`8-01`, `IMG_014`) en campos heredados | Llegan al Plan Anual y al Plan de Clase, que lee un docente | Prohibidos en campo visible; se corrigen aguas arriba |
| Hoja A4 y márgenes de 2 cm heredados de la plantilla | Costo de impresión más alto; tablas angostas | Oficio con márgenes estrechos y tablas al 100 % (`formato_oficio`, `ancho_ventana`) |

Además: `helpers.extraer_fichas()` (regex) sólo funciona si las fichas están escritas
como llamadas literales `H.ficha(doc, capacidad="...", ...)`. Si el contenido se declara
como diccionarios de datos, **importar los módulos y leer las claves**, y poner siempre un
`assert len(FICHAS) == n_clases` antes de generar el Plan Anual.

## Referencias (leer según la fase)

| Archivo | Cuándo leerlo |
|---|---|
| `references/estandares-editoriales.md` | Siempre, antes de escribir contenido |
| `references/estandar-grafico.md` | Siempre en materias procedimentales/técnicas (diagramas obligatorios desde jul-2026) y en todo retrofit gráfico |
| `references/doctrina-legal.md` | Antes de cualquier contenido legal/tributario/contable |
| `references/plan-anual.md` | Antes de generar el Plan Anual |
| `references/plan-de-clase.md` | Antes de generar Planes de Clase (formato V3, modos A/B, perfiles, auditoría 100 pts) |
| `references/identidades.md` | Al definir portada/colores (deconflicto CIELAB obligatorio) |
| `references/auditoria.md` | Antes de entregar |

## Scripts

- `scripts/helpers.py` — pipeline python-docx canónico: `set_identidad`, `new_doc`,
  `portada`, `presentacion`, `indice_toc`, `ficha`, `caja`, `add_table_md`, `ejercicios`,
  `evaluacion_unidad`, `evaluacion_etapa`, `prueba_diagnostica`, `imagen`, `finalizar`,
  `extraer_fichas`, `barajar_opciones`. Ya incorpora cantSplit universal, `keepNext` en la
  ficha y en el rótulo de tabla, páginas propias para evaluaciones, footer con campos
  reales y updateFields en el orden correcto del schema. `caja()` acepta los tipos
  `ejemplo | concepto | paraguay | neutra | taller` (los dos últimos SIN prefijo).
  `add_table_md(..., rotulo=..., forzar_salto_antes=True)` pone el salto ANTES del rótulo,
  para que el rótulo no quede huérfano al pie.
  El `cantSplit` universal es la regla del TOMO y ahí sigue vigente. En Planes de Clase se
  usa selectivo (`references/plan-de-clase.md` §11): no "corregir" uno con la regla del otro.
- `scripts/plan_anual.py` — `build_plan_anual(plan_data, ruta)`: la tabla continua de
  7 columnas canónica completa (bandas de etapa, filas de unidad fusionadas, fila propia
  para evaluaciones de etapa, cierre con criterios/inclusión/firma). Oficio horizontal; los
  ANCHOS se derivan de `PROPORCIONES` y suman el ancho útil (30,46 cm): **no reescribirlos a mano**.
- `scripts/planes_clase.py` + `scripts/auditoria_planes.py` — generador de Planes de
  Clase (formato V3) y su auditoría de 100 puntos, tomados de la serie de 26 planes que
  validó el estándar. Se copian a `/home/claude/<materia>/` y se reemplazan `momentos.py`
  (contenido de cada sesión) y `fuente_planes.json` (campos heredados, extraídos del Plan
  Anual y de las fichas, nunca transcritos). Norma: `references/plan-de-clase.md`.
- `scripts/deconflicto_color.py` — `catalogo(inventario)` + `verificar(cat, tonos)`:
  distancia CIELAB de una identidad nueva contra TODO el catálogo (bandas fijas incluidas)
  y contraste de MED con blanco. `buscar()` propone tonos de una familia de matiz.
  Correrlo SIEMPRE antes de construir la portada de una materia nueva.

Los .docx del proyecto están guardados como texto extraído (sin colores ni binario):
sirven para leer contenido, no para verificar formato. El TOC es un campo dinámico que
Fer puebla con Ctrl+E → F9; el .docx es siempre el entregable (el PDF solo para auditar).

## Regla de entrega de esta skill (leer antes de tocar cualquier archivo de acá)

Subir una habilidad **REEMPLAZA el paquete entero**: lo que no va en la subida, se borra.
Y los archivos `.md` sueltos **no cargan** (dan error).

Por lo tanto, cuando se modifique cualquier archivo de esta skill se entrega **UN ÚNICO
.zip con el paquete COMPLETO** — `SKILL.md` + `references/` enteras + `scripts/` enteros —
aunque haya cambiado un solo archivo, y se lista su contenido para que Fer verifique antes
de reemplazar. **Nunca archivos individuales.** Esto ya costó la pérdida de
`estandar-grafico.md` y de los scripts en julio de 2026.

## Estado de esta skill (07-oct-2026)

Se adoptó el **formato oficio** para toda la colección (§ Formato de la colección):
`helpers.py`, `plan_anual.py` y `planes_clase.py` generan oficio con márgenes estrechos y
tablas al 100 %; `references/plan-anual.md`, `references/plan-de-clase.md`,
`references/estandares-editoriales.md` y `references/auditoria.md` quedaron sincronizados.
Aplicado y auditado con 0 fallos en Algorítmica 1.º, 2.º y 3.º (BTI).

## Estado anterior de esta skill (13-ago-2026, tarde)

Los `scripts/` y `references/plan-de-clase.md` de esta versión fueron **reconstruidos**
en la sesión del 12-13 de agosto de 2026, porque la skill había quedado con un único
archivo (`SKILL.md`) apuntando a nueve rutas inexistentes. Los tres scripts históricos
(`helpers.py`, `plan_anual.py`, `deconflicto_color.py`) están validados contra un caso
conocido: reproducen el tomo, el Plan Anual y la identidad PALO ROSA de Castellano 8.º
con las mismas cifras (ΔE mín 9,4 · contraste 8,79:1 · 24 procedimientos e instrumentos
únicos). `references/doctrina-legal.md` fue **reescrito el 13-ago-2026** con re-verificación web
completa (DNIT, BACN, MTESS, IPS, BCP). Trae en su §1 una **corrección mayor**: el régimen
SIMPLE del IRE NO está disponible para S.R.L. ni S.A. — solo Régimen General. Eso afecta
tomos ya entregados de las sagas Arasy/Yvoty/Takuara y Casa Ñandutí, cuya auditoría queda
**pendiente**.

El 13-ago-2026 (tarde) se escribieron `references/identidades.md` y
`references/estandares-editoriales.md`. El catálogo de identidades sale del inventario
`_94` (74 identidades, 256 tonos) y el protocolo de deconflicto quedó documentado, no
reinventado: el umbral se aplica **al tono DARK** (el MED se informa, el SOFT y el LIGHT no
se deconflictan) y el control duro es la **mochila** del curso, porque el catálogo global
ya está saturado.

También se escribieron `references/plan-anual.md` (formato canónico, origen de cada campo,
unicidad estricta de procedimientos e instrumentos) y `references/auditoria.md` (protocolo
de liberación del tomo, seis bloques, criterio de **cero fallos**, regla del auditor).

`references/estandar-grafico.md` fue **recuperado** el 13-ago-2026: Fer encontró la copia
de jul-2026 y se reincorporó tal cual, sin reescribir. Único ajuste: la firma de
`helpers.imagen()` quedó sincronizada con la real del script
(`doc, ruta, lead_in, epigrafe, ancho_cm=14.0`). **Con eso el paquete de referencias está
completo**: no falta ninguna.

Dos asimetrías que no hay que "corregir" cruzando reglas: el `cantSplit` es **universal**
en el tomo y en el Plan Anual, y **selectivo** en los Planes de Clase; la unicidad de
procedimientos e instrumentos es **estricta** en el Plan Anual y **flexible con piso
verificable** (§1.5bis) en los Planes de Clase.
