---
name: cuadernillos-mec
description: Pipeline completo para producir cuadernillos pedagógicos (tomos) y Planes Anuales de asignaturas del MEC de Paraguay, alineados a los programas oficiales de tercer ciclo y nivel medio (plan común y planes específicos BTC/BTAN/BTM/BT Informática y demás énfasis). Usar SIEMPRE que Fer pida crear, continuar, corregir o auditar un tomo, cuadernillo, Plan Anual, unidad, clase, evaluación o guía didáctica; también cuando diga "Seguimos", "Avanza", "dale" o nombre una materia/curso (Informática BTC, FEC, Contabilidad, etc.), aunque no mencione la palabra "cuadernillo". Incluye helpers python-docx canónicos, formato canónico del Plan Anual, doctrina legal paraguaya verificada, identidades visuales, formato canónico del Plan de Clase y protocolo de auditoría.
---

# Cuadernillos pedagógicos MEC (Paraguay)

Producción comercial de cuadernillos de trabajo ("tomos") para Fer, docente paraguaya.
Autoridad pedagógica delegada por completo: no re-preguntar decisiones ya tomadas.
Español con voseo; tomo en **oficio (21,59 × 33,02 cm), márgenes estrechos (1,27 cm) y tablas
ajustadas a la ventana** (Fer, 02-oct-2026); enfoque «Aprender Haciendo»; venta nacional.

## Flujo de trabajo por tomo

1. **Verificar antes de construir.** Revisar `/mnt/user-data/outputs/`, los archivos del
   proyecto y la planilla `Inventario_Maestro_Cuadernillos.xlsx`: NUNCA reconstruir un
   tomo ya entregado. Un chat por tomo pesado (ver `references/estandares-editoriales.md`
   § Gestión de chats).
2. **Leer el programa oficial del MEC** (PDF en el proyecto) y la carga horaria.
   Segmentar: unidades → clases (numeración continua) → calendario paraguayo
   (Etapa 1 cierra en junio, Etapa 2 en noviembre).
3. **Verificar el marco legal con búsqueda web** para todo contenido tributario,
   societario, laboral o financiero. Partir de `references/doctrina-legal.md` (corte
   jul-2026) y re-verificar lo que pueda haber cambiado. NUNCA confiar en las citas
   legales del programa MEC.
4. **Diseñar el caso integrador** (empresa paraguaya propia de la materia) y TODOS sus
   números de atrás hacia adelante antes de escribir. Definir identidad visual
   (`references/identidades.md`) — materia nueva ⇒ color nuevo, deconflictado con
   `scripts/deconflicto_color.py` y propuesto a Fer con sus cifras de ΔE y contraste.
5. **Construir con el pipeline** `scripts/helpers.py` (copiarlo a `/home/claude/<materia>/`
   junto con módulos `unidadN_content.py`, `evaluaciones_content.py`,
   `build_tomo_completo.py`). Estructura de cada clase, registro de profundidad
   INTERMEDIO, fichas, cajas y ejercicios: `references/estandares-editoriales.md`.
6. **Generar el Plan Anual** con `scripts/plan_anual.py` en archivo aparte, con los temas
   e indicadores LEÍDOS de las fichas del tomo (nunca escritos a mano). Formato y
   verificaciones: `references/plan-anual.md`.
7. **Generar los Planes de Clase** solo cuando Fer los pida: no van por defecto con el
   tomo. Un solo .docx con todos los planes, derivados del Plan Anual (Modo A) o
   directamente del programa oficial si el encargo no tiene Plan Anual (Modo B, caso
   Educación Física y Matemática Yegros). Formato, parámetros, perfiles por nivel y
   auditoría de 100 puntos: `references/plan-de-clase.md`. NUNCA suponer que la hora
   cátedra dura 40 minutos.
7bis. **Paginar e indexar sobre el render**: `scripts/paginacion.py` (0 páginas interiores
   ocupadas en menos del 25 %) y `scripts/indice_pdf.py` (índice poblado, «cambiadas 0»).
   El PDF se regenera siempre después del último cambio y tiene el mismo papel que el DOCX.
8. **Auditar hasta 0 fallos** con `references/auditoria.md`, en un script `auditoria.py`
   que cuente los controles (cantSplit, páginas propias, render PDF, fichas y bandas sin
   partir, tablas sin filas perdidas, coherencia aritmética transversal, coherencia
   tomo↔solucionario en las opciones múltiples, terminología legal, voseo, residuos,
   **cobertura textual del 100 % de las capacidades** y **unicidad de datos**
   con `scripts/unicidad_datos.py`).
9. **Entregar** los TRES .docx (tomo, Plan Anual y Solucionario Docente), con su PDF —
   CUATRO con planes de clase (+ Planes de Clase); en gabinete las prácticas van dentro del
   libro — más la muestra comercial, a
   `/mnt/user-data/outputs/` + planilla de inventario
   actualizada, y avisar si el próximo tomo va en este chat o en uno nuevo.

## Defectos recurrentes del pipeline (ya corregidos en `scripts/`)

Estos cuatro se detectaron una y otra vez al copiar los scripts a cada tomo. Ya están
arreglados acá: **si reaparecen, es porque se copió una versión vieja**.

| Defecto | Síntoma | Estado |
|---|---|---|
| `ANCHOS` del Plan Anual sumaban 28,2 cm | La tabla se desborda del A4 horizontal | Corregido a 26,7 cm |
| `helpers.ficha()` sin `keepNext` | La ficha de la clase se parte entre páginas | Corregido |
| `helpers.caja()` sin tipo neutro | Sale «Concepto clave — » delante de textos que no lo son | Tipos `neutra` y `taller` |
| Salto de página DESPUÉS del rótulo de una tabla larga | El rótulo queda huérfano al pie | `add_table_md(rotulo=...)` |
| `w:tblLayout=fixed` sin `w:tblGrid` | Word y LibreOffice ignoran los anchos: la columna de actividades queda estrangulada | `tblGrid` reescrito columna por columna |
| `cantSplit` universal en Planes de Clase | Huecos blancos al pie cuando una fila larga no entra | Selectivo: filas cortas protegidas, Desarrollo divisible |
| Códigos internos (`8-01`, `IMG_014`) en campos heredados | Llegan al Plan Anual y al Plan de Clase, que lee un docente | Prohibidos en campo visible; se corrigen aguas arriba |
| Salto de página en un párrafo vacío propio | Página en blanco cuando la hoja anterior queda justa | `helpers.saltos_robustos()` (en `finalizar()`): «salto de página antes» |
| DOCX y PDF con distinto papel (A4 / oficio) | Notas, auditoría e índice con números distintos (137 vs 113 págs.) | Mismo papel siempre; el PDF se regenera al final |
| Índice con leyenda «Ctrl+E / F9» | El PDF que compra el docente sale con el índice vacío | `scripts/indice_pdf.py`: índice poblado desde el PDF |
| Capacidades fusionadas, recortadas u omitidas | La auditoría externa las marca como CRÍTICO o MEDIO | Lista textual del programa + `plan_anual.verificar_capacidades()` |
| Datos del ejemplo resuelto reutilizados en actividades, también como operación inversa | «Todo dato repetido es un fallo» (protocolo 2026) | `scripts/unicidad_datos.py`, que valida también los datos propuestos por el auditor |
| LibreOffice sin el módulo Writer en el contenedor | `soffice` responde «source file could not be loaded» | `apt-get install libreoffice-writer fonts-crosextra-carlito fonts-crosextra-caladea` |

Además: `helpers.extraer_fichas()` (regex) sólo funciona si las fichas están escritas
como llamadas literales `H.ficha(doc, capacidad="...", ...)`. Si el contenido se declara
como diccionarios de datos, **importar los módulos y leer las claves**, y poner siempre un
`assert len(FICHAS) == n_clases` antes de generar el Plan Anual.

## Referencias (leer según la fase)

| Archivo | Cuándo leerlo |
|---|---|
| `references/estandares-editoriales.md` | Siempre, antes de escribir contenido |
| `references/estandar-grafico.md` | Siempre en materias procedimentales/técnicas (diagramas obligatorios desde jul-2026) y en todo retrofit gráfico |
| `references/doctrina-legal.md` | Antes de cualquier contenido legal/tributario/contable |
| `references/plan-anual.md` | Antes de generar el Plan Anual |
| `references/plan-de-clase.md` | Antes de generar Planes de Clase (formato V3, modos A/B, perfiles, auditoría 100 pts) |
| `references/identidades.md` | Al definir portada/colores (deconflicto CIELAB obligatorio) |
| `references/auditoria.md` | Antes de entregar |

## Scripts

- `scripts/helpers.py` — pipeline python-docx canónico: `set_identidad`, `new_doc`,
  `portada`, `presentacion`, `indice_toc`, `ficha`, `caja`, `add_table_md`, `ejercicios`,
  `evaluacion_unidad`, `evaluacion_etapa`, `prueba_diagnostica`, `imagen`, `finalizar`,
  `extraer_fichas`, `barajar_opciones`. Ya incorpora cantSplit universal, `keepNext` en la
  ficha y en el rótulo de tabla, páginas propias para evaluaciones, footer con campos
  reales y updateFields en el orden correcto del schema. `caja()` acepta los tipos
  `ejemplo | concepto | paraguay | neutra | taller` (los dos últimos SIN prefijo).
  `add_table_md(..., rotulo=..., forzar_salto_antes=True)` pone el salto ANTES del rótulo,
  para que el rótulo no quede huérfano al pie.
  El `cantSplit` universal es la regla del TOMO y ahí sigue vigente. En Planes de Clase se
  usa selectivo (`references/plan-de-clase.md` §11): no "corregir" uno con la regla del otro.
- `scripts/plan_anual.py` — `build_plan_anual(plan_data, ruta)`: la tabla continua de
  7 columnas canónica completa (bandas de etapa, filas de unidad fusionadas, fila propia
  para evaluaciones de etapa, cierre con criterios/inclusión/firma). Los ANCHOS ya suman
  26,7 cm, el ancho útil real del A4 horizontal: **no reescribirlos a mano**.
- `scripts/planes_clase.py` + `scripts/auditoria_planes.py` — generador de Planes de
  Clase (formato V3) y su auditoría de 100 puntos, tomados de la serie de 26 planes que
  validó el estándar. Se copian a `/home/claude/<materia>/` y se reemplazan `momentos.py`
  (contenido de cada sesión) y `fuente_planes.json` (campos heredados, extraídos del Plan
  Anual y de las fichas, nunca transcritos). Norma: `references/plan-de-clase.md`.
- `scripts/paginacion.py` — `render()`, `ocupacion()`, `casi_vacias()` y
  `corregir_paginas()`: ciclo que ajusta el espaciado sólo en el bloque que deja una hoja
  casi vacía, en tres niveles, sin tocar la tipografía.
- `scripts/indice_pdf.py` — `construir()` arma las entradas del índice (TDC1/TDC2) a
  partir de los títulos, y `actualizar()` les pone la página real del PDF.
- `scripts/formato_oficio.py` — convierte un tomo A4 existente a oficio: secciones, tablas a
  la ventana y portadas compuestas extendidas en sus franjas lisas.
- `scripts/unicidad_datos.py` — `operaciones_repetidas()`, `choca()` y
  `firmas_repetidas()`: control de datos repetidos entre ejemplo, actividades, prácticas,
  fichas y evaluaciones.
- `scripts/deconflicto_color.py` — `catalogo(inventario)` + `verificar(cat, tonos)`:
  distancia CIELAB de una identidad nueva contra TODO el catálogo (bandas fijas incluidas)
  y contraste de MED con blanco. `buscar()` propone tonos de una familia de matiz.
  Correrlo SIEMPRE antes de construir la portada de una materia nueva.

Los .docx del proyecto están guardados como texto extraído (sin colores ni binario):
sirven para leer contenido, no para verificar formato. El índice se entrega
poblado (`scripts/indice_pdf.py`), y el combo comercial lleva el .docx **y** el PDF,
regenerado después del último cambio y con el mismo papel (protocolo 2026 §4.4–4.5).

## Regla de entrega de esta skill (leer antes de tocar cualquier archivo de acá)

Subir una habilidad **REEMPLAZA el paquete entero**: lo que no va en la subida, se borra.
Y los archivos `.md` sueltos **no cargan** (dan error).

Por lo tanto, cuando se modifique cualquier archivo de esta skill se entrega **UN ÚNICO
.zip con el paquete COMPLETO** — `SKILL.md` + `references/` enteras + `scripts/` enteros —
aunque haya cambiado un solo archivo, y se lista su contenido para que Fer verifique antes
de reemplazar. **Nunca archivos individuales.** Esto ya costó la pérdida de
`estandar-grafico.md` y de los scripts en julio de 2026.

## Estado de esta skill (02-oct-2026)

Actualización posterior a la auditoría externa (ChatGPT) del piloto Software 1.º BTI,
Edición Esencial, y a la respuesta v1 (`_TRABAJO/05_RESPUESTA_CLAUDE_SOFTWARE_1_ESENCIAL_v1`):

- **Formato del tomo: oficio, márgenes estrechos y tablas a la ventana** (`helpers.new_doc`
  y `finalizar`, `estandares-editoriales.md` §2bis). El Plan Anual sigue en A4 horizontal y
  los Planes de Clase en A4; el Solucionario, en A4 hasta que Fer decida.
- **Gabinete: un solo libro** (Clase N → Práctica N), sin Cuaderno de Laboratorio aparte
  (`estandares-editoriales.md` §6, protocolo 2026 §3quater).
- **Índice poblado**, sin leyenda F9 (`indice_pdf.py`).
- **Capacidad MEC por secuencia** en el Plan Anual (`plan_anual.py`, `plan-anual.md`).
- **Ley 7593/2025**: vacatio de 24 meses confirmada (art. 57), vigente desde el 27/11/2027
  (`doctrina-legal.md` §1.3 y §9.2). Anexo nuevo sobre software sin licencia, Windows no
  genuino y la definición de grooming.
- Los cuatro scripts nuevos se validaron contra el caso conocido (Software 1.º): reproducen
  las 107 páginas en oficio con 0 páginas casi vacías, el índice con «cambiadas 0» y las
  11 repeticiones de operandos de la Unidad 3 (las 3 del auditor y 4 más), y dan 0 en la
  versión corregida.

## Estado anterior (13-ago-2026, tarde)

Los `scripts/` y `references/plan-de-clase.md` de esta versión fueron **reconstruidos**
en la sesión del 12-13 de agosto de 2026, porque la skill había quedado con un único
archivo (`SKILL.md`) apuntando a nueve rutas inexistentes. Los tres scripts históricos
(`helpers.py`, `plan_anual.py`, `deconflicto_color.py`) están validados contra un caso
conocido: reproducen el tomo, el Plan Anual y la identidad PALO ROSA de Castellano 8.º
con las mismas cifras (ΔE mín 9,4 · contraste 8,79:1 · 24 procedimientos e instrumentos
únicos). `references/doctrina-legal.md` fue **reescrito el 13-ago-2026** con re-verificación web
completa (DNIT, BACN, MTESS, IPS, BCP). Trae en su §1 una **corrección mayor**: el régimen
SIMPLE del IRE NO está disponible para S.R.L. ni S.A. — solo Régimen General. Eso afecta
tomos ya entregados de las sagas Arasy/Yvoty/Takuara y Casa Ñandutí, cuya auditoría queda
**pendiente**.

El 13-ago-2026 (tarde) se escribieron `references/identidades.md` y
`references/estandares-editoriales.md`. El catálogo de identidades sale del inventario
`_94` (74 identidades, 256 tonos) y el protocolo de deconflicto quedó documentado, no
reinventado: el umbral se aplica **al tono DARK** (el MED se informa, el SOFT y el LIGHT no
se deconflictan) y el control duro es la **mochila** del curso, porque el catálogo global
ya está saturado.

También se escribieron `references/plan-anual.md` (formato canónico, origen de cada campo,
unicidad estricta de procedimientos e instrumentos) y `references/auditoria.md` (protocolo
de liberación del tomo, seis bloques, criterio de **cero fallos**, regla del auditor).

`references/estandar-grafico.md` fue **recuperado** el 13-ago-2026: Fer encontró la copia
de jul-2026 y se reincorporó tal cual, sin reescribir. Único ajuste: la firma de
`helpers.imagen()` quedó sincronizada con la real del script
(`doc, ruta, lead_in, epigrafe, ancho_cm=14.0`). **Con eso el paquete de referencias está
completo**: no falta ninguna.

Dos asimetrías que no hay que "corregir" cruzando reglas: el `cantSplit` es **universal**
en el tomo y en el Plan Anual, y **selectivo** en los Planes de Clase; la unicidad de
procedimientos e instrumentos es **estricta** en el Plan Anual y **flexible con piso
verificable** (§1.5bis) en los Planes de Clase.
