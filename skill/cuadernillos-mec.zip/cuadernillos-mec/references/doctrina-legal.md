# Doctrina legal paraguaya — referencia para contenido tributario, societario, laboral y financiero

Corte de verificación: **13-ago-2026** (re-verificado con búsqueda web en esa fecha, fuentes
primarias DNIT / BACN / MTESS / IPS / BCP y secundarias de estudios jurídicos paraguayos).

Se aplica a: Contabilidad y Legislación Aplicada, Seminario Contable, Cálculo Mercantil y
Financiero, Administración de Empresas, Introducción a la Economía, Economía y Gestión,
Informática (módulos de datos personales y facturación electrónica) y a cualquier clase de
cualquier materia que mencione un impuesto, una sociedad, un salario o un aporte.

## 0. Regla de uso — leer antes que el resto

1. **Este archivo es punto de partida, no autoridad final.** Antes de escribir contenido
   legal en un tomo nuevo, re-verificar con búsqueda web los ítems marcados 🔴 y 🟡. Los
   marcados 🟢 son estables y rara vez cambian.
2. **NUNCA confiar en las citas legales del programa oficial del MEC.** Los programas
   arrastran normas derogadas hace años (IRACIS, IMAGRO, CNV, Ley 1064/97). Se enseña el
   contenido curricular con la **norma vigente**, no con la que cita el programa.
3. **Nunca inventar un número de ley ni un artículo.** Si no se pudo verificar, se redacta
   sin la cita («la ley tributaria vigente establece…») antes que citar mal.
4. Los montos en guaraníes se actualizan por decreto o resolución **todos los años**.
   Cualquier cifra de este archivo con más de doce meses debe re-verificarse sí o sí.

### Leyenda de estabilidad

| Marca | Significado |
|---|---|
| 🟢 | Estable — estructura de fondo, cambia por reforma legislativa |
| 🟡 | Semiestable — reglamentación activa, revisar una vez al año |
| 🔴 | Volátil — monto o cronograma que cambia por decreto/resolución anual |

## 1. ⚠️ Correcciones a la doctrina que veníamos aplicando

Esta sección existe porque la re-verificación del 13-ago-2026 encontró un error que **ya
está en tomos entregados**. Leerla completa antes de tocar cualquier caso societario.

### 1.1 El régimen SIMPLE NO es para S.R.L. ni para S.A. (corrección mayor)

La doctrina que veníamos usando decía: «RESIMPLE exclusivo de unipersonal; S.R.L. y S.A.
usan SIMPLE o GENERAL». **Es incorrecto.**

El art. 26 de la Ley 6380/2019 destina el SIMPLE a los contribuyentes de los **numerales 1
y 8** del art. 2.° — empresas unipersonales y sucesiones indivisas de sus propietarios
(num. 1) y las demás entidades privadas de esa naturaleza (num. 8). Las Sociedades
Simples, Anónimas, de Responsabilidad Limitada, en Comandita y de Capital e Industria son
el **numeral 2**, que no está incluido. El propio art. 26 cierra confirmándolo: «las
empresas unipersonales que liquiden el impuesto por este Régimen no serán contribuyentes
del IDU».

**Doctrina correcta:**

| Forma jurídica | Regímenes IRE posibles |
|---|---|
| Empresa unipersonal | RESIMPLE, SIMPLE o GENERAL, según ingresos |
| E.A.S. (Ley 6480/2020) | SIMPLE o GENERAL |
| S.R.L. | **GENERAL únicamente** |
| S.A. | **GENERAL únicamente** |

**Impacto en los tomos:** la saga Arasy (unipersonal) → Yvoty S.R.L. → Takuara S.A. de
CyLA y la saga Casa Ñandutí de Seminario Contable y Cálculo Mercantil atraviesan
exactamente esta progresión. Si alguna clase dice que la S.R.L. o la S.A. «puede optar por
el SIMPLE», está mal y hay que corregirlo por edición aditiva. **Pendiente: auditar los
seis tomos de esas dos sagas.** Pedagógicamente la corrección incluso mejora el relato: el
salto a S.R.L. implica pasar obligatoriamente al Régimen General, con contabilidad
completa y estados financieros — que es justo lo que el tomo enseña después.

### 1.2 Confirmaciones sin cambios

Todo lo demás que traíamos de la verificación de julio se confirmó: DNIT, derogaciones de
la Ley 125/91, RESIMPLE solo unipersonal, salario mínimo, IPS, reserva legal, acciones
nominativas, maquila, mercado de valores y datos personales. El detalle está en las
secciones siguientes.

### 1.3 Dato confirmado el 02-oct-2026 (antes pendiente)

La *vacatio legis* de la Ley 7593/2025 de datos personales **está confirmada: 24 meses
(art. 57)**. Promulgada y publicada el 27/11/2025, entra en vigencia el **27/11/2027**.
Fuentes: SILPy/Congreso y BACN (citadas por la auditoría externa de Software 1.º, 02-oct-2026)
y estudios jurídicos paraguayos que citan el art. 57. Ver §9.2.

## 2. Administración tributaria 🟢

- La **DNIT** (Dirección Nacional de Ingresos Tributarios), creada por la **Ley 7143/2023**,
  es la administración tributaria y aduanera. Reemplazó a la SET y a la Aduana.
  **Nunca escribir «SET» en material nuevo.** Es error de auditoría.
- **Marangatú** sigue siendo el sistema de gestión del contribuyente (declaraciones,
  cuenta corriente, RUC). El nombre no cambió con la creación de la DNIT.
- **Registro Electrónico de Comprobantes** de ventas/compras e ingresos/egresos en
  Marangatú: RG 90/2021. 🟡
- El **RUC** identifica al contribuyente; la constancia de RUC se obtiene ante la DNIT.

### 2.1 Facturación electrónica — SIFEN 🟡

- **SIFEN** = Sistema Integrado de Facturación Electrónica Nacional. Marco: Decreto
  872/2023 y sus resoluciones.
- Dos vías, según el tamaño del contribuyente:
  - **e-Kuatia'i** — gratuita, provista por la DNIT, para pequeños facturadores con un
    solo establecimiento y un punto de expedición.
  - **e-Kuatia** — sistema transaccional, para medianos y grandes que integran su propio
    ERP al SIFEN.
- **Incorporación por grupos.** RG 21/2024 designó grupos hasta 2026; **RG 52/2026**
  (mayo-2026) incorporó seis grupos nuevos con cronograma hasta 2027, y habilitó una
  prórroga por única vez de hasta 3 meses solo para adhesiones por e-Kuatia.
- **RG 41/2025**: los proveedores, contratistas y consultores del Estado están obligados
  desde el **2 de enero de 2026**.
- **Punto clave para enseñar:** llegada la fecha de obligatoriedad del grupo, el timbrado
  de los documentos preimpresos o autoimpresos **pierde vigencia al día siguiente**. No
  hay convivencia entre papel y electrónico. Antes de esa fecha el contribuyente debe
  comunicar la numeración utilizada y dar de baja los documentos timbrados no electrónicos.
- Documentos del sistema: Factura Electrónica, Factura Cambiaria Electrónica, Factura
  Electrónica de Exportación, Autofactura, notas de crédito y débito, comprobantes de
  retención y percepción.

## 3. Impuesto a la Renta Empresarial (IRE) 🟢 (montos 🟡)

Ley 6380/2019, reglamentada por el **Decreto 3182/2019**.

- **Hecho generador:** rentas de fuente paraguaya de actividades económicas primarias,
  secundarias y terciarias, excluidas las gravadas por el IRP.
- **Tasa: 10 %** sobre la renta neta (art. 21).
- **Sistema territorial:** la renta de fuente extranjera de personas físicas no está
  gravada; a nivel empresarial la Ley extiende la regla de fuente a dividendos del exterior.

### 3.1 Los tres regímenes

| Régimen | Quién puede | Tope de ingresos del ejercicio anterior | Cómo tributa | DDJJ |
|---|---|---|---|---|
| **RESIMPLE** (art. 27) | Solo **empresas unipersonales** | ≤ G. 80.000.000 | Monto fijo según escala; **no alcanzado por IVA** | Form. 502, en febrero; pagos en marzo, junio, setiembre y diciembre |
| **SIMPLE** (art. 26) | Contribuyentes de los **num. 1 y 8** del art. 2.° (unipersonales, E.A.S. y entidades privadas de esa naturaleza) | ≤ G. 2.000.000.000 | Renta neta real o presunta, **la que resulte menor**; la presunta da un tope efectivo del 3 % sobre ingresos brutos | Hasta el vencimiento del 3.er mes tras el cierre |
| **GENERAL (IRE RG)** | **Todos**, y obligatorio para S.A. y S.R.L. | Sin tope | Renta neta real, partiendo del resultado contable ajustado | Form. 500, hasta el vencimiento del 4.º mes tras el cierre (abril para cierre 31-dic) |

- **Pasaje de régimen:** las unipersonales pasan de pleno derecho al régimen inmediato
  superior al superar el tope. Quien cambió o optó voluntariamente **no puede volver a
  cambiar por tres ejercicios fiscales consecutivos**, salvo que supere el monto.
- El Régimen General rige **subsidiariamente** para SIMPLE y RESIMPLE en todo lo no
  previsto específicamente (art. 32).
- El RESIMPLE emite **Boleta RESIMPLE** como comprobante de venta.
- **Ejercicio fiscal:** cierra el **31 de diciembre**. Es la fecha que deben usar todos
  los casos de los tomos.
- **Pérdidas fiscales:** arrastre admitido hasta cinco años.

### 3.2 Estructuras Jurídicas Transparentes (EJT)

Art. 4.° de la Ley: negocios fiduciarios (Ley 921/1996), fondos patrimoniales de inversión
(Ley 5452/2015) y figuras análogas. Efecto fiscal **neutro** en el IRE: la renta se traslada
a socios o beneficiarios y la estructura no paga IRE. Tema de nivel avanzado — solo
mencionarlo en 3.er curso si el programa lo pide.

## 4. Impuesto a los Dividendos y a las Utilidades (IDU) 🟢

- **Tasas: 8 %** si el beneficiario es residente en el país, **15 %** si no lo es.
- Grava las utilidades, dividendos o rendimientos puestos a disposición o pagados al
  dueño, consorciados, socios o accionistas de unipersonales, S.A., S.R.L., en comandita
  simple, de capital e industria, consorcios de obra pública y demás entidades privadas
  con personería jurídica constituidas en el país, y de establecimientos permanentes de
  entidades del exterior.
- **Se retiene en la fuente**: la entidad pagadora retiene y remite a la DNIT.
- **No gravadas:** las utilidades destinadas a **capitalización** o a **reserva legal**.
  Ese punto es central en la clase de distribución de resultados: la reserva legal no paga
  IDU, y por eso el orden de aplicación del resultado importa.
- **Exclusión:** las empresas unipersonales que liquidan por SIMPLE o RESIMPLE **no son
  contribuyentes del IDU**.
- Carga combinada del ejercicio distribuido a residente: 10 % IRE + 8 % IDU sobre el
  remanente ⇒ **17,2 % efectivo**. Cifra útil para el ejercicio comparativo de 3.er curso.

## 5. IRP, INR, IVA e ISC 🟡

- **IRP** — Impuesto a la Renta Personal. Dos categorías que se liquidan **por separado**,
  sin compensar entre sí:
  - *Servicios personales:* alcanza a la persona física cuyo ingreso bruto gravado anual
    supera **G. 80.000.000**; tasas progresivas de **8 %, 9 % y 10 %** sobre renta neta.
  - *Rentas y ganancias de capital:* tasa **8 %**.
  - El **aguinaldo está exonerado** del IRP.
- **INR** — Impuesto a la Renta de No Residentes: retención sobre pagos a no residentes por
  rentas de fuente paraguaya.
- **IVA** — tasa general **10 %**; tasa reducida **5 %** para el conjunto de bienes y
  servicios que la ley enumera (canasta familiar básica, productos agrícolas en estado
  natural, arrendamiento de inmuebles, medicamentos, intereses de préstamos). 🟡
  Verificar la lista antes de armar un ejercicio que dependa de la tasa reducida.
- **ISC** — Impuesto Selectivo al Consumo. Tasas modificables **por decreto**: nunca
  publicar una tasa de ISC sin verificarla en el mismo mes. 🔴

## 6. Estados financieros y normativa contable 🟡

- **RG 77/2020** — vigente. Reglamenta aspectos de los Estados Financieros y aprueba el
  **Cuadro de Depreciación de los bienes del activo fijo** para contribuyentes del IRE RG.
  Es la norma a citar cuando el tomo enseña depreciación.
- **RG 49/2026** (marzo-2026) — **novedad importante para Contabilidad**. Establece qué
  información debe exponerse en las **Notas a los Estados Financieros** sobre **utilidades
  acumuladas, reservas y resultados distribuibles**, para los contribuyentes obligados
  (Obligación 948). Permite a la DNIT contrastar la contabilidad con las declaraciones y
  detectar utilidades acumuladas sin destino claro, reservas sin sustancia económica o
  distribuciones encubiertas.
  **Consecuencia pedagógica:** la clase de distribución de resultados y la de notas a los
  estados financieros ganaron relevancia real. Vale la pena que el tomo de 3.er curso
  muestre una nota modelo con la composición de las utilidades acumuladas y el objeto de
  cada reserva.
- **RG 50/2026** (7-abr-2026) — prórroga **excepcional** del plazo de presentación de los
  Estados Financieros del ejercicio cerrado al 31/12/2025. Es coyuntural: **no
  incorporarla como regla general** en ningún tomo.
- **RG 49/2014** — modelo de Estados Financieros y Cuadro de Revalúo y Depreciación.
- **RG 38/2020** — plazos de presentación de DDJJ y pago.
- Fundamento de la potestad reglamentaria de la DNIT: Ley 7143/2023.

## 7. Derecho societario 🟢

### 7.1 Formas jurídicas y sus rasgos distintivos

| | S.A. | S.R.L. | E.A.S. | Unipersonal |
|---|---|---|---|---|
| Norma base | Código Civil, arts. 1048–1159 | Código Civil | Ley 6480/2020 | Ley 6380/2019 art. 3.° (def. fiscal) |
| N.º de socios | Mínimo 2, sin máximo | Mínimo 2, **máximo 25** | Desde 1 (física o jurídica) | 1 persona física |
| Capital dividido en | **Acciones nominativas** | **Cuotas nominativas** de G. 1.000 o múltiplos | Acciones nominativas | Sin división |
| Restricción de objeto | Cualquier actividad lícita | No puede realizar actividades reguladas por el BCP | Ídem S.R.L. | — |
| Régimen IRE | Solo GENERAL | Solo GENERAL | SIMPLE o GENERAL | RESIMPLE / SIMPLE / GENERAL |

- La **empresa unipersonal** en sentido fiscal (art. 3.°) es la unidad productiva de una
  persona física, organizada y habitual, que combina trabajo y capital con preponderancia
  del capital. Incluye a las Empresas Individuales de Responsabilidad Limitada.

### 7.2 Constitución de la S.A.

- Se constituye **por escritura pública**. El acto constitutivo indica socios y acciones
  suscriptas por cada uno, denominación y domicilio, objeto social, capital autorizado /
  suscripto / integrado, valor nominal y número de acciones, órganos de administración.
- Debe estar **suscripto por entero el capital social emitido** (art. 1051 CC, texto de la
  Ley 388/1994).
- Aporte en dinero: la **integración no puede ser inferior al 25 % de la suscripción**
  (art. 1059 CC), con depósito en el **Banco Central del Paraguay**. **No es el BNF** —
  ese error estaba en material viejo.
- Inscripción en el Registro de Personas Jurídicas y Asociaciones; publicación de un
  extracto por tres días.
- Órganos: **Asamblea de accionistas · Directorio · Sindicatura**.

### 7.3 Acciones nominativas — Ley 5895/2017

Estableció reglas de transparencia: **las acciones serán nominativas** (nueva redacción
del art. 1070 CC). Las acciones al portador debieron canjearse por nominativas en 24 meses;
vencido el plazo sin canje, quedan suspendidos los derechos económicos del titular.
Complemento: Ley 6446/2019 (Registro Administrativo de Personas y Estructuras Jurídicas y
de Beneficiarios Finales) y Ley 6872/2021 (reconducción de S.A. incumplidoras).

**En el material: no existen ya acciones al portador en Paraguay.** Cualquier ejercicio que
las use está desactualizado.

### 7.4 Reserva legal — Ley 1034/83 «Del Comerciante»

- **Art. 91:** toda sociedad debe destinar el **5 % de la utilidad neta después de
  impuestos** a Reserva Legal, **hasta alcanzar el 20 % del capital suscripto**.
- Alcanza a S.A., S.R.L. y E.A.S., cualquiera sea su actividad. Entidades financieras y
  cooperativas tienen tasas y reglas propias.
- Alcanzado el 20 %, deja de calcularse. El excedente sobre el 20 % es de libre
  disposición y puede repartirse.
- Sin utilidades, no se calcula.
- Destino exclusivo: **enjugar pérdidas**. No se puede aplicar a otro fin.
- **Art. 93:** no se pueden distribuir utilidades hasta cubrir las pérdidas de ejercicios
  anteriores. Regla imprescindible en el ejercicio de distribución de resultados.

**Orden de aplicación del resultado, para los casos de los tomos:**
resultado del ejercicio → absorción de pérdidas acumuladas (art. 93) → IRE 10 % →
reserva legal 5 % hasta el tope del 20 % (no gravada por IDU) → reservas estatutarias o
facultativas → dividendos (IDU 8 % / 15 %).

## 8. Laboral y seguridad social

### 8.1 Salario mínimo 🔴

- **Decreto 6225/2026**, del **17 de junio de 2026**, reajuste del **5 %**.
- Vigente **desde el 1 de julio de 2026**:
  - **Salario mínimo mensual (actividades diversas no especificadas): G. 3.044.000**
  - **Jornal mínimo: G. 117.077**
- Valor anterior, por Decreto 4122/2025: G. 2.899.048. Útil para ejercicios comparativos.
- Las actividades especificadas y las profesiones escalafonadas se reglamentan **por
  resolución separada del MTESS**: no inventar cifras por rubro.
- Base normativa: Código del Trabajo (Ley 213/1993), Ley 5764/2016 (art. 255), Ley
  6339/2019 (empleo a tiempo parcial).
- **Este es el número que más rápido se vuelve viejo.** Verificar en junio-julio de cada año.

### 8.2 IPS 🟢 (base 🔴)

- **Aporte obrero: 9 %** del salario bruto, descontado al trabajador.
- **Aporte patronal: 16,5 %** (14 % IPS + 2,5 % Ministerio de Salud Pública), a cargo
  exclusivo del empleador. **No puede descontarse al trabajador.**
- Total sobre el salario: **25,5 %**.
- La base mínima de cálculo es el salario mínimo vigente: si el trabajador gana menos, se
  le descuenta el 9 % de su salario real y el empleador completa hasta el 9 % del mínimo.
- La base imponible incluye remuneraciones normales y variables habituales; en general
  **excluye el aguinaldo**.
- Jubilación ordinaria: 60 años con 25 de aportes, o 55 años con 30 de aportes.

**Ejercicio de planilla — cifras coherentes al 13-ago-2026:** sobre un salario mínimo de
G. 3.044.000, aporte obrero G. 273.960 y aporte patronal G. 502.260; costo total para el
empleador G. 3.546.260. Verificar el salario mínimo antes de reusarlas.

### 8.3 Otros conceptos laborales 🟢

- **Aguinaldo:** un salario mensual, pagadero antes del 31 de diciembre; exonerado del IRP.
- **Bonificación familiar:** 5 % del salario mínimo por hijo (Ley 6338/2019).
- **Vacaciones:** 12 días hábiles hasta los 5 años de antigüedad; escalonan luego.
- Recargos: hora extra diurna +50 %, nocturna y feriados +100 %, recargo nocturno 30 %.
  Verificar contra el Código del Trabajo antes de armar una liquidación completa.

## 9. Regímenes especiales y marco digital

### 9.1 Maquila 🟡

- Norma vigente: **Ley 7547/2025 «Del Régimen de Maquila»**, del **8 de setiembre de 2025**,
  reglamentada por el **Decreto 5714/2026**.
- Sustituye a la **Ley 1064/97**, que queda derogada en lo que se le oponga **transcurridos
  12 meses** desde la migración prevista en el art. 42; los programas vigentes conservan
  sus derechos adquiridos hasta su conclusión. Es decir: durante 2026 hay **transición**,
  no corte seco. Si el tomo lo menciona, decirlo así.
- **Tributo Único de Maquila: 1 %**. La Ley 7547/2025 modificó la determinación de la base
  imponible respecto del esquema anterior: verificar antes de plantear un cálculo numérico.
- Novedad relevante para Informática y Administración: incorpora la **maquila de
  servicios** — software, BPO, soporte técnico global, consultoría transfronteriza.
- Órgano: CNIME, con representantes de DNIT, BCP y MTESS, entre otros. Sistema: SIMEX.

### 9.2 Protección de datos personales 🟢

- **Ley 7593/2025**, promulgada el **27 de noviembre de 2025**. Primer marco integral del
  país, para sector público y privado.
- **Vigencia diferida: 24 meses (art. 57) → desde el 27/11/2027.** Hasta esa fecha
  **no se la presenta como «vigente»** ni se la incluye en un «marco legal vigente»: se
  estudia como «norma publicada el 27/11/2025, con entrada en vigencia diferida hasta el
  27/11/2027 conforme a su artículo 57». Fue hallazgo CRÍTICO en el Plan Anual de Software
  1.º (oct-2026).
- Crea la **Agencia Nacional de Protección de Datos Personales**, adscrita al **MITIC**.
- Derechos del titular: acceso, rectificación, supresión, oposición, portabilidad.
- Obligaciones del responsable: consentimiento libre, previo, expreso e informado;
  transparencia; medidas de seguridad; protocolos ante incidentes; registro de tratamiento;
  límites de conservación; Evaluación de Impacto en los casos exigidos (biometría,
  monitoreo a gran escala).
- Alcance **extraterritorial**: alcanza a responsables no establecidos en el país que
  ofrezcan bienes o servicios a residentes o monitoreen su comportamiento en territorio
  paraguayo.
- **Menores — dato clave para los tomos de Informática:** el tratamiento de datos de
  menores de **16 años** requiere consentimiento previo, expreso e informado del titular de
  la patria potestad, guarda o tutela. Entre 16 años y la mayoría de edad, para datos
  **sensibles** se requiere consentimiento del adolescente **más** autorización del adulto
  responsable. Encaja directo en la clase de ciudadanía digital.
- **No deroga** la Ley 4868/2013 de Comercio Electrónico: la complementa. Los datos
  crediticios siguen fiscalizados por el BCP.
- ⚠️ **Pendiente de confirmar:** la duración exacta de la *vacatio* y la fecha desde la cual
  la Agencia puede sancionar. Hasta confirmarlo, redactar sin fecha: «la ley prevé un
  período de adecuación antes del inicio de la actividad sancionadora».

### 9.3 Mercado de valores 🟡

- Norma vigente: **Ley 7572/2025 «Mercado de Valores y Productos»**, promulgada el
  **7 de noviembre de 2025**.
- **Autoridad de aplicación: el Banco Central del Paraguay**, que la ejerce **a través de
  la Superintendencia de Valores (SIV)**, organismo técnico dentro de la estructura del BCP.
- **La Comisión Nacional de Valores (CNV) ya no existe.** Cualquier material que la
  mencione como reguladora está desactualizado. Tampoco corresponde ya citar la Ley
  1284/98 como marco vigente.
- La ley compendia en un solo régimen: mercado de valores, fondos patrimoniales de
  inversión, bolsas de productos, sociedades securitizadoras y calificadoras de riesgo.
  Incorpora productos, servicios y actividades de inversión, y habilita tecnología de
  registros distribuidos (DLT).
- El Superintendente de Valores es designado por el Poder Ejecutivo de una terna del
  Directorio del BCP; dura 5 años y puede ser reelecto.
- La reglamentación se abrió a consulta pública tras la promulgación: hay resoluciones
  SIV posteriores. Verificar antes de dar detalle operativo.

## 10. Lista negra — normas derogadas y errores de cita

Cualquiera de estos en un tomo es **fallo de auditoría**:

| No escribir | Escribir |
|---|---|
| SET | DNIT (Ley 7143/2023) |
| IRACIS, IRAGRO, IMAGRO, tributo único | IRE (Ley 6380/2019) — Libros I, III y IV de la Ley 125/91 derogados por su art. 153 |
| «Ley 121/91» | **No existe.** El impuesto inmobiliario está en el **Libro II de la Ley 125/91**, que sigue vigente |
| Impuesto a la Renta del Servicio de Carácter Personal | IRP (Ley 6380/2019) |
| CNV — Comisión Nacional de Valores | SIV — Superintendencia de Valores, dentro del BCP (Ley 7572/2025) |
| Ley 1284/98 como marco del mercado de valores | Ley 7572/2025 |
| Ley 5810/2017 | Derogada por la Ley 7572/2025 |
| Ley 1064/97 de maquila como norma vigente | Ley 7547/2025 + Decreto 5714/2026 (con transición) |
| Acciones al portador | Acciones nominativas (Ley 5895/2017) |
| Depósito del 25 % en el BNF | Depósito en el **BCP** (art. 1059 CC) |
| S.R.L. o S.A. «pueden optar por el SIMPLE» | S.R.L. y S.A. liquidan **solo por el Régimen General** |

**Qué sí sigue vigente de la Ley 125/91:** el **Libro II** (Impuesto Inmobiliario) y el
**Libro V** (disposiciones generales, infracciones, sanciones y procedimiento, arts. 155 y
siguientes). Citar la Ley 125/91 no es un error en sí: lo es citar sus libros derogados.

## 11. Aplicación a las sagas de los tomos

Las tres sociedades de la progresión didáctica y su tratamiento correcto:

| Etapa | Caso CyLA | Caso Ñandutí | Régimen IRE | IDU | Reserva legal | Estados financieros |
|---|---|---|---|---|---|---|
| 1.er curso | Arasy (unipersonal) | Casa Ñandutí unipersonal | RESIMPLE si ≤ 80 M; SIMPLE si ≤ 2.000 M | **No contribuyente** si SIMPLE o RESIMPLE | No aplica | No exigidos |
| 2.º curso | Yvoty S.R.L. | Ñandutí S.R.L. | **GENERAL** | 8 % residentes | 5 % hasta 20 % del capital suscripto | RG 77/2020 |
| 3.er curso | Takuara S.A. | Ñandutí S.A. | **GENERAL** | 8 % / 15 % | Ídem, sobre capital suscripto | RG 77/2020 + notas RG 49/2026 |

El salto de 1.º a 2.º curso es, en términos tributarios, **el paso obligado al Régimen
General**: contabilidad completa, estados financieros, IDU sobre distribuciones y reserva
legal. Ese es el eje narrativo correcto del segundo tomo de ambas sagas.

## 12. Protocolo de re-verificación

Antes de escribir contenido legal en un tomo nuevo:

1. Verificar el **salario mínimo** (🔴, cambia cada julio) y las **tasas de ISC** si se usan.
2. Verificar los ítems 🟡 que el tomo vaya a citar: SIFEN, RG contables, maquila, datos
   personales, mercado de valores.
3. Buscar en la web «[norma] + Paraguay + [año en curso]» y contrastar **al menos dos
   fuentes**, una de ellas oficial (dnit.gov.py, bacn.gov.py, mtess.gov.py, bcp.gov.py,
   ips.gov.py, mic.gov.py).
4. Si la fuente oficial y una secundaria discrepan, **gana la oficial**.
5. Registrar en el pipeline del tomo qué se verificó y en qué fecha.
6. Si la verificación cambia algo de este archivo, **actualizar este archivo en la misma
   sesión** y avisar a Fer qué tomos entregados quedan afectados.

### Control de auditoría (para `auditoria.py`)

Regex de términos prohibidos en el .docx final: `\bSET\b` (como administración tributaria),
`IRACIS`, `IRAGRO`, `IMAGRO`, `Ley 121/91`, `Comisión Nacional de Valores`, `\bCNV\b`,
`acciones al portador`, `Ley 1064/97` (salvo en contexto histórico explícito), `BNF`
(en contexto de depósito constitutivo). Cualquier coincidencia ⇒ fallo.


## Anexo oct-2026 — Software sin licencia (materias de Informática)

- La copia o el uso de un programa sin licencia **puede implicar infracción** de la
  **Ley 1328/98** de Derecho de Autor. En las consignas que mezclan lo legal con lo
  técnico conviene escribir «puede implicar infracción» y no afirmar la infracción en
  abstracto.
- **Windows no genuino SÍ recibe las actualizaciones críticas de seguridad** (Microsoft,
  «Acerca de Windows original»). Lo que se reserva al software original son otras
  actualizaciones, descargas y beneficios. Es **incorrecto** escribir que una copia
  no genuina «no recibe actualizaciones de seguridad» (hallazgo de la auditoría de
  Software 1.º). El riesgo técnico real son los **activadores no oficiales**, que suelen
  traer programas maliciosos.
- **Grooming**: acercamiento, contacto o manipulación de una persona adulta hacia una
  persona menor de edad con fines sexuales. Hacerse pasar por menor puede ocurrir, pero
  **no** forma parte de la definición: no se la presenta así en las consignas.
