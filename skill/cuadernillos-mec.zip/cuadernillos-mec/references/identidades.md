# Identidades visuales — catálogo y protocolo de deconflicto

Cada materia del catálogo tiene una **identidad**: un nombre (PETRÓLEO, BUGANVILLA,
KA'AGUY) y una paleta de cuatro tonos que gobierna la portada, los títulos, las fichas y
las cajas de todo el tomo. Este archivo fija el catálogo vigente, los tonos que no
pertenecen a ninguna materia, la regla de asignación y los umbrales que ya están
implementados en `scripts/deconflicto_color.py`. **La referencia documenta el script: no
lo reinventa.** Si una cifra de acá y una del script no coinciden, manda el script y este
archivo está desactualizado.

Fuente del catálogo: `Inventario_Maestro_Cuadernillos_94.xlsx`, hoja `Inventario`
(40.ª edición, actualizada el 12-ago-2026): 151 filas de tomo, **74 identidades** y 256
tonos distintos. En el proyecto conviven ocho versiones del inventario (`_87_31` a `_94`);
**sólo vale la de número más alto**. Cualquier deconflicto corrido contra una versión
vieja está mal por definición, porque le faltan identidades.

## 1. Anatomía de una paleta

`helpers.set_identidad(nombre, dark, med, soft, light)` fija los cuatro tonos. Ninguno
puede quedar en `None` si el tomo lleva fichas o cajas: `helpers` los lee sin comprobar.

| Tono | Dónde aparece | Exigencia |
|---|---|---|
| **DARK** | Banda de la portada (fondo, texto blanco 24 pt), color de Heading 1 y Heading 2, rótulo de las tablas largas | Es **el** tono identitario: el único que se deconflicta |
| **MED** | Heading 3, columna de rótulos de la ficha (fondo con texto blanco), título de cada caja, encabezado de las tablas, rótulos de las actividades, borde exterior de las cajas | Legibilidad de texto blanco chico (9,5 pt) sobre él |
| **SOFT** | Bordes de la ficha de clase | Sólo tiene que verse contra el papel |
| **LIGHT** | Fondo de la columna de valores de la ficha y fondo de **todas** las cajas | Casi blanco: texto negro encima |

Los cuatro son de la misma familia de matiz. El DARK y el MED se eligen; el SOFT y el
LIGHT son derivados aclarados del mismo matiz y **no se deconflictan** (§4).

## 2. Tonos fijos — no pertenecen a ninguna materia

Ninguna identidad puede reclamarlos, ni siquiera una materia cuyo matiz natural caiga
cerca. Cambian sólo por decisión de Fer sobre todo el catálogo a la vez.

| Tono | Función | Constante |
|---|---|---|
| **#B8860B** ámbar | Banda de **evaluación de unidad** | `helpers.AMBAR` |
| **#1B4F72** azul | Banda de **evaluación de etapa** (tomo) y bandas de etapa del Plan Anual | `helpers.AZUL` = `plan_anual.AZUL` |
| **#EAF0F6** azul claro | Fila propia de la evaluación de etapa en el Plan Anual | `plan_anual.AZUL_CLARO` |
| **#5D4037** marrón | Cabecera de 7 columnas del Plan Anual | `plan_anual.CABECERA` |
| **#E0F2F1** | Caja tipo `referencia` (texto de referencia propio) | `helpers.REF` |
| **#F2FAFB** | Caja tipo `dp` (antología de dominio público) | `helpers.DP` |
| **#FAF3F3** | Caja tipo `observa` («Observá en el texto») | `helpers.OBS` |
| **#F5F5F5** · **#BFBFBF** · **#555555** / **#595959** | Filas pares de tabla · bordes · texto secundario y epígrafes | neutros de `helpers` |

`catalogo()` inyecta explícitamente las dos bandas (#B8860B y #1B4F72) para que ninguna
identidad nueva aterrice encima. **#5D4037 no está inyectado**: hoy entra al catálogo de
rebote, porque aparece escrito en la columna de notas de una fila. Conviene agregarlo a
`catalogo()` junto a las bandas — hasta que se haga, el resultado depende de que esa nota
siga existiendo.

**Deuda registrada sobre la banda ámbar.** #B8860B tiene contraste 3,25:1 con blanco y el
texto de la banda va en 12,5 pt negrita, que no llega al umbral de «texto grande». Es el
único tono del sistema que no cumple el contraste que se les exige a las identidades
nuevas. Se mantiene porque es una banda corta y estable en todo el catálogo, pero está
anotado acá para que nadie lo tome como precedente al proponer un DARK flojo.

## 3. Reglas de asignación

**Materia nueva ⇒ identidad nueva.** No se recicla el color de otra materia porque «queda
bien» ni porque el tomo sea corto. Vale también para materias que se parecen: Antropología
Cultural (URUNDE'Y) y Antropología Social (ARCILLA) son dos identidades.

**Un mismo tomo, una sola identidad, de la portada al solucionario.** El Plan Anual usa el
color de la materia en las filas de unidad; el Solucionario y el Cuaderno de Laboratorio
usan la misma paleta que el tomo. Lo que los distingue es el rótulo de la portada, no el
color.

**La serie es la norma; el tono por curso es la excepción.** Una materia que se dicta en
varios cursos del mismo programa comparte paleta: PETRÓLEO cubre CyLA 1.º-3.º, GRANA
SANITARIA cubre Atención Básica 1.º-3.º, ANTRACITA cubre Administración BTAN 1.º-3.º. Sólo
tres familias se separaron por curso, y siempre por pedido explícito:

- **Castellano tercer ciclo** — AGUAMARINA 7.º · PALO ROSA 8.º · TINTA SEPIA 9.º
- **Lengua Castellana y Literatura, nivel medio** — BORGOÑA 1.º · BORDÓ 2.º · CARMÍN 3.º
- **Matemática, nivel medio** — ZAFIRO 1.º · NOCTURNO 2.º · AZUL PROFUNDO 3.º

Para eso está `serie()`, que además exige ΔE ≥ 5,5 **entre** los tonos de la serie.

**La especialidad como identidad es la excepción BTI.** El VERDE #1B5E20/#2E7D32 cubre
trece tomos de siete materias distintas del BT Informática: fue una decisión comercial de
serie, se respeta y no se toca. **No se extiende a otras especialidades**: BTCA, BT Salud
y BTAN tienen una identidad por materia. Si aparece un pedido de «hacer como BTI» en otro
programa, se pregunta.

**La propone Claude, la decide Fer.** El deconflicto se corre antes de construir la
portada y se le presenta a Fer con las cifras (§5). Ella puede elegir otra cosa: el DPS
1.er curso del BT lleva la paleta MBURUKUJA del 3.er curso del Científico porque así lo
resolvió.

**Se registra en el inventario.** Columna «Identidad visual», con el nombre y los cuatro
hex separados por ` / `. Si el nombre lleva variante o excepción, va en la misma celda o
en notas, con la cifra de ΔE. Una identidad que no está en el inventario no existe para el
deconflicto siguiente y va a volver a asignarse.

## 4. El deconflicto se aplica al DARK

Ésta es la regla que más fácil se rompe. `verificar()` acepta cualquier lista de tonos,
así que es tentador pasarle los cuatro de la paleta. **No se hace.** Medido hoy contra el
catálogo completo, la paleta PALO ROSA da:

| Tono | ΔE mínimo | Contraste con blanco |
|---|---|---|
| DARK #6A3E46 | **9,38** (vecino #5D4037) | **8,79:1** |
| MED #925663 | 6,77 (vecino #AC505C, CORAL PUBLICITARIO) | 5,62:1 |
| LIGHT #F7EEF0 | 1,08 (vecino #F7ECEF, VINO 3.º) | 1,14:1 |

Los LIGHT de las 74 identidades están todos a ΔE < 2 entre sí **por construcción**: son
tonos casi blancos, y el espacio de «casi blanco» no da para 74 casillas distinguibles.
Exigirles ΔE ≥ 8 rechazaría cualquier paleta correcta. El MED queda en tierra de nadie: se
**informa** para revisar su contraste, pero no bloquea.

Se deconflicta el DARK, que es el que el estudiante ve a treinta centímetros en la tapa.

## 5. Umbrales

Los valores por defecto de `buscar()` son `L_min=20`, `L_max=45`, `C_min=15`,
`contraste_min=7.0`, `delta_min=8.0`, `paso=4`; los de `serie()`, `delta_mutuo=5.5`.

| Control | Umbral | Si no se cumple |
|---|---|---|
| ΔE CIEDE2000 del DARK contra la **mochila** | **≥ 8** | Rechazo. Se busca otro tono, sin excepción |
| ΔE del DARK contra el **catálogo global** | ≥ 8 deseable | Entre 5,5 y 8 se admite **sólo** si el vecino está en otro programa **y** otro nivel, y se registra la cifra en el inventario |
| ΔE del DARK contra cualquiera | **< 5,5 ⇒ rechazo** | Salvo serie deliberada declarada de antemano |
| ΔE mutuo dentro de una serie | ≥ 5,5 | Se rearma la serie con `serie()` |
| Contraste del DARK con blanco | **≥ 7:1** | Rechazo: la portada lleva texto blanco de 24 pt y la ficha, blanco de 9,5 pt |
| L\* del DARK | 20–45 | Fuera de rango no es un tono de portada |
| Croma C\* del DARK | ≥ 15 | Menos que eso es un gris y no identifica nada |

**La mochila es el control que importa.** `verificar(cat, tonos, mochila=[...])` recibe los
DARK de todos los tomos que el mismo estudiante lleva ese año — mismo programa, mismo
curso. Dos identidades a ΔE 4 en programas que nunca se cruzan son un problema de
planilla; dos identidades a ΔE 4 en la misma cartuchera son un problema del estudiante.

**Por qué el umbral global es deseable y no bloqueante.** Con 74 identidades en la franja
L\* 20-45 y contraste ≥ 7:1, el espacio está saturado: hoy hay más de ochenta pares de
DARK por debajo de ΔE 8 en el catálogo. Exigir 8 global de forma absoluta haría imposible
cualquier identidad nueva. Por eso el orden es: mochila primero (duro), global después
(informado y registrado).

**Caso de referencia.** PALO ROSA, Castellano 8.º: ΔE mín **9,38** contra #5D4037 y
contraste **8,79:1**. Es el número que sirve para verificar que el script sigue sano —
recalculado excluyendo su propia fila del catálogo, tiene que volver a dar eso.

**Precedente de la banda 5,5-8.** MALVA ACADÉMICA #4A3652 (Inglés optativo, UNC-FCEA) se
aceptó por debajo de 8 contra una identidad de otro nivel. Ojo con la trazabilidad: el
inventario registra «ΔE mín 5,8 vs #6A3E7A», pero recalculado hoy contra el catálogo
completo el vecino más cercano es YVAPURU'Ũ #3E2247 a **6,47**, y contra #6A3E7A
(LAVANDA/CIRUELA) la distancia real es **10,62**. La cifra anotada no reproduce. Al
registrar una excepción hay que guardar **el vecino y la cifra que devolvió el script**,
no una aproximación de memoria.

## 6. Procedimiento

```python
import deconflicto_color as D
INV = '/mnt/project/Inventario_Maestro_Cuadernillos_94.xlsx'   # SIEMPRE la más nueva

cat = D.catalogo(INV)                       # 256 tonos + las dos bandas fijas
cand = D.buscar(cat, hue_min=20, hue_max=60)  # familia de matiz en grados Lab
inf  = D.verificar(cat, ['#6B2C12', '#8C3B1B'],
                   mochila=['#1F2E63', '#2A4A0C', '#531357'])  # DARK del mismo curso
```

1. Elegir la familia de matiz por sentido de la materia, no por gusto: tierra para
   recursos naturales, verde para agro, azul para finanzas, gris para sistemas.
2. `buscar()` sobre esa franja de matiz. Devuelve tonos ya filtrados por contraste,
   luminosidad, croma y ΔE.
3. `verificar()` sobre el DARK candidato (y el MED, para mirarle el contraste), con la
   mochila del curso cargada a mano.
4. Presentarle a Fer **el nombre propuesto, los cuatro hex, el ΔE mínimo con su vecino y
   el contraste**. Sin cifras no es una propuesta.
5. Con el visto bueno: `set_identidad()` en el build y fila del inventario actualizada.

Para una serie graduada, `serie(cat, hue_min, hue_max, franjas=[(38,45),(30,37),(22,29)])`
en lugar de tres `buscar()` sueltos: garantiza el ΔE mutuo de 5,5.

## 7. Conflictos ya presentes en el catálogo

Detectados al correr el deconflicto sobre el inventario 94. No son hipótesis: están en
tomos entregados.

| ΔE | Par | Gravedad |
|---|---|---|
| **0,00** | CEDRÓN #33691E (Educación Física 7.º-9.º) ≡ SAVIA #33691E (Cs. de la Naturaleza y Salud 7.º-8.º) | **Alta — mismo hex, misma mochila.** Un chico de 7.º lleva las dos tapas idénticas |
| 1,16 – 2,34 | ZAFIRO / NOCTURNO / AZUL PROFUNDO (Matemática 1.º/2.º/3.º de Media) | Media — declaradas «identidad propia del curso», pero muy por debajo del ΔE mutuo de 5,5 de una serie |
| 1,41 | BUGANVILLA #7B1145 (Matemática 7.º-9.º) vs MBURUKUJÁ #7E1946 (DPS 2.º de Media) | Baja — distinto nivel, no coinciden en mochila |
| 3,94 | MBURUKUJA #8E1F55 (DPS 3.º y DPS 1.º BT) vs MBURUKUJÁ #7E1946 (DPS 2.º) | Media — misma materia, dos nombres casi iguales con y sin tilde y dos paletas distintas: se unifica o se separa, pero no las dos cosas |
| 4,07 | COBRE #9C4722 (Adm. Empresas BTC) vs TERRACOTA #A84B2F (Introducción a la Economía 3.º BTC) | **Media-alta — mismo programa y mismo curso**: conviven en 3.º BTC |
| 2,69 / 3,01 | AGUAMARINA #006064 vs PETRÓLEO #0E5A5A y PETRÓLEO CLARO #12666E | Baja — programas y niveles distintos |

Al abrir una identidad nueva no hay que arreglar esto de paso; se arregla cuando Fer
decida tocar esos tomos. Lo que sí corresponde es **no agregar el par número 87**.

## 8. Catálogo completo — materia → identidad

Nombre e hex tal como están registrados. Cuando la celda del inventario trae menos de
cuatro tonos, es que la paleta completa quedó sólo en el binario del tomo: se recupera de
ahí antes de reusarla, **no se reconstruye a ojo**.

### Bachillerato Técnico en Contabilidad (BTC)

| Identidad | Paleta | Cubre |
|---|---|---|
| **PETRÓLEO** | #0E5A5A / #147D7D / #7FB8B8 / #E7F3F3 | Contabilidad y Legislación Aplicada 1.º-3.º |
| **VINO** | #4A1223 / #6D1B33 / #B07484 / #F3E7EA | Seminario Contable 1.º-3.º |
| **BRONCE/DORADO** | *sin hex en el inventario* | Cálculo Mercantil y Financiero 1.º-3.º |
| **COBRE** | #9C4722 / #6E3018 / #C98B6B / #F6ECE6 | Administración de Empresas 2.º-3.º |
| **ACERO** | #263238 / #455A64 / #78909C / #ECEFF1 | Informática 1.º-3.º |
| **TERRACOTA** | #A84B2F | Introducción a la Economía 3.º |
| **OLIVA** | #556B2F | Sociología y Antropología Cultural 1.º (plan común del BT) |

### BT Informática (BTI, Diseño Curricular may-2026)

| Identidad | Paleta | Cubre |
|---|---|---|
| **VERDE** | #1B5E20 / #2E7D32 | Administración Financiera 2.º-3.º · Algorítmica 1.º-3.º · Dibujo Técnico 1.º · Gabinete Hardware 2.º · Gabinete Laboratorio 1.º-3.º · Gabinete Software 1.º · Matemática Aplicada 1.º-2.º |

Trece tomos con una sola identidad: es la excepción de serie del §3. Gabinete Software 2.º
figura sin identidad declarada y Matemática Aplicada 3.º está pendiente.

### BT Administración de Negocios (BTAN)

| Identidad | Paleta | Cubre |
|---|---|---|
| **AZUL** | #0D47A1 | Contabilidad y Gabinete de Gestión 1.º-3.º (serie Kuñataî) |
| **ANTRACITA GERENCIAL** | #2B2B31 / #52525C / #9494A0 / #F1F1F4 | Administración de Empresas 1.º-3.º |
| **CORAL PUBLICITARIO** | #AC505C / #D4655C / #F0A093 / #FDEFEB | Mercadotecnia 2.º-3.º |
| **CIAN DIGITAL** | #00485C / #00A0BF / #6ECBDD / #E2F6FB | Informática 1.º-2.º |
| **OCRE MONEDA** | #4C3204 / #70480B / #B08A3C / #F8F1E1 | Economía 1.º-2.º |

### BT Ciencias Ambientales (BTCA)

| Identidad | Paleta | Cubre |
|---|---|---|
| **KA'AGUY** | #0B5D3B / #12805A / #5FBF95 / #E9F6F0 | Legislación Ambiental 2.º-3.º |
| **TIERRA COLORADA** | #6B2C12 / #8C3B1B / #C0714E / #F8EDE6 | Adm. de los Recursos Naturales · Rec. Geológicos y Edafológicos 1.º-3.º |
| **ÍNDIGO PROYECTO** | #1F2E63 / #33478C / #7A8BC4 / #ECEFF8 | Diseño y Elaboración de Proyectos · Economía Ambiental 1.º-3.º |
| **VERDE KOKUE** | #2A4A0C / #3B7D0A / #AFCC84 / #EFF6E3 | Agroecología · Meteorología · Biología General 2.º-3.º |
| **CIRUELA INVESTIGACIÓN** | #531357 / #7B2680 / #C08BC6 / #F6ECF8 | Metodología de la Investigación · Sociología Rural y Urbana 1.º-3.º |
| **ÁMBAR TRIGO** | #584D20 / #A16000 / #E6D17E / #FBF3D9 | Tecnología Alternativa · Industrias Alimentarias Orgánicas 3.º (ΔE mín 13,8) |
| **SERIE BTCA (neutra)** | #2E3B33 / #47605A / #8FA8A0 / #EDF2F0 | Ficha del Territorio Integrador (pieza canónica de serie) |

El 2.º curso de Metodología quedó con una variante distinta (#4E0B3F / #7E1466 / #C58BB4 /
#F7ECF4) marcada en el inventario **«variante a corregir»**: al tocar ese tomo se unifica
con #531357.

### BT en Salud (Salud Comunitaria) y BTS

| Identidad | Paleta | Cubre |
|---|---|---|
| **GRANA SANITARIA** | #8E1B22 / #B92B32 / #E39A9D / #FCECEC | Atención Básica de Salud 1.º-3.º |
| **AZUL FRASCO** | #0D3B66 / #1D6FA3 / #6FA8CC / #E8F1F8 | Farmacología 1.º |
| **VERDE QUIRÚRGICO** | #1F5C52 / #2E8577 / #8FC2B7 / #E9F4F1 | Anatomía y Fisiología 1.º |
| **MANDARINA/ZAPALLO** | #9E4409 / #DE7411 / #F3B673 / #FDF3E7 | Nutrición 2.º |
| **CRUZ** | #B71C1C / #C62828 | Salud Pública y Comunitaria 1.º |
| **VERDE SANITARIO OSCURO** | #0E4429 / #17734B / #7FBB9C / #E9F5EE | Salud Pública y Comunitaria 2.º |
| **PINO SANITARIO** | #0F3D2E / #1A5E46 / #7BB8A0 / #E8F4EE | Salud Pública y Comunitaria 3.º |
| **PLOMO CLÍNICO** | #3A3F55 / #565D7A | Patología 3.º |
| **TURQUESA COMUNITARIO** | #0B7285 / #0E8A9E / #6FBFCC / #E6F5F7 | Educación para la Salud 1.º y 3.º |
| **VERDE HOJA** | #4A6B0C / #6E9A14 | Biología 2.º (BTS) |
| **ARENA / TIERRA CLARA** | #806036 / #A98652 / #D3B98A / #F8F1E4 | Práctica Comunitaria 3.º (BTS) |

Salud Pública y Comunitaria es el único caso del catálogo con **tres identidades para una
misma materia**, una por curso, sin serie declarada. Está así en producción; se documenta,
no se cambia sin pedirlo.

### BT Mecánica (BTM) y otros técnicos

| Identidad | Paleta | Cubre |
|---|---|---|
| **LADRILLO** | #BF360C | Administración de Empresas 1.º (BTM) |
| **MORADO PIXEL** | #3B0F5C / #8E3FD6 / #B57BE8 / #F4EBFC | Informática 1.º-2.º (BTM) |
| **AZUL FRANCIA** | #0B33C4 / #2E5BD8 / #5A86EA / #EAF0FE | Contabilidad 3.º (BTM) |

### Plan común — tercer ciclo (7.º, 8.º, 9.º)

| Identidad | Paleta | Cubre |
|---|---|---|
| **INDIGO** | #1A237E / #283593 / #3949AB / #E8EAF6 | Formación Ética y Ciudadana 7.º-9.º y 1.º-2.º de Media |
| **PIZARRA** | #21374D / #3D5A80 / #6B8CAE / #E6EBF1 | Historia y Geografía 7.º-9.º |
| **BUGANVILLA** | #7B1145 / #AD1457 | Matemática 7.º-9.º |
| **SAVIA** | #33691E / #558B2F / #7CB342 / #F1F8E9 | Ciencias de la Naturaleza 7.º-8.º · Salud 7.º-8.º |
| **QUEBRACHO** | #00695C | Ciencias de la Naturaleza y de la Salud 9.º |
| **CEDRÓN** | #33691E | Educación Física 7.º-9.º — *colisión exacta con SAVIA, §7* |
| **LAVANDA/CIRUELA** | #6A3E7A | Desarrollo Personal y Social 7.º-9.º |
| **ARTE / NARANJA ARTÍSTICO** | #E65100 | Educación Artística 7.º-9.º |
| **CIRUELA** | #5D2A4A / #8A3D6E / #B072A0 / #F4E9F1 | Trabajo y Tecnología 7.º |
| **VOLTAJE** | #01579B / #0288D1 / #4FC3F7 / #E1F5FE | Trabajo y Tecnología 8.º-9.º |
| **AGUAMARINA** | #006064 | Lengua y Literatura Castellana 7.º |
| **PALO ROSA** | #6A3E46 / #925663 / #C49AA5 / #F7EEF0 | Lengua y Literatura Castellana 8.º |
| **TINTA SEPIA** | #5D482D / #867644 / #C9AD72 / #F8F3E6 | Lengua y Literatura Castellana 9.º |

Guaraní Ñe'ẽ 7.º-9.º está postergado y sin identidad asignada.

### Nivel medio — Científico, plan común

| Identidad | Paleta | Cubre |
|---|---|---|
| **ZAFIRO** | #102A54 / #1D4E9B / #7FA6D9 / #E9F0FA | Matemática 1.º |
| **NOCTURNO** | #14315C / #2A5DA0 / #7FA6D6 / #EAF1FA | Matemática 2.º |
| **AZUL PROFUNDO** | #0B2E59 / #1B5299 | Matemática 3.º |
| **BORGOÑA LITERARIO** | #5C1A38 / #83294F / #BE7F9D / #F8EEF3 | Lengua Castellana y Literatura 1.º |
| **BORDÓ LITERARIO** | #7A1F1F / #9C2B2B / #C98080 / #FBEAEA | Lengua Castellana y Literatura 2.º |
| **CARMÍN LITERARIO** | #A01838 / #C62F4E / #E58399 / #FBE7EB | Lengua Castellana y Literatura 3.º |
| **PAVO REAL** | #045C7C / #0A7E9E / #55AEC4 / #E3F4F8 | Lengua Extranjera: Inglés 1.º y 3.º |
| **AMATISTA** | #8E24AA / #A83FC0 / #C99AD9 / #F7EDFA (3.º) · #702963 / #9B3D8C / #C77FBC / #F7EAF5 (2.º) | Química 2.º-3.º — dos variantes bajo un solo nombre |
| **ACERO CLARO** | #2F4858 / #4E7285 / #8FB0BF / #EDF3F6 | Física 2.º-3.º |
| **MUSGO** | #37471F / #6A8535 | Ciencias Naturales y Salud 1.º-2.º |
| **JACARANDÁ** | #4527A0 / #5E35B1 / #9575CD / #EDE7F6 | Artes y sus Tecnologías 1.º-2.º |
| **VIOLETA** | #4A148C | Filosofía 2.º |
| **MOSTAZA** | #6E5A12 / #A07C14 / #D4B24A / #FBF3DE | Economía y Gestión 3.º |
| **MBURUKUJA** | #8E1F55 / #C2185B / #E58AAE / #FCE9F0 | DPS 3.º Científico y DPS 1.º BT |
| **MBURUKUJÁ** | #7E1946 / #B01F5F / #E28BB0 / #FCEAF2 | DPS 2.º Científico — *§7* |

### Nivel medio — plan específico Ciencias Sociales, optativas y otros

| Identidad | Paleta | Cubre |
|---|---|---|
| **URUNDE'Y** | #4E342E / #795548 / #A1887F / #EFEBE9 | Antropología Cultural 1.º |
| **ARCILLA** | #7B4A3F / #A9695A / #D2A294 / #F9EFEB | Antropología Social 1.º |
| **PETRÓLEO CLARO** | #12666E | Estadística 1.º |
| **SEÑAL VIAL** | #1C1C1C / #6E4E00 / #F9A825 | Educación para la Seguridad Vial 1.º |
| **ESMERALDA / verde billete** | #046A4E / #0E9070 / #57C0A2 / #E6F7F1 | Educación Económica y Financiera 3.º |
| **YVAPURU'Ũ** | #3E2247 / #6A3A73 / #A987B0 / #F2EBF4 | Seguridad Social 3.º (Plan Optativo) |
| **LAPACHO** | #4A1F3D / #7A3560 / #B87FA0 / #F6EBF2 | Castellano 3.er Ciclo EBBPJA |
| **BORDÓ ACADÉMICO** | #7B1E3B | Comunicación II (UNVES, universitario) |
| **MALVA ACADÉMICA** | #4A3652 / #6B4E78 / #A98FB4 / #F2ECF5 | Inglés optativo (UNC-FCEA, universitario) |

Identidad retirada: **OLIVA/TERRACOTA** #5B6B4F / #A85C32, de Antropología Social y
Cultural 1.º, reemplazada. Los tonos retirados siguen en el catálogo del deconflicto y eso
está bien: evita que una materia nueva agarre el color de un tomo que puede volver.

## 9. Huecos del catálogo

Al correr el deconflicto conviene tener presente qué falta, porque son las próximas
identidades a definir o a recuperar:

- **BRONCE/DORADO** (Cálculo Mercantil 1.º-3.º) sin ningún hex registrado. Tres tomos
  cerrados cuya paleta sólo vive en el binario: recuperarla e inscribirla.
- **Gabinete Software 2.º (BTI)** con la celda de identidad vacía; por serie le corresponde
  VERDE, pero está sin declarar.
- **Matemática Aplicada 3.º (BTI)** pendiente, y **Matemática Aplicada 2.º** a rehacer por
  contenido, no por color.
- **Guaraní Ñe'ẽ 7.º-9.º** postergado, sin identidad.
- **Química 2.º vs 3.º** comparten el nombre AMATISTA con dos paletas distintas: o son dos
  nombres o son una serie.
