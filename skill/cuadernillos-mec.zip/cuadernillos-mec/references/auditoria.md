# Auditoría de liberación del tomo

Se corre **antes de entregar**, sobre los archivos finales, en un script `auditoria.py`
propio de cada materia guardado junto al build. **El criterio de liberación del tomo es
cero fallos**, no un puntaje: si un control falla, se arregla el origen y se regenera.

(El esquema de 100 puntos con áreas ponderadas es el de los **Planes de Clase**,
`references/plan-de-clase.md` §12. No se mezclan: son documentos distintos con criterios
distintos.)

## 0. Regla del auditor

**Todo control nuevo se valida contra un caso conocido antes de usarse como criterio de
liberación.** En la primera corrida de la auditoría de los 26 planes, tres de los cuatro
fallos eran **controles mal escritos**, no defectos del documento. Un control mal formulado
produce un falso crítico y frena una entrega correcta; y peor, enseña a ignorar la salida
de la auditoría.

Corolarios prácticos:

- Un control que falla se investiga **mirando el documento**, no arreglando el documento.
- Los recuentos por página confunden páginas de inicio con páginas de continuación.
- Un elemento puede aparecer dos veces legítimamente (la diagnóstica figura como contenido
  y como recurso).
- La auditoría imprime siempre el **detalle** del fallo, no sólo el booleano: sin el número
  encontrado contra el esperado no se puede distinguir un defecto de un control mal hecho.

## 1. Estructura del script

```python
R = []
def chk(bloque, nombre, cond, critico=False, detalle=''):
    R.append((bloque, nombre, bool(cond), critico, detalle))
```

Se audita sobre **tres fuentes a la vez**, porque cada una ve cosas distintas:

1. **El objeto `python-docx`** — estilos, tablas, secciones, propiedades.
2. **El XML crudo** (`zipfile` sobre `word/document.xml` y `word/settings.xml`) — es la
   única forma de contar `cantSplit`, `tblHeader`, `tblGrid` y el orden de `updateFields`.
3. **El render PDF** — `soffice --headless --convert-to pdf` y después `pdftotext -layout`.
   Es la única fuente que muestra **paginación real**: bloques perdidos, filas caídas,
   fichas partidas. El PDF es instrumento de auditoría; **el entregable es siempre el
   .docx**.

Herramientas disponibles: `pdftotext`, `pdftoppm` (para mirar una página a ojo cuando el
texto no alcanza), `pdfimages` (contar figuras) y `tesseract` (OCR cuando hay que verificar
qué dice una imagen).

Cierre del script: total de controles, lista de fallos con su detalle, y
`sys.exit(1 if fallos else 0)`.

## 2. Bloque A — Integridad estructural

- El tomo tiene **todas** las clases del programa, numeradas de forma **continua** y sin
  saltos ni repeticiones.
- Orden canónico presente y en su lugar: portada → presentación → índice (campo TOC) →
  salto → **prueba diagnóstica en página propia** → salto → unidades.
- La diagnóstica **no** está adentro de la Clase 1 y lleva la línea de que **no lleva nota**.
- Cada clase abre con su **ficha** de Capacidad / Tema / Indicadores.
- **Cobertura de capacidades del programa: 100 % y textual.** Se transcriben todas las
  capacidades del programa oficial, una por una, y se comprueba que cada una aparezca
  **literal** en el tomo, en los Planes de Clase y en el Plan Anual
  (`plan_anual.verificar_capacidades`). Se buscan también las fusiones («… y reflexiona
  sobre …», «… y las ventajas de los actuales») y los recortes («entero» en lugar de
  «entero o fraccionario»). Las capacidades transversales, como «Reconoce la importancia
  de la capacidad de abstracción, análisis y síntesis…», también cuentan: en Software 1.º
  era la única que faltaba y fue un hallazgo CRÍTICO.
- `assert len(FICHAS) == N_CLASES` — el mismo control que habilita el Plan Anual.
- Cada unidad cierra con su **evaluación de unidad**; cada etapa, con la suya.
- Portada: sin ciudad, departamento, institución ni docente; cierra con
  `República del Paraguay · 2026`.

## 3. Bloque B — Paginación y formato

Éste es el bloque que sólo se puede auditar **en el render**.

- **Ninguna ficha partida entre páginas.** Se protege con `cantSplit` + `keepNext`; ojo con
  que `cantSplit` impide que se parta una **fila**, pero **no** impide que la tabla se corte
  entre dos filas.
- **Ninguna banda de evaluación separada de su contenido.**
- **Ninguna tabla con filas perdidas.** Defecto conocido: LibreOffice **descarta filas en
  silencio** cuando el encabezado de la tabla cae al pie de una página. Se detecta contando
  filas en el XML contra filas en el render, y se arregla forzando el salto **antes** del
  rótulo (`add_table_md(..., rotulo=..., forzar_salto_antes=True)`).
- **Ningún rótulo huérfano** al pie: el rótulo de una tabla larga tiene que ir en la misma
  página que su primera fila.
- **`cantSplit` en el 100 % de las filas del tomo.** Única excepción histórica: la fila de
  la portada. Se cuenta `<w:cantSplit` contra el total de `<w:tr`.
- **Cada evaluación empieza al tope de una página propia.**
- Pie con **campos reales** PAGE/NUMPAGES en todas las páginas; nunca texto literal, y
  nunca asignar `r.text` a un run que contiene `fldChar` (destruye el campo).
- `updateFields=true` **antes** de `w:compat` en `settings.xml`.
- Campo TOC presente (`TOC \o`).
- Ninguna tipografía por debajo del mínimo; fuente explícita, no heredada del tema.
- Todas las figuras citadas en la prosa **existen**, y todas las figuras insertadas están
  citadas. Conteo cruzado con `pdfimages`. También se buscan referencias duplicadas
  («Figuras 5.2 y 5.2») en los Planes de Clase.
- **Papel oficio, márgenes de 1,27 cm y tablas al 100 %** en el tomo; el PDF tiene el
  **mismo tamaño de papel** que el DOCX (`pdfinfo` → 612 × 936 pts).
- **Ninguna página interior ocupada en menos del 25 %** (`paginacion.casi_vacias`), ni
  páginas en blanco. No queda ningún salto de página en un párrafo vacío propio.
- **Índice poblado y exacto**: `indice_pdf.actualizar()` sobre el PDF final informa
  «cambiadas 0». Sin la leyenda «Ctrl+E / F9».
- Ningún subtítulo de actividades huérfano al pie («Respondé y fundamentá:» sin ítems).

## 4. Bloque C — Coherencia aritmética

Vale para todo tomo con números: contabilidad, cálculo mercantil, economía, matemática,
administración, y cualquier clase con un caso numérico.

- Los números del caso integrador se diseñaron **de atrás hacia adelante** desde la cifra de
  cierre, y eso se verificó con asserts **antes** de escribir el contenido — no después.
- **Coherencia transversal**: un mismo saldo que aparece en varias clases tiene que ser
  idéntico en todas. El balance de la clase 18 tiene que cerrar con los asientos de la
  clase 4.
- Balances, sumas y saldos, mayores, asientos de cierre y de reapertura: verificados
  programáticamente, no a ojo.
- La verificación vive en un `caso.py` con los asserts, y la auditoría lo **vuelve a
  correr**: no alcanza con que haya corrido bien una vez, porque el contenido se editó
  después.
- Los mismos números aparecen igual en el tomo y en el Solucionario.
- **Unicidad de datos** (`scripts/unicidad_datos.py`), en todas las materias con números y
  obligatoria en gabinete:
  - `operaciones_repetidas()` sobre cada unidad: 0 pares de operaciones que compartan dos o
    más de sus tres números, fuera de los productos parciales de un mismo ejemplo resuelto.
  - `firmas_repetidas()` sobre ejemplos, actividades, prácticas, fichas y evaluaciones:
    0 bloques que compartan dos o más datos con unidad.
  - Cada dato nuevo, incluido el que proponga el auditor, se valida contra la unidad entera
    antes de escribirlo.

## 5. Bloque D — Coherencia tomo ↔ solucionario

- **Opciones múltiples.** El tomo y el Solucionario comparten la **misma semilla** de
  `barajar_opciones(eval_id, enunciado, opciones)`. La auditoría vuelve a llamar a la
  función con los mismos argumentos y compara la letra resultante contra la clave impresa
  en el Solucionario: si divergen, es porque en algún lado se barajó o se escribió a mano.
- **Distribución de las correctas** repartida entre a, b, c y d — no todas en la misma letra.
- **Cobertura**: hay clave para **todos** los ítems de todas las evaluaciones y de todas las
  actividades cerradas.
- El Solucionario abre con las **orientaciones para corregir la diagnóstica**, después las
  claves por clase y al final las de las evaluaciones.
- Su portada dice `Solucionario · Material exclusivo del docente`, nunca la leyenda del
  estudiante.
- **En el material del estudiante no hay ninguna clave ni rúbrica.** Se busca en el texto
  del tomo: «Respuesta:», «Clave», «Solución:», «Rúbrica».

## 6. Bloque E — Contenido, lengua y residuos

- **Terminología legal vigente.** Se busca en el texto la lista negra de
  `references/doctrina-legal.md` §10: normas derogadas y errores de cita (IRACIS, IMAGRO,
  SET donde va DNIT, CNV donde va SIV, «Ley 121/91», Ley 1064/97, Ministerio de Justicia y
  Trabajo). Cualquier aparición es fallo.
- **Régimen societario**: la doctrina corregida del §1 de `doctrina-legal.md` — el SIMPLE no
  es para S.R.L. ni S.A. Control específico en todo tomo con casos societarios.
- Los montos en guaraníes son los vigentes y coinciden entre clases.
- **Voseo** en las consignas dirigidas al estudiante; se busca tuteo residual (`tú`,
  `tienes`, `puedes`, `debes`, `haz`).
- **Sin residuos de otra materia o curso**: se busca el nombre de las otras materias del
  catálogo, otros cursos y otros casos integradores. Es el fallo típico de copiar un módulo
  de contenido de un tomo vecino.
- **Sin códigos internos** del pipeline en texto visible (`8-01`, `IMG_014`, rutas).
- **Sin instituciones, ciudades ni nombres propios de docentes.**
- **Registro intermedio**: ninguna clase quedó en «dos párrafos y un cuadro»
  (`estandares-editoriales.md` §1). Es el único control que no cierra con una regex — se
  hace por muestreo, mirando las clases más cortas del tomo.

## 7. Bloque F — Entregables

- Están los archivos del combo con los nombres comerciales (`estandares-editoriales.md` §7):
  LIBRO y SOLUCIONARIO de la edición, PLAN_ANUAL y PLANES_DE_CLASE **sin** edición, cada uno
  en .docx y .pdf, y la muestra comercial regenerada con la paginación nueva. En gabinete
  las prácticas van dentro del libro.
- Metadatos: el autor es «Equipo editorial», nunca «python-docx». El .docx pesa menos de
  25 MB.
- El Plan Anual es **archivo aparte** y pasó sus propios controles
  (`references/plan-anual.md` §6).
- Los tres comparten identidad visual y los datos de portada.
- La **planilla de inventario** está actualizada, con la fila completa del tomo, y los
  rangos de las fórmulas COUNTIF alcanzan las filas nuevas.
- Se avisó si el próximo tomo sigue en este chat o va en uno nuevo
  (`estandares-editoriales.md` §10).

## 8. Salida esperada

```
======================================================================
  A · integridad estructural      13/13
  B · paginación y formato        22/22
  C · coherencia aritmética       76/76
  D · tomo ↔ solucionario          9/9
  E · contenido y residuos        15/15
  F · entregables                  7/7
  TOTAL: 142 controles · 0 fallos
  ESTADO: APROBADO
======================================================================
```

Con un solo fallo, `NO APROBADO`: se corrige el **origen** (módulo de contenido, ficha,
`caso.py`), se regenera el documento entero y se vuelve a correr la auditoría completa. No
se parcha el .docx a mano, porque el siguiente build pisa el parche.
