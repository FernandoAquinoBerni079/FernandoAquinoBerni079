# Estándares editoriales — registro, estructura y anatomía del tomo

Todo lo que hay que tener decidido **antes** de escribir la primera línea de contenido de
un tomo. El pipeline técnico está en `scripts/helpers.py`; el formato del Plan Anual, en
`references/plan-anual.md`; el legal, en `references/doctrina-legal.md`. Acá va la norma
editorial: cuánto se escribe, cómo se arma cada clase, qué se le pide al estudiante y qué
se entrega.

## 1. El registro INTERMEDIO

Es la decisión editorial más importante del catálogo y la que más veces se desvió. Los
cuadernillos se venden a estudiantes de 12 a 18 años que trabajan **sobre el tomo**: no es
un libro de texto para leer ni un cuadernillo de ejercicios para completar. El registro
intermedio es el punto donde el estudiante puede estudiar del tomo sin la clase y también
trabajar en clase sin el manual.

**Qué es.** Por clase: alrededor de cuatro secciones de nivel h2, cada una con una o dos
unidades de prosa corta y directa, una caja de ejemplo o de caso, una tabla, un «Concepto
clave» y un «En Paraguay». Párrafos de tres a cinco líneas; oraciones que no obligan a
releer. El contenido conceptual está **explicado**, no enunciado: si la clase introduce el
IVA, no alcanza con decir que grava el consumo — se dice qué grava, con qué tasa, quién lo
paga y quién lo ingresa, y se muestra un cálculo del caso integrador.

**Qué no es, por abajo.** El contraejemplo tiene nombre en esta casa: **«dos párrafos y un
cuadro»**. Una clase que abre con la ficha, suelta dos párrafos genéricos, mete una tabla
sin comentar y salta a los ejercicios no es una clase: es un índice con relleno. El
estudiante que faltó no puede recuperar nada de ahí y el docente tiene que dictar todo lo
que falta, que es exactamente lo que el cuadernillo vino a evitar. Las 27 clases del FEC
1.er curso quedaron así y están anotadas como corrección pendiente.

**Qué no es, por arriba.** Tampoco es un tratado. Ocho secciones h2, tres cajas seguidas,
párrafos de doce líneas, digresiones históricas y cuatro tablas por clase producen un tomo
que no se termina en el año y que el estudiante deja de leer en la unidad 2. Si un tema
necesita más, se parte en dos clases: la numeración continua está para eso.

**Cómo se controla.** No hay métrica dura, pero sí dos preguntas que se responden clase por
clase antes de cerrarla: ¿un estudiante que faltó ese día puede estudiar de acá?, y
¿alcanza el tiempo de la clase para hacer lo que pide? Si la primera da que no, está por
abajo. Si la segunda da que no, está por arriba.

## 2. Estructura canónica del tomo

El orden es fijo. Vale para todas las materias, todos los programas y todos los niveles.

1. **Portada** — banda DARK con materia y curso, subtítulo, programa, tipo de documento,
   enfoque «Aprender Haciendo», caso o proyecto integrador y el cierre
   **«República del Paraguay · 2026»**. Nunca ciudad, departamento ni institución: el
   material es de venta nacional y una portada con nombre de colegio lo vuelve invendible
   en el resto del país.
2. **Presentación** — dos a cuatro párrafos dirigidos al estudiante: qué va a aprender, con
   qué caso, cómo se trabaja el cuadernillo.
3. **Índice** — campo TOC dinámico (`indice_toc()`). Se puebla en Word con Ctrl+E → F9; en
   el .docx entregado se ve la leyenda de actualización, y está bien que así sea.
4. **Salto de página.**
5. **Prueba diagnóstica** — **en su propia página**, con título propio, cinco o seis
   consignas de conocimientos previos y renglones para escribir. Cierra con la línea de que
   **no lleva nota**. Nunca va adentro de la Clase 1 ni como primera actividad de la unidad
   1: es un instrumento del docente para conocer el punto de partida, y si queda embutida
   en una clase se pierde.
6. **Salto de página.**
7. **Unidad 1** → clases → evaluación de unidad; Unidad 2 → …; y así hasta el final, con
   **numeración de clases continua** a lo largo de todo el tomo (no se reinicia en cada
   unidad).
8. **Evaluación de la Primera Etapa** al cierre de junio y **de la Segunda Etapa** al cierre
   de noviembre, según cómo caiga el calendario paraguayo sobre las unidades.

La segmentación en unidades y clases sale del programa oficial del MEC y de la carga
horaria, no de la comodidad del contenido. Si el programa tiene cinco unidades temáticas y
la carga horaria da veintiuna clases, el tomo tiene veintiuna clases.

## 3. Anatomía de una clase

Cada clase abre **siempre** con la ficha y sigue con el desarrollo.

**La ficha** (`ficha(doc, capacidad, tema, indicadores)`) trae tres filas: **Capacidad**,
**Tema** e **Indicadores de logro**. La capacidad se copia **textual del programa oficial**
— no se parafrasea ni se «mejora»; si el programa la trae subrayada o abreviada, se
respeta. Los indicadores son dos o tres, **específicos y observables**: describen lo que el
estudiante hace, no lo que comprende. «Calcula el IVA de tres operaciones del caso» sirve;
«Comprende la importancia del IVA» no, porque nadie puede verlo.

La ficha no es decorativa: `plan_anual.py` **lee de ahí** los temas e indicadores del Plan
Anual. Un indicador mal escrito en la ficha llega tal cual al documento del docente. Por
eso los indicadores nunca se escriben dos veces, y por eso ningún campo de la ficha puede
contener códigos internos del pipeline.

**El cuerpo** son unas cuatro secciones h2. La progresión típica: qué es → cómo funciona →
cómo se ve en el caso integrador → qué implica o cómo se decide. Dentro de esas secciones
van, una vez cada una:

- **una caja de ejemplo o de caso**, con números del caso integrador de la materia;
- **una tabla** que ordene lo que la prosa explicó (`add_table_md`), con rótulo cuando es
  larga;
- **un «Concepto clave»**, que fija la definición operativa de la clase en dos o tres
  líneas — es lo que el estudiante subraya para la prueba;
- **un «En Paraguay»**, que aterriza el contenido en la norma, el organismo, la cifra o la
  práctica paraguaya vigente. No es color local: es el diferencial del material frente a
  cualquier manual extranjero, y en las materias con contenido legal se verifica contra
  `references/doctrina-legal.md` antes de escribirlo.

Y al cierre, el bloque de actividades de la familia que corresponda (§5).

**Las cajas disponibles** en `helpers.caja(doc, titulo, bloques, tipo=...)`:

| tipo | Prefijo que imprime | Uso |
|---|---|---|
| `concepto` | «Concepto clave — » | Definición operativa de la clase |
| `paraguay` | «En Paraguay — » | Anclaje normativo o local |
| `ejemplo` | «Ejemplo — » | Resolución o caso numérico |
| `taller` | «Taller — » | Consigna de trabajo extendida |
| `neutra` | *ninguno* | Texto que no es ninguna de las anteriores |
| `referencia` | *ninguno* | Texto de referencia propio (fondo #E0F2F1) |
| `dp` | *ninguno* | Antología de dominio público (fondo #F2FAFB) |
| `observa` | *ninguno* | «Observá en el texto» (fondo #FAF3F3) |

El tipo `neutra` existe porque el defecto clásico era que apareciera «Concepto clave —»
delante de un texto que no lo era. Si el bloque no es un concepto, es `neutra`.

**Figuras.** En materias procedimentales y técnicas los diagramas son obligatorios desde
julio de 2026 (`references/estandar-grafico.md`). Van con `imagen(doc, ruta, lead_in,
epigrafe)`: la prosa que la anuncia, la figura y el epígrafe quedan pegados por `keepNext`.
Una figura sin lead-in que la mencione no se pone.

## 4. Las tres familias de actividades

La familia la determina **la capacidad de la clase**, no la materia en abstracto. Una clase
de legislación dentro de un tomo de Cálculo Mercantil lleva actividades conceptuales, y una
clase de cálculo de intereses dentro de un tomo de Economía lleva procedimentales. La
asignación por materia de abajo es la regla general, no una camisa de fuerza.

### 4.1 CONCEPTUAL

Aproximadamente **cuatro opciones múltiples, tres para completar, tres verdadero/falso y
dos abiertas**. Sirve para contenido que se comprende y se argumenta.

Materias donde domina: Formación Ética y Ciudadana, Filosofía, Antropología, Sociología,
Historia y Geografía, Introducción a la Economía, Economía y Gestión, Legislación
Ambiental, Administración de Empresas, y todas las clases de contenido legal de las
materias contables.

Las opciones múltiples se barajan con `barajar_opciones(eval_id, enunciado, opciones)`, que
usa un hash determinista: la respuesta correcta queda repartida entre a, b, c y d en lugar
de caer siempre en la misma letra, y el tomo y el solucionario **no pueden divergir**
porque comparten la semilla. Nunca se baraja a mano ni se escribe la clave aparte.

### 4.2 PROCEDIMENTAL / de cálculo

Bloques **Ejercitá · Resolvé · Pensá y decidí · Desafío**, en esa progresión: mecánica,
aplicación al caso, decisión justificada, extensión para quien va más rápido.

Materias donde domina: Matemática, Matemática Aplicada a la Informática, Cálculo Mercantil
y Financiero, Algorítmica, Estadística, Física, Química, Dibujo Técnico y todas las clases
de registro y cálculo de las materias contables.

En estas materias **el procedimiento es el contenido**: la clase no explica y después
ejercita, sino que muestra el procedimiento resuelto paso a paso y pide replicarlo. Un
asiento contable, un algoritmo en PSeInt o una construcción geométrica se enseñan
haciéndolos.

### 4.3 PRÁCTICA / de laboratorio

Estructura **objetivo → modelo → pasos → punto de control**. Vive en el **Cuaderno de
Laboratorio**, no en el tomo (§6).

Materias: Gabinete de Software, Gabinete de Hardware, Gabinete de Laboratorio, y las
prácticas de Dibujo Técnico.

### 4.4 Estado de la implementación

`helpers.actividades(doc, lee, analiza, produci, comparti)` está escrita hoy con los
rótulos de lectura **Leé y comprendé · Analizá · Producí · Compartí**, que son los de
Castellano y las materias de lengua. Los rótulos procedimentales y el bloque conceptual
completo **no están en el `helpers.py` de esta versión de la skill**: `SKILL.md` menciona
un `ejercicios()` que el archivo no tiene. Hasta que se generalice `actividades()` para
recibir los rótulos por parámetro, cada tomo define su bloque en su propio módulo. Es
deuda del pipeline, no una decisión editorial: la norma de las tres familias sigue siendo
la de arriba.

## 5. Evaluaciones

Dos niveles, con banda de color fija e invariable en todo el catálogo:

| Instrumento | Banda | Cuándo |
|---|---|---|
| Evaluación de unidad | **ámbar #B8860B** | Al cierre de cada unidad |
| Evaluación de etapa | **azul #1B4F72** | Cierre de la Primera Etapa (junio) y de la Segunda (noviembre) |

Reglas comunes:

- **Cada evaluación empieza en su propia página**, con salto forzado antes. Una evaluación
  que arranca a media hoja, debajo del final de una clase, no se puede fotocopiar suelta.
- Debajo de la banda va la línea de identificación: **Nombre y apellido / Curso / Fecha**.
- **En el material del estudiante no hay claves ni rúbricas.** Ni al pie, ni invertidas, ni
  al final del tomo. Todo eso vive en el Solucionario Docente.
- Los ítems se arman con la misma familia de actividades que las clases que evalúan, y
  sobre los mismos indicadores de las fichas: una evaluación que pregunta algo que ninguna
  ficha declaró es un fallo de coherencia, no una pregunta difícil.
- Las abiertas llevan renglones reales para escribir. El estudiante trabaja sobre el tomo.

## 6. La regla de Gabinete

En las materias de gabinete el tomo y la práctica son **dos piezas complementarias**, no
dos versiones de lo mismo:

- **El tomo es CONCEPTUAL.** Explica qué es una red, qué hace un sistema operativo, cómo se
  estructura una planilla, y evalúa con la familia conceptual.
- **El Cuaderno de Laboratorio es PRÁCTICO.** Una práctica por clase, con la misma
  numeración que el tomo, en formato objetivo → modelo → pasos → punto de control.

Aplica a Gabinete de Software, Gabinete de Hardware y Gabinete de Laboratorio. **No se
reconvierten esos tomos a la familia práctica**: ya se intentó, y el resultado es un tomo
que duplica el cuaderno y un cuaderno que se queda sin razón de existir.

La contracara: **Algorítmica, Matemática Aplicada y Dibujo Técnico llevan el
procedimiento en el tomo**, porque en esas materias el procedimiento *es* el contenido
conceptual y separarlo dejaría el tomo vacío.

El Cuaderno de Laboratorio lleva portada comercial propia, sin nombre de institución ni de
docente, igual que el tomo.

## 7. Entregables por tomo

**Formato de todas las piezas (desde oct-2026): oficio 21,6 × 33 cm con márgenes estrechos
de 1,27 cm y tablas al 100 % del ancho** — tomo, solucionario y Planes de Clase en vertical,
Plan Anual en horizontal. Ninguna pieza en A4: el motivo es el costo de impresión para
docentes y estudiantes. Detalle en `SKILL.md` § Formato de la colección.

Estándar desde julio de 2026. **Tres** archivos siempre, cuatro o cinco según el caso, todos
en `/mnt/user-data/outputs/`:

1. **`..._TOMO_COMPLETO.docx`** — el material del estudiante.
2. **`..._PLAN_ANUAL.docx`** — documento del docente, **archivo aparte**, formato canónico
   de 7 columnas en oficio horizontal. Nunca va adentro del tomo del estudiante.
3. **`..._SOLUCIONARIO_DOCENTE.docx`** — de uso exclusivo del docente. La portada se marca
   con `tipo_doc="Solucionario · Material exclusivo del docente"`, nunca con la leyenda del
   estudiante. Orden interno: **orientaciones para corregir la diagnóstica primero**,
   después las claves clase por clase, y al final las claves de las evaluaciones.
4. **`..._CUADERNO_LABORATORIO.docx`** — sólo en las materias de gabinete (§6).
5. **`..._PLANES_DE_CLASE.docx`** — sólo cuando Fer los pide. **No van por defecto**
   (`references/plan-de-clase.md`).

Más la **planilla de inventario actualizada**, con la fila del tomo completa: identidad
visual con sus cuatro hex, caso integrador, unidades, clases, páginas y notas. Si se
agregaron filas, hay que revisar los rangos de las fórmulas COUNTIF del bloque de resumen,
que no se estiran solos.

## 8. Marca comercial y registro lingüístico

- **Voseo** en todas las consignas dirigidas al estudiante: «Calculá», «Observá»,
  «Compará», «Pensá y decidí». Es la voz del catálogo; un imperativo en tuteo es un error
  editorial, no una variante.
- La **prosa explicativa** va en tercera persona, clara y sin coloquialismo forzado. El
  voseo está en las consignas, no en la exposición.
- **Nunca** aparecen nombre de ciudad, departamento, institución ni docente en el material
  comercial. La portada cierra con «República del Paraguay · 2026» y nada más.
- El **caso integrador** es una empresa o situación paraguaya inventada, propia de la
  materia, coherente a lo largo de todo el tomo y de toda la saga cuando la hay. Sus
  números se diseñan de atrás hacia adelante desde la cifra de cierre y se verifican con
  asserts antes de escribir una sola línea de contenido: un balance que no cierra en la
  clase 18 obliga a reescribir la clase 4.
- Nada de códigos internos del pipeline en campos visibles.

## 9. Edición aditiva: no reconstruir

Un tomo entregado **no se reconstruye**. Si hay que agregar el proyecto de feria, una
corrección de doctrina legal o una clase, se **agrega** sobre el .docx existente,
insertando con `addprevious()` / `addnext()` sobre los elementos XML — capturando las
referencias a los elementos **antes** de mutar el árbol, porque los proxies de lxml se
invalidan. Reconstruir un tomo cerrado significa perder las correcciones manuales que Fer
ya le hizo.

Antes de construir cualquier cosa: revisar `/mnt/user-data/outputs/`, los archivos del
proyecto y la planilla de inventario. Si el tomo ya está, no se rehace.

## 10. Gestión de chats

Fer pidió expresamente que **Claude le avise cuándo cerrar el chat y abrir uno nuevo**: ella
sigue la indicación sin problema, pero necesita que se la den. No es una sugerencia
opcional al final de la entrega — es parte del entregable.

**La regla: un chat por tomo pesado.** Un tomo pesado es el que trae su propio caso
integrador, su propia verificación legal y su propio pipeline de construcción. Se pueden
agrupar dos o tres tomos en un mismo chat **sólo** cuando comparten las tres cosas: el
mismo caso, el mismo marco legal y el mismo pipeline — típicamente los cursos consecutivos
de una misma materia que continúan la misma saga.

Al terminar una entrega, el aviso va explícito: si el próximo tomo sigue en este chat o va
en uno nuevo. Y si en el chat conviven ramas paralelas tocando el inventario, se corta:
**una sola planilla canónica**, nunca dos versiones divergentes editándose a la vez. Las
ocho versiones del inventario que hoy conviven en el proyecto son el resultado de no haber
cortado a tiempo.
