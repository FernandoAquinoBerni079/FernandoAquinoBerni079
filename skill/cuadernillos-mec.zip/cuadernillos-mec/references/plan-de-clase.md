# Plan de Clase — formato canónico V3

Documento de **sesión**: describe una clase concreta con sus momentos, tiempos, recursos
y evaluación. Distinto del **Plan Anual** (documento de curso, tabla continua de 7
columnas, `references/plan-anual.md`) y del **Solucionario** (claves de corrección). Los
tres deben ser coherentes entre sí; nunca se fusionan.

Válido para EEB, Educación Media Científica, Bachilleratos Técnicos, EPJA y formularios
institucionales. La estructura pedagógica es estable; la identificación curricular se
adapta al perfil y **conserva la terminología de la fuente**.

Historia: V1 (12-ago-2026, formato Yegros) → V2 (auditoría externa: perfiles, modos,
parámetros, unicidad flexible, trazabilidad) → **V3** (13-ago-2026: §1.8bis, §1.5bis y
§1.13bis, validadas en la serie de 26 planes de Castellano 8.º con 100/100).

## 1. Modos de derivación

**Modo A — pipeline completo.** Programa oficial → tomo → Plan Anual → Plan de Clase →
Solucionario. El Plan de Clase se genera solo después de cerrar el Plan Anual.

**Modo B — encargo independiente.** Si Fer pide SOLO planes de clase y no hay Plan Anual
del encargo (caso de los prompts de Educación Física y Matemática Yegros), se derivan
directamente del programa oficial. **No se fabrica un Plan Anual innecesario** para
habilitar el proceso.

En Modo A se copian **VERBATIM** de la fila de la misma clase del Plan Anual: **Tema,
Indicadores de logro, Procedimientos e Instrumentos**. La **Capacidad** se copia verbatim
de la **ficha de la clase en el tomo** (el Plan Anual no tiene columna de capacidades); si
no hay tomo, del programa oficial.

Si un campo heredado trae un error o un código interno, **se corrige aguas arriba y se
regenera**, nunca se arregla solo en el Plan de Clase.

Campos propios del Plan de Clase (no existen aguas arriba): momentos con actividades y
tiempos, recursos y criterios de evaluación.

## 2. Estructura: nueve bloques en orden fijo

| N.º | Bloque | Contenido |
|---|---|---|
| 1 | Título | «Plan de Clase N.º X — [tema corto]», estilo `Plan de Clase`, nivel de esquema 1, sección nueva |
| 2 | Banda de identificación | Institución + «Plan de Clase N.º X de [total] · [año]» |
| 3 | Tabla de datos | Docente / Disciplina · Curso o perfil / Tiempo · Organizador curricular / Sección · Material / Fecha · Tema (fila ancha) |
| 4 | Capacidad e indicadores | Capacidad textual de la fuente; 2–4 indicadores observables |
| 5 | Momentos didácticos | Tabla MOMENTO / ACTIVIDADES / TIEMPO: Inicio, Desarrollo, Cierre |
| 6 | Recursos y medios auxiliares | Solo lo disponible y efectivamente usado |
| 7 | Evaluación | Banda + Procedimientos / Instrumentos / Criterios |
| 8 | Observaciones | Línea en blanco |
| 9 | Firmas | Docente / Dirección — Visto bueno |

El bloque **contenidos conceptuales / procedimentales / actitudinales NO es canónico**.
Se inserta entre 4 y 5 solo si el formulario de la institución lo exige (fue el modelo de
Dibujo Técnico-Armoa, Psicología 1.º y Química 2.º-Viera, julio 2026). Motivo de la
exclusión: los programas vigentes se redactan por capacidades e indicadores; forzar la
tríada produce actitudinales genéricos repetidos en todos los planes.

## 3. Trazabilidad pedagógica

Cadena obligatoria por indicador: **indicador → actividad observable → evidencia →
criterio → instrumento**. Un instrumento puede cubrir varios indicadores. Los códigos de
trazabilidad (I1, A1, C1) son control interno: **no aparecen en el documento del docente**.

## 4. Parámetros que no se presumen

| Parámetro | Valores | Regla |
|---|---|---|
| `MODO_DERIVACIÓN` | Pipeline / Independiente | de dónde vienen los campos heredados |
| `PERFIL` | EEB / EM-C / EM-T / EPJA / Institucional | activa solo los campos de identificación pertinentes |
| `MINUTOS_HORA_CÁTEDRA` | dato institucional | **NUNCA suponer 40 min**; se usa solo si el tiempo viene en horas cátedra |
| `VERSIÓN` | Comercial / Personalizada | qué datos quedan en blanco |
| `USA_TOMO` | Sí / No | si se pueden citar clase, figura y texto modelo |
| `FUENTE_CAPACIDAD` | Tomo / Programa | de dónde se copia la capacidad |

## 5. Tiempos

Total del Plan Anual o del encargo; si viene en horas cátedra se convierte con
`MINUTOS_HORA_CÁTEDRA`. Reparto orientativo Inicio 15-25 % · Desarrollo 55-70 % ·
Cierre 10-20 %. **La suma debe coincidir exactamente** con el tiempo declarado (control
aritmético) **y** las actividades deben caber razonablemente en esos minutos (control de
viabilidad). Una suma correcta con seis actividades en 30 minutos no se acepta.

## 6. Registro lingüístico — §1.8 y §1.8bis

La **prosa del plan** va en registro institucional neutro: impersonal, nominal o tercera
persona. «Lectura guiada de…», «Se realiza la puesta en común…». Sin voseo ni tuteo en
las instrucciones.

**§1.8bis — excepción para el material citado.** Títulos, consignas y fragmentos
reproducidos del tomo, del programa o de cualquier fuente **conservan su registro y
redacción originales**, aunque estén en voseo o en guaraní. Neutralizarlos rompe la
correspondencia verbatim de §1 y manda al docente a buscar en el tomo una consigna que
allí está escrita de otro modo.

> Correcto: «Resolución guiada del bloque "Observá en el texto": subrayado de tres marcas
> de oralidad…» — descripción impersonal, cita en voseo intacta.

Control: la cita aparece igual que en el origen y no existe ninguna variante neutralizada.

## 7. Unicidad — §1.5bis

Se **permite** repetir un procedimiento o instrumento cuando es pedagógicamente
pertinente. Se **prohíbe** la repetición mecánica. Como «mecánica» no lo verifica un
script, el piso auditable es:

- Ningún par de planes coincide **simultáneamente** en primera actividad de Inicio +
  procedimiento + instrumento. Coincidir en uno o dos campos está permitido.
- Un instrumento repetido en **más de 3 planes consecutivos** se marca para confirmación
  humana (alerta, no fallo).

Las actividades deben nombrar el texto, el error frecuente y la consigna concreta.
«Explicación del tema y ejercicios» no es una actividad.

## 8. Recursos — correspondencia bidireccional

Con tomo: se citan tomo, clase, texto modelo y figuras realmente usadas. Sin tomo: se
prohíbe citar material del catálogo; solo recursos de una institución común, con
alternativa de bajo costo cuando el recurso puede faltar.

**Control obligatorio ACTIVIDADES ↔ RECURSOS**: todo recurso listado tiene función visible
en las actividades, y toda actividad que dependa de un recurso lo tiene listado.

## 9. Diagnóstico, evaluaciones y tareas: condicionales

La diagnóstica, las evaluaciones de unidad/etapa y las sesiones especiales se incorporan
**solo cuando el Plan Anual, el tomo o el encargo las contemplan**; no por número de
clase. Una evaluación de etapa lleva **plan propio** con los nueve bloques y actividades
de sesión de evaluación. La tarea domiciliaria es **opcional**.

## 10. Datos y códigos internos

Comercial: institución, docente, fecha y sección en blanco. Personalizada: completos, con
nombre en la firma. **Ningún campo visible puede contener códigos del pipeline**
(identificadores del consolidado de textos modelo, nombres de figuras internos, rutas).
La trazabilidad de producción se guarda aparte.

## 11. Requisitos técnicos del .docx

- Un solo .docx por asignatura. Portada + índice TOC dinámico (Ctrl+E → F9) + planes.
- **Hoja oficio 21,6 × 33 cm, márgenes de 1,27 cm** en cada sección (regla de la colección
  desde oct-2026; nunca A4). Ancho útil 19,06 cm: `W` en `planes_clase.py`, y toda tabla al
  100 % (`tblW` pct 5000) con sus columnas escaladas a ese ancho.
- Estilo `Plan de Clase` con `w:outlineLvl = 0`; **una sección nueva por plan**.
- **Layout fijo REAL: `w:tblLayout=fixed` MÁS `w:tblGrid` reescrito** con el ancho de cada
  columna. Solo `tblLayout` no alcanza: Word y LibreOffice reparten las columnas por su
  cuenta y la columna de actividades queda estrangulada.
- Fila MOMENTO/ACTIVIDADES/TIEMPO con `tblHeader` **y** `keepNext` (repetición + sin
  encabezado huérfano).
- **`cantSplit` selectivo**, no universal: se protegen las filas cortas; la fila
  Desarrollo queda divisible. Forzar 100 % genera huecos al pie.
- Pie con campos reales PAGE/NUMPAGES **reconstruido en cada sección y también en la
  primera página** cuando está activada primera página diferente.
- Encabezado de continuación con `STYLEREF "Plan de Clase"`; el encabezado de primera
  página de cada sección se vacía.
- `updateFields=true` **antes** de `w:compat` en settings.xml.
- Tipografía explícita (no heredada del tema), mínimo 9,5 pt. Nunca reducir contenido para
  que entre en una página: si un plan necesita 2 hojas, usa 2 hojas.

### §1.13bis — control de escala

La configuración de una sección por plan es la que más fácilmente pierde el pie de página,
porque cada sección nace desvinculada. **La validación no se hace sobre un plan de
muestra**: se genera la serie completa y se verifica en el render que las páginas con pie
igualen a las páginas del documento, que cada plan empiece al tope de una página y que
ningún bloque se pierda. Un modelo de un plan no es evidencia para una serie de 26.

## 12. Auditoría de liberación

Cuatro áreas ponderadas; **un fallo crítico invalida la entrega aunque el puntaje sea
alto**. Liberación masiva: 100/100 y cero críticos.

| Área | Puntos | Controles |
|---|---|---|
| A · Integridad documental | 20 | cantidad y numeración; nueve bloques; perfil y rótulos; versión comercial/personalizada |
| B · Coherencia curricular y trazabilidad | 30 | derivación verbatim; capacidad correcta; cadena indicador→instrumento; sin residuos; referencias existentes; §1.8bis |
| C · Calidad pedagógica | 30 | actividades específicas; tiempos viables; recursos usados; unicidad §1.5bis; evaluación pertinente; condicionales |
| D · Calidad técnica y editorial | 20 | TOC/estilos/campos; tblGrid; encabezados; cantSplit selectivo; fuentes; render completo |

**Críticos**: plan ausente o duplicado · capacidad o indicador incorrecto · tiempos que no
suman · referencia a material inexistente · contenido de otra materia · evaluación sin
relación con los indicadores · bloque perdido por paginación · texto truncado o tabla rota.

### Regla del auditor (13-ago-2026)

En la primera corrida de los 26 planes, 3 de los 4 fallos eran **controles mal escritos**,
no defectos del documento: el recuento de planes al tope de página contaba también las
páginas de continuación (que empiezan con el mismo título porque el STYLEREF funciona);
el de «Institución» ignoraba la portada; y el de la diagnóstica la contaba dos veces en el
plan 1, cuando la segunda aparición **es** la correspondencia de recursos que exige §8.

**Todo control nuevo se valida contra un caso conocido antes de usarse como criterio de
liberación.** Un control mal formulado produce un falso crítico y frena una entrega
correcta.

## 13. Serie de referencia

`Lengua_y_Literatura_Castellana_8vo_Grado_PLANES_DE_CLASE.docx` — 26 planes (24 clases +
2 evaluaciones de etapa), 42 páginas, 27 secciones, 100/100 con 0 críticos. Generador:
`build_planes.py` + `momentos.py` (contenido propio) + `fuente_planes.json` (campos
heredados extraídos programáticamente del Plan Anual y de las fichas del tomo, nunca
transcritos a mano).

Modelo de un solo plan para mostrar el formato: `MODELO_PLAN_DE_CLASE.docx`.
