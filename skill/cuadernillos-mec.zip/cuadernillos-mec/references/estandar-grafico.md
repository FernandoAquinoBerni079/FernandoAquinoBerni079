# Estándar gráfico de los tomos (doctrina desde jul-2026)

Definido y validado en Matemática Aplicada a la Informática 2.º Curso (82 pág,
17 diagramas). Pedido explícito de Fer: "Quiero que los alumnos vean y aprendan."
Se aplica a TODO tomo nuevo de materia procedimental/técnica y, por retrofit
aditivo, a los ya entregados cuando Fer lo pida. Las materias más beneficiadas:
Matemática Aplicada, Algorítmica, Gabinete Laboratorio, Gabinete Hardware,
Dibujo Técnico, Cálculo Mercantil.

## Regla central

Todo concepto con estructura visual (una matriz, una diagonal, un flujo, un
intervalo, una región, un componente físico) se DIBUJA, no solo se describe.
Un tomo procedimental sin diagramas se considera incompleto desde jul-2026.

## Especificación técnica

- **Motor:** matplotlib (backend Agg) para diagramas matemáticos y esquemas;
  PIL para composiciones simples. 200 dpi, fondo blanco, `bbox_inches="tight"`.
- **Tipografía:** DejaVu Sans (`mathtext.fontset: dejavusans`).
- **Colores:** identidad de la materia como color principal (VERDE BTI
  #1B5E20/#2E7D32/#43A047 en Informática) + acentos fijos: ámbar #B8860B
  (secundario/advertencia), rojo #C62828 (resta/error/no factible), azul #1565C0
  (dato reemplazado/segunda serie), gris #616161 (anotaciones).
- **Inserción** (`helpers.imagen(doc, ruta, lead_in, epigrafe, ancho_cm=14.0)`): SIEMPRE el
  trío (1) párrafo previo que enseña a LEER el diagrama ("Observá…", "Seguí la
  flecha…"), (2) imagen centrada a 13–15,5 cm, (3) epígrafe "Figura N.M — …" en
  itálica 8,5 pt gris (N = clase, M = correlativo dentro de la clase).
- **Organización del código:** módulos `diagramasN.py` que generan los PNG a
  `figs/`, y un `figuras_map.py` con
  `{num_clase: [(idx_seccion, ruta, ancho_cm, lead_in, epígrafe)]}` que el
  renderizador consume — las figuras se declaran como datos, igual que el
  contenido.
- **Desarrollos paso a paso:** acompañar el estándar gráfico con un
  `expansiones.py` (`{(clase, seccion): [párrafos]}`) con ejemplos completamente
  desplegados ("casilla por casilla", "con doble control por sustitución").

## Verificación obligatoria (las tres capas, sin excepción)

1. **Aritmética:** todo número que aparezca DENTRO de un diagrama se verifica
   con numpy/ejecución ANTES de dibujarlo (los diagramas entran en el conteo de
   controles del tomo).
2. **Píxeles:** muestreo de cada PNG con PIL — rechazar si la fracción de tinta
   (píxeles < 100) es menor a 0,2 % (imagen vacía o rota). Esta capa NO gasta
   cupo de imágenes del chat (es lectura numérica con PIL, no `view`).
3. **Visual:** inspeccionar con `view` SOLO 3-4 figuras clave (las técnicamente
   más delicadas: circuitos, gráficos con ejes, esquemas con muchas etiquetas),
   NO las 20-25. Para la auditoría del PDF, usar `pdftotext -layout` para
   verificar texto, estructura, residuos y numeración; reservar `pdftoppm`
   (rasterizar a imagen) para 1-2 páginas concretas solo si hay una duda visual
   real que el texto no resuelve.

## ⚠️ IMÁGENES DEL CHAT — causa real y regla (corregido jul-2026)

CAUSA REAL (verificada empíricamente por Fer): el cupo de ~100 imágenes del
chat lo consumen sobre todo los PDF ESCANEADOS adjuntos (~1 imagen por página
al subirlos). Un programa MEC de 100 páginas funde el cupo antes de empezar.
Las figuras del tomo NO son el problema si el adjunto está recortado.

REGLA: adjuntar SOLO las páginas necesarias del programa (sección del área y
curso: carátula + capacidades + orientaciones; 5-15 páginas), indicando en el
mensaje a qué área/curso corresponden para que el chat verifique la sección
antes de diseñar (lección del typo del DC). Con eso, el flujo normal es EN UN
SOLO CHAT con verificación completa antes de entregar: las tres capas enteras
(numpy, píxeles, inspección visual de figuras clave y rasterizado de páginas
con figuras) y auditoría a 0 fallos, y recién entonces present_files.

PLAN B (solo si aun así aparece el aviso de saturación): pasar a auditoría por
pdftotext, entregar de inmediato con present_files, y si el chat se traba al
entregar, cambiar el modelo a Sonnet (más liviano) para ejecutar solo
ls + present_files. El control visual pendiente se termina en un chat nuevo
adjuntando el tomo entregado.

## Vocabulario visual por familia de materia

- **Matrices/determinantes:** corchetes dibujados (`_corchetes`), filas/columnas
  rotuladas con flechas, elemento localizado con recuadro, diagonales
  sombreadas + flecha de dirección, Sarrus con columnas repetidas y 6 diagonales
  (verdes suman / rojas restan), tablero de signos tipo damero, Cramer con la
  columna reemplazada en azul.
- **Inecuaciones:** rectas numéricas con punto lleno/vacío, intersecciones
  apiladas (una recta por condición + la recta resultado), tabla de signos
  montada sobre la recta, parábolas con la región solución sombreada, región
  factible con vértices rotulados + un punto factible ✓ y uno no factible ✗.
- **Algorítmica:** diagramas de flujo con simbología normalizada (óvalo
  inicio/fin, paralelogramo E/S, rectángulo proceso, rombo decisión), trazas de
  variables por iteración, arreglos como casilleros con índices, DER con
  cardinalidades.
- **Hardware/Laboratorio:** esquemas de bloques rotulados con flechas — NUNCA
  intentos de fotorrealismo; un esquema rotulado enseña más que una foto.
  Placa madre, puertos, jerarquía de memoria, árboles de carpetas, anatomía de
  ventanas, flujos de encendido/POST, árboles de diagnóstico.
- **Imagen digital:** la matriz renderizada como imagen gris real
  (`imshow(cmap="gray", vmin=0, vmax=255)`) con los valores impresos sobre cada
  píxel — la figura más persuasiva de la serie.
- **Grafos/PERT (Matemática 3.º):** nodos y aristas, ruta crítica en rojo con
  duración total, Gantt simple como complemento.
- **Contable/administrativo/legal (BTC — Seminario Contable, CyLA, Cálculo
  Mercantil, Administración de Empresas/Financiera, Introducción a la
  Economía):** ecuación patrimonial como balanza (Activo = Pasivo + PN);
  partida doble como dos columnas enfrentadas (debe/haber) con flecha de
  contrapartida; flujo del asiento (comprobante → registro → mayor → balance)
  con las cifras REALES del caso del tomo; árbol Dupont del ROE con sus tres
  factores; ratios financieros como velocímetros o barras comparativas;
  conciliación bancaria como flujo (saldo libros vs. saldo banco → partidas
  conciliatorias → saldo conciliado); arqueo de caja (efectivo contado vs.
  registrado → diferencia); mapas de impuestos (tributo → base → tasa →
  monto); líneas de tiempo de vencimientos fiscales; organigramas de áreas
  funcionales; mapas de normativas agrupadas por tema. Regla de oro: las cifras
  de estas figuras SIEMPRE se toman del caso ya verificado del tomo — nunca se
  inventan números nuevos para el diagrama.
- **Humanidades/sociales (Historia y Geografía, FEC, Filosofía, Desarrollo
  Personal):** líneas de tiempo (una por unidad como mínimo en Historia);
  mapas esquemáticos DIBUJADOS propios (nunca calcados de mapas con derechos);
  esquemas causa→consecuencia; pirámides sociales; organigramas del Estado;
  dilemas como flujos de decisión; mapas conceptuales; ruedas de emociones y
  redes de apoyo (Desarrollo Personal).
- **Lengua/comunicación (Castellano, Guaraní, Literatura — familia
  COMUNICATIVA):** estructura de los géneros textuales como bloques rotulados
  (partes de la noticia, la carta, el cuento); análisis sintáctico dibujado
  (cajas o árboles); esquemas gramaticales (en guaraní: posposiciones y
  prefijos como tablas visuales); líneas argumentales de las obras; el proceso
  de escritura como ciclo (planificar→redactar→revisar).
- **Ciencias naturales escolares:** el cuerpo y sus sistemas como esquemas
  rotulados; células dibujadas; ciclos naturales como diagramas circulares;
  cadenas alimentarias con flechas; esquemas de experimentos caseros;
  clasificaciones como árboles.
- **Registro etario del tercer ciclo (7.º-9.º, 12-15 años):** las figuras de
  este nivel llevan menos texto por lámina, rótulos más grandes y una sola
  idea por figura; los párrafos-lectura son de 1-2 oraciones.

## Regla de volumen de Laboratorio (Fer, jul-2026)

Gabinete Laboratorio tiene carga excepcional (8/6/12 h semanales, DC may-2026):
sus tomos se dimensionan al TRIPLE del estándar (~150–200 pág) con Cuaderno de
2-3 prácticas por semana. Antes de construir: matemática de segmentación
explícita (horas/sem × ~30 semanas) y PROPONER la estructura a Fer.

## Retrofit de tomos ya entregados

Por EDICIÓN ADITIVA sobre el .docx real (adjuntado por Fer — las copias del
proyecto son extracciones de texto y NO sirven para editar): localizar los
títulos h2 como anclas con python-docx e insertar párrafo-lectura + imagen +
epígrafe. Nunca reconstruir. Tras insertar: auditoría íntegra (PDF, bandas en
página propia, cantSplit, OCR) y actualización del inventario (páginas + nota
"diagramas didácticos ✓").
