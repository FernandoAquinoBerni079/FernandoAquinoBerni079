# Plan Anual — formato canónico

Documento **de curso**: la planificación completa del año en una sola tabla continua, que
el docente presenta y la dirección firma. Distinto del **tomo** (material del estudiante),
del **Plan de Clase** (documento de sesión, `references/plan-de-clase.md`) y del
**Solucionario**. Los cuatro tienen que ser coherentes entre sí y **ninguno se fusiona con
otro**.

Va **siempre en archivo aparte**. Nunca adentro del tomo del estudiante: es material del
docente, trae instrumentos de evaluación y lleva firmas.

Se genera con `scripts/plan_anual.py` → `build_plan_anual(plan_data, ruta)`. Esta
referencia documenta el script; si algo no coincide, manda el script.

## 1. Formato

| Parámetro | Valor | Dónde |
|---|---|---|
| Orientación | **A4 horizontal** (29,7 × 21,0 cm) | `WD_ORIENT.LANDSCAPE` |
| Márgenes | 1,2 cm arriba/abajo · 1,5 cm izquierda/derecha | ancho útil real **26,7 cm** |
| Tabla | **continua, 7 columnas**, layout fijo con `tblGrid` | no se corta en tablas por unidad |
| `ANCHOS` | `[1.0, 5.0, 6.8, 1.5, 5.3, 4.2, 2.8]` = **26,6 cm** | 1 mm de holgura sobre el ancho útil |
| Tipografía | Calibri 8,5 pt en las celdas | 9-10 pt en encabezado y cierre |

**Los `ANCHOS` no se reescriben a mano.** Es el defecto que más veces reapareció: una
versión vieja los tenía sumando 28,2 cm y la tabla se desbordaba del A4 apaisado. El
`SKILL.md` menciona 26,7 y el script suma 26,6 — no es contradicción: 26,7 es el ancho útil
del papel y 26,6 es lo que ocupa la tabla, con un milímetro de aire para que Word no
empuje la última columna. Si aparece una versión con otra suma, es vieja.

`tblLayout=fixed` **más** `tblGrid` reescrito columna por columna. Sólo con `tblLayout`,
Word y LibreOffice reparten las columnas por su cuenta y la de indicadores queda
estrangulada.

### Columnas

`N.º · TEMAS · INDICADORES DE LOGRO · TIEMPO · PROCEDIMIENTOS · INSTRUMENTOS DE EVALUACIÓN
· OBSERVACIÓN`

### Trazabilidad de capacidades (desde oct-2026)

Cada secuencia lleva su **capacidad MEC textual** dentro de la celda TEMAS, debajo del tema:
el rótulo «Capacidad MEC:» en negrita y cada capacidad entre comillas y en cursiva. Se
cargan en `clase['capacidades']` (lista); el encabezado pasa solo a «TEMAS Y CAPACIDAD
MEC». **No se agrega una octava columna**: los ANCHOS ya suman el ancho útil. Las
profundizaciones y las evaluaciones de unidad repiten la capacidad que consolidan; las
integradoras de etapa pueden remitir a las secuencias para que la fila no supere una hoja.
Antes de generar: `verificar_capacidades(plan_data, CAPACIDADES_PROGRAMA)`. La auditoría
externa de Software 1.º (oct-2026) marcó como hallazgo un Plan Anual que decía
«capacidades oficiales conservadas» sin mostrarlas.

Los marcos legales de los criterios generales siguen `doctrina-legal.md`: una ley
publicada pero en *vacatio legis* (Ley 7593/2025 de datos personales, vigente desde el
27/11/2027) no se presenta como «vigente».

### Colores

| Fila | Color | Texto |
|---|---|---|
| Cabecera de las 7 columnas | **#5D4037** (`CABECERA`) | blanco, negrita |
| Banda de etapa (fusionada a 7) | **#1B4F72** (`AZUL`) | blanco, 9,5 pt |
| Fila de unidad (fusionada a 7) | **MED de la materia** | blanco, 9 pt |
| Fila de clase, columna N.º | **LIGHT de la materia** | negro |
| Fila de evaluación de etapa | **#EAF0F6** (`AZUL_CLARO`) | negro, N.º y tema en negrita |

Los tonos fijos no cambian por materia (`references/identidades.md` §2). Lo único que trae
la identidad de la materia son las filas de unidad y la columna del número de clase.

### Encabezado y cierre

Arriba: título `PLAN ANUAL — MATERIA · CURSO` en DARK, línea de subtítulo con carga horaria
y `República del Paraguay · 2026`, y la línea en blanco de **Institución educativa** y
**Docente** — en blanco porque es material comercial.

Abajo, después de la tabla: **Criterios generales de evaluación**, **Estrategias de
inclusión** y las dos firmas (docente / dirección).

### Requisitos técnicos

- **`cantSplit` en el 100 % de las filas.** Ésta es la regla del Plan Anual y del tomo. En
  los Planes de Clase el `cantSplit` es **selectivo** (`plan-de-clase.md` §11): no se
  "corrige" uno con la regla del otro.
- `tblHeader` en la fila de cabecera, para que se repita en cada hoja.
- Pie con campos reales PAGE/NUMPAGES (`fldChar`, no texto literal).
- `updateFields=true` **antes** de `w:compat` en `settings.xml` (orden del schema).

## 2. La estructura de datos

```python
plan_data = {
  'materia': 'Contabilidad y Legislación Aplicada',
  'curso': '2.º curso',
  'subtitulo': 'Bachillerato Técnico en Contabilidad · Plan Específico',
  'horas': '5 horas semanales',
  'anio': '2026',
  'identidad': {'DARK': '0E5A5A', 'MED': '147D7D', 'LIGHT': 'E7F3F3'},
  'etapas': [
     {'banda': 'PRIMERA ETAPA — cierre en junio',
      'unidades': [
         {'nombre': 'UNIDAD 1 — …',
          'clases': [
             {'n': 1, 'tema': '…', 'indicadores': ['…', '…'], 'tiempo': '5 h',
              'procedimiento': '…', 'instrumento': '…', 'observacion': '…'},
          ]},
      ],
      'evaluacion': 'Evaluación de la Primera Etapa (Unidades 1 a 4)'},
  ],
  'tiempo_etapa': '5 h',
  'criterios': '…', 'inclusion': '…',
}
```

La fila de evaluación de etapa la arma el script solo, con `N.º = «—»` y textos fijos; lo
único que se le pasa es el nombre en `etapa['evaluacion']`.

## 3. De dónde sale cada campo

Ésta es la parte que define si el Plan Anual sirve o es un documento paralelo que se
desincroniza del tomo en la primera corrección.

**TEMAS e INDICADORES DE LOGRO se LEEN de las fichas del tomo. Nunca se escriben a mano.**
Dos caminos:

- `helpers.extraer_fichas()`, por expresión regular. **Sólo funciona si las fichas están
  escritas como llamadas literales** `H.ficha(doc, capacidad="...", tema="...", ...)` en los
  módulos de contenido.
- Si el contenido está declarado como diccionarios de datos, la regex no ve nada: hay que
  **importar los módulos y leer las claves**.

En los dos casos, antes de generar:

```python
assert len(FICHAS) == N_CLASES, 'faltan fichas: %d de %d' % (len(FICHAS), N_CLASES)
```

Sin ese assert, un Plan Anual con 19 de 21 clases sale sin avisar y el docente firma una
planificación incompleta.

**N.º** es la numeración continua del tomo, que no se reinicia por unidad.
**TIEMPO** sale de la carga horaria oficial, no de una estimación.
**PROCEDIMIENTOS** e **INSTRUMENTOS** son campos propios del Plan Anual: no existen aguas
arriba y se escriben acá, con las reglas del §4.
**OBSERVACIÓN** es opcional; sirve para el aviso de página propia, material o articulación.

**Clase 1** lleva la **prueba diagnóstica** como procedimiento y como instrumento.
**La última clase de cada unidad** lleva «Cierre de Unidad N» y la **evaluación de unidad**
como instrumento. Las dos cosas se cargan en `plan_data`; el script no las infiere.

Si un campo heredado trae un error, **se corrige aguas arriba y se regenera**: se arregla
la ficha del tomo y se vuelve a construir el Plan Anual. Nunca se parcha sólo acá, porque
en la próxima regeneración vuelve el error.

## 4. Unicidad de procedimientos e instrumentos

`verificar_unicidad(plan_data)` exige que **todos** los procedimientos sean distintos entre
sí y **todos** los instrumentos también, y devuelve la cantidad de clases verificadas. Es un
assert, no una advertencia.

**Ojo con la asimetría.** El Plan Anual pide unicidad estricta; el Plan de Clase admite
repetición pedagógicamente pertinente con un piso verificable (`plan-de-clase.md` §1.5bis).
Son documentos distintos con reglas distintas: no se importa el criterio de uno al otro.
El motivo es práctico: en el Plan Anual la columna se lee entera de un vistazo, y veinte
veces «Prueba escrita» seguidas es lo primero que observa una dirección.

Escribir 21 o 25 instrumentos realmente distintos obliga a pensar la evaluación clase por
clase, que es el punto. Lista de partida: registro anecdótico, lista de cotejo, escala de
estimación, rúbrica analítica, portafolio, resolución guiada, mapa conceptual evaluado,
exposición oral con guía, informe de laboratorio, prueba escrita de unidad, autoevaluación
con criterios, coevaluación entre pares, cuaderno de trabajo revisado, ficha de proceso,
resolución de caso, simulación, defensa de resultados.

## 5. Sin códigos internos

`sin_codigos_internos(plan_data)` recorre `tema`, `procedimiento`, `instrumento` y
`observacion` buscando patrones del pipeline (`8-01`, `IMG_014`, `TXT_*`) y corta con
assert si encuentra alguno. **El Plan Anual lo lee un docente y lo firma una dirección**: un
código interno ahí no es un detalle estético, es un documento que no se puede presentar.

Igual que los indicadores: se corrige aguas arriba, en el módulo de contenido, y se
regenera.

## 6. Antes de entregar

```python
n = verificar_unicidad(plan_data)      # assert: procedimientos e instrumentos únicos
sin_codigos_internos(plan_data)        # assert: sin residuos del pipeline
assert n == N_CLASES
build_plan_anual(plan_data, ruta)
```

Y en el render PDF (sólo para auditar, el entregable es el .docx):

- La tabla **no se desborda** del ancho de la hoja y ninguna columna quedó estrangulada.
- La cabecera de 7 columnas **se repite** en todas las hojas.
- Ninguna fila quedó partida entre páginas.
- Todas las clases del tomo están, con la numeración continua completa y sin saltos.
- Los indicadores del Plan Anual son **literalmente** los de las fichas del tomo.
- El pie aparece en todas las páginas.

## 7. Caso de referencia

`Lengua_y_Literatura_Castellana_8vo_Grado_PLAN_ANUAL.docx`: 24 clases + 2 evaluaciones de
etapa, **24 procedimientos y 24 instrumentos únicos**, indicadores leídos de las fichas del
tomo. Es el archivo contra el que se valida que el generador sigue sano.
